// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/error.js
var e = class extends Error {
	constructor(e) {
		let t = Error, n = t.stackTraceLimit;
		n && (t.stackTraceLimit = 0), super(), n && (t.stackTraceLimit = n), this.source = e;
	}
}, t = class extends Error {
	constructor(e, t) {
		try {
			var n = String(t instanceof Error ? t.message : t);
		} catch {}
		super(n, { cause: t }), this.source = e;
	}
};
function n(e) {
	return e instanceof t ? e.cause : e;
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/constants.js
var r = 1024, i = 2048, a = 4096, o = 8192, s = 16384, c = 1 << 17, l = 1 << 18, u = 1 << 19, d = 1 << 22, f = 1 << 23, p = 1 << 20, m = 1024, h = 4096, g = 1 << 18, _ = 1 << 21, v = 1 << 22, y = {}, b = {}, ee = Symbol("refresh"), te = Set;
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/owner.js
function ne(e) {
	let t = e.pe;
	for (; t;) t.R |= 32, ne(t), t = t.Ge;
}
var re;
function ie(e) {
	try {
		e();
	} catch (e) {
		re || (re = [e]), k();
	}
}
function x(e) {
	let t = re;
	if (re = void 0, t && !e) throw t[0];
}
function ae(e, t = !1, n) {
	let r = e.R;
	if (r & 64) return;
	t && (n || e.T === null || e.T.me === null && e.T.Le === null || ae(e, !1, !0), e.R = r | 64, e.X && (ln(e), (e.m & 1 && e.T?.Re != null || r & 2048 || Et.length) && k()));
	let i = n ? e.T.me : e.pe;
	for (n ? e.T.me = null : e.pe = null; i;) i.l &= -33, Ut(i, D), $t(i), i.Me = i, ae(i, !0), i = i.Ge;
	if (n || (e.be = 0), t && !n && !(r & 32) && e._parent !== null && !(e._parent.R & 64)) {
		let t = e.Me, n = e.Ge;
		t === null ? e._parent.pe = n : t.Ge = n, n !== null && (n.Me = t), e.Me = null;
	}
	if (se(e, n), t && e.ze) {
		let t = e.ze;
		e.ze = void 0, ie(t);
	}
}
function oe(e, t) {
	let n = e.pe;
	t.Me = null, t.Ge = n, n !== null && (n.Me = t), e.pe = t;
}
function se(e, t) {
	let n = t ? e.T.Le : e.ke;
	if (n) {
		if (t ? e.T.Le = null : e.ke = null, Array.isArray(n)) for (let e = n.length - 1; e >= 0; e--) ie(n[e]);
		else ie(n);
	}
}
function ce(e, t) {
	for (; e.l & 4 && e._parent;) e = e._parent;
	if (e.id != null) return de(e.id, t ? e.be++ : e.be);
	throw Error();
}
function le(e) {
	return ce(e, !0);
}
function ue(e, t, n) {
	return e?.id ?? (t ? n?.id : n?.id == null ? void 0 : le(n));
}
function de(e, t) {
	let n = t.toString(36), r = n.length - 1;
	return e + (r ? String.fromCharCode(64 + r) : "") + n;
}
function S() {
	return j ? M : null;
}
function fe() {
	return M;
}
function pe(e, t = M) {
	return t && (t.ke ? Array.isArray(t.ke) ? t.ke.push(e) : t.ke = [t.ke, e] : t.ke = e), e;
}
function me(e) {
	return !!(e.R & 64);
}
function he(e = !0) {
	ae(this, e), re && !A.Y && x();
}
function ge(e) {
	let t = M, n = e?.transparent ?? !1, r = {
		id: ue(e, n, t),
		l: n ? 4 : 0,
		R: 0,
		Qe: !0,
		Ke: t?.Qe ? t.Ke : t,
		pe: null,
		Ge: null,
		Me: null,
		ke: null,
		A: t?.A || b,
		be: 0,
		T: null,
		_parent: t,
		dispose: he
	};
	return t && oe(t, r), r;
}
function _e(e, t) {
	let n = ge(t);
	return mr(n, () => e(he.bind(n, !0)));
}
// \0@oxc-project+runtime@0.156.0/helpers/esm/typeof.js
function ve(e) {
	"@babel/helpers - typeof";
	return ve = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
		return typeof e;
	} : function(e) {
		return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
	}, ve(e);
}
// \0@oxc-project+runtime@0.156.0/helpers/esm/toPrimitive.js
function ye(e, t) {
	if (ve(e) != "object" || !e) return e;
	var n = e[Symbol.toPrimitive];
	if (n !== void 0) {
		var r = n.call(e, t || "default");
		if (ve(r) != "object") return r;
		throw TypeError("@@toPrimitive must return a primitive value.");
	}
	return (t === "string" ? String : Number)(e);
}
// \0@oxc-project+runtime@0.156.0/helpers/esm/toPropertyKey.js
function be(e) {
	var t = ye(e, "string");
	return ve(t) == "symbol" ? t : t + "";
}
// \0@oxc-project+runtime@0.156.0/helpers/esm/defineProperty.js
function xe(e, t, n) {
	return (t = be(t)) in e ? Object.defineProperty(e, t, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[t] = n, e;
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/scheduler.js
var Se = null, Ce = null, we = null, Te = null, Ee = null, De = null, Oe = null, ke = null, Ae = null, je = null, Me = null, Ne = null, Pe = null, Fe = null;
function Ie(e, t) {
	Pe = e, Fe = t;
}
var Le = null, Re = null, ze = null, Be = null, Ve = null, He = null, Ue = void 0, We = [];
function Ge(e, t = null) {
	let n = {
		ln: [],
		rn: [[], []],
		fn: [],
		eo: null,
		_parent: t,
		P: e,
		Pe: null,
		tt: 0,
		nt: !1,
		nn: null,
		Ue: !1,
		un: !1,
		I: null
	};
	return e || We.push(n), n;
}
var C = null, w = null, Ke = null;
function qe(e, t) {
	if (A.Y && !t || w !== null) return Ye(e);
	Ke === null ? Ke = E(e) : Xe(E(e), Ke), k();
}
function T(e) {
	return e.T.Re = E(e.T.Re);
}
function Je(e) {
	return e = E(e), We.indexOf(e) === -1 ? null : e;
}
function E(e) {
	for (; e.eo !== null;) e = e.eo;
	return e;
}
function Ye(e) {
	let t = w;
	t === null ? w = e === null ? Ge(!1) : E(e) : e !== null && Xe(E(e), t), A.Y || k();
}
function Xe(e, t) {
	var n, r;
	e = E(e), t = E(t), e === t || e.P || t.P || (e.eo = t, t.tt += e.tt, (n = t).nt || (n.nt = e.nt), Tt(t.ln, e.ln), Tt(t.rn[0], e.rn[0]), Tt(t.rn[1], e.rn[1]), Tt(t.fn, e.fn), e.I !== null && Tt((r = t).I ?? (r.I = []), e.I), We.splice(We.indexOf(e), 1));
}
function Ze(e) {
	let t = Qe;
	Qe ?? (Qe = e);
	let n = e.tt !== 0 || et(e.ln, e) || !!Ee?.(e);
	return Qe = t, n;
}
var Qe = null;
function $e(e, t) {
	let n = e.T?.se;
	if (n === void 0) return !0;
	for (let e of n) {
		let n = e.T?.Re;
		if (n == null || E(n) === t) return !0;
	}
	return !1;
}
function et(e, t, n = !1) {
	for (let r = 0; r < e.length; r++) {
		let i = e[r];
		if (!(!(i.m & 1) || i.R & 64 || i.l & 8192 || i.T.Re !== null && T(i) !== t || n && !$e(i, t))) {
			if (i.i === 1) {
				if (tt(i, Qe ?? t)) return !0;
			} else for (let e = i.o; e !== null; e = e.t) {
				let n = e.u;
				if ((n.i === 1 && n.m & 1 || n.R & 2048 || n.l & 16384 && n.m === 1) && (e.Ne === n.de || n.T?.U != null) && !(n.R & 64) && tt(n, Qe ?? t)) return !0;
			}
		}
	}
	return !1;
}
function tt(e, t) {
	return !je?.(e) && !(e.R & 32 && nt(e, t));
}
function nt(e, t) {
	for (; e?.R & 32;) e = e._parent;
	return e?.l & 256 && e.T?.Re != null && T(e) === E(t);
}
var rt = [];
function it(e) {
	rt.push(e);
}
var at = [];
function ot(e) {
	Ut(e, D), e.R &= -4, at.push(e);
}
function st(e, t) {
	e.l |= 256, ct(e, t);
}
function ct(e, t) {
	let n = N(e);
	n.Re !== t && (n.Re = t, t.ln.push(e));
}
function lt(e, t) {
	for (let n = e.pe; n !== null; n = n.Ge) n.T?.Re?.P || (n.X !== void 0 && (n.l & 256 || st(n, t), n.l |= p), lt(n, t));
}
var D = {
	et: Array(2e3).fill(void 0),
	p: !1,
	Fe: 0,
	Et: 0
}, O = 0, ut = !1, dt = !1, ft = !1, pt = 0, mt = 0, ht = 0;
function gt(e) {
	ht = e;
}
function k() {
	dt ? bt() : ut || (ut = !0, !pt && !A.Y && queueMicrotask(Lt));
}
var _t = Symbol.for("solid-js/root-error-hook"), vt = "[REACTIVITY_HALTED]";
function yt(e) {
	if (dt) return;
	dt = !0, x(!0);
	let t = vt, n = e !== void 0 && globalThis.reportError;
	n || e === void 0 ? console.error(t) : console.error(t, e), n && n(e);
}
function bt() {
	ft || (ft = !0, console.error(vt));
}
var xt = class e {
	constructor() {
		xe(this, "rn", [[], []]), xe(this, "Y", !1);
	}
	flush() {
		if (!this.Y) {
			this.Y = !0, rr(), C = null, Ke = null;
			try {
				an(), Kt(D, e._e), this.settle(), O++, ut = D.Et >= D.Fe || Et.length !== 0, this.run(1), this.run(2);
			} finally {
				this.Y = !1, Ke = null;
			}
		}
	}
	settle() {
		we?.() && Kt(D, e._e);
		let t = w;
		w = null, Ce?.(t);
		let n = t !== null && !t.P ? E(t) : null;
		if (n !== null) {
			let e = Et.length;
			for (let t = 0; t < e; t++) {
				let e = Et[t];
				if (!(e.l & 2304) && (e.T === null || e.T.Re === null || !e.T.Re.P)) {
					if (e.ue === y && e.m & 4 && e.i !== 1) continue;
					if (e.ue !== y && !(e.m & 5) && e.T?.me == null && e.T?.Le == null && !e.T?.Te && fr(e, e.le, e.ue)) {
						e.ue = y, e.l &= -129;
						continue;
					}
					st(e, n);
				}
				e.l & 128 && lt(e, n);
			}
			Et.length = 0, Pe?.(n), at.splice(0);
		} else {
			It();
			for (let e = 0; e < rt.length; e++) {
				let t = rt[e];
				t.T?.U == null && !t.Ae && Qt(t);
			}
		}
		rt.length && (rt.length = 0);
		let r = this.rn;
		this.rn = [[], []];
		for (let e = We.length - 1; e >= 0; e--) {
			let t = We[e];
			Ze(t) || (We.splice(e, 1), Te?.(t), Ct(t), e = We.length);
		}
		Fe?.();
		let i = n && Je(n);
		Le?.(i);
		let a = i !== null;
		for (let e = 0; e < 2; e++) a && Tt(i.rn[e], r[e]), this.rn[e] = a || this.rn[e].length ? [].concat(a ? [] : r[e], this.rn[e]) : r[e];
		if (at.length !== 0) {
			let e = at.splice(0).sort((e, t) => e.he - t.he);
			for (let t = 0; t < e.length; t++) e[t].R & 64 || kn(e[t]);
		}
		Me?.();
	}
	run(e) {
		let t = this.rn[e - 1];
		t.length && (this.rn[e - 1] = [], Rt(t, e));
	}
	enqueue(e, t, n = C) {
		e && (n?.P ? n : this).rn[e - 1].push(t), k();
	}
	notify(e, t, n, r) {
		return ke?.(e, n & t, r) ? !0 : t & 1 ? (n & 1 && C === null && Ye(null), !0) : !1;
	}
};
function St(e) {
	let t;
	for (let n = 0; n < e.fn.length; n++) {
		let r = e.fn[n], a = r.T?.U?.source;
		if (!(r.R & 64 || r.m & 2 && (r.i || !(r.l & 8388608)) && a !== r && (a?.m ?? 2) & 2) && r.R & 2048) {
			t = 1, e.P || (r.R &= ~i), r.Ae = !1;
			for (let e = r.pe; e !== null; e = e.Ge) e.i && (e.Ae = !1);
			De?.(r), zt(r);
		}
	}
	return e.fn.length = 0, t;
}
function Ct(e) {
	let t = St(e);
	for (let t = 0; t < e.ln.length; t++) {
		let n = e.ln[t];
		n.T.Re !== null && T(n) === e && (n.T.Re = null, Ft(n));
	}
	w === e && (w = null), t ? A.rn[1].push(() => wt(e)) : wt(e);
}
function wt(e) {
	for (let t = 0; t < 2; t++) Tt(A.rn[t], e.rn[t]), e.rn[t] = [];
}
function Tt(e, t) {
	for (let n = 0; n < t.length; n++) e.push(t[n]);
}
var Et = [];
function Dt(e, t) {
	t.fn.push(e), e.R |= i;
}
function Ot(e) {
	Et.push(e), A.Y || Qn();
}
var kt = 0;
function At() {
	kt++;
}
function jt(e) {
	e.we = kt;
	let t = !!(e.l & 512) && e.T?.De !== void 0;
	for (let n = e.o; n !== null; n = n.t) {
		let r = n.u;
		r.R & 4 && n.Ne === r.de && (n !== r._ || !e.X) && (r.R |= a), t && r.l & 8 ? r.R |= 256 : (zt(r), r.R & 8388608 && Gt(r._parent, 1));
	}
}
function Mt(e) {
	e.Ae = !0, A.enqueue(e.i, e.W ?? (e.W = xt.q.bind(null, e)));
}
function Nt(e) {
	return e.ue !== y && (e.le = e.ue, e.ue = y);
}
function Pt(e) {
	return !(e.m & 4) && !!e.T?.Ee && !e.T.Ve && (e.ue = y, !0);
}
function Ft(e) {
	if (!e.X) {
		e.l &= -385, Nt(e);
		return;
	}
	let t = !!(e.m & 1) && (e.ue === y || Pt(e)), n = e.l & _;
	if (!t && e.T && (e.T.Te = null), e.l = t ? e.l & -1048833 | m : e.l & -3147137, n) {
		let t = e.ue;
		e.ue = y, e.ie = O + 1, En(e, 2, t);
	} else Nt(e) && (e.m &= -5, e.T != null && (e.T.Ve = !1, e.T.je = y), e.i && e.i !== 3 && Mt(e));
	e.Ie = !1, e.R &= ~r, e.T?.U ?? Qt(e), e.m & 1 || (e.m &= -5), t || e.T == null || e.T.me === null && e.T.Le === null || xt.Ce(e, !1, !0);
}
function It() {
	for (let e = 0; e < Et.length; e++) {
		let t = Et[e];
		t.l & 2304 || Ft(t);
	}
	Et.length = 0;
}
var A = new xt();
function Lt(e) {
	if (mt > 0) return e ? e() : void 0;
	if (e) {
		pt++;
		try {
			return e();
		} finally {
			try {
				Lt();
			} finally {
				pt--;
			}
		}
	}
	if (!A.Y && !dt) {
		for (; ut;) A.flush();
		x();
	}
}
function Rt(e, t) {
	for (let n = 0; n < e.length; n++) e[n](t);
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/heap.js
function zt(e) {
	D.Fe > e.he && (D.Fe = e.he), Vt(e, D);
}
function Bt(e, t) {
	let n = (e._parent?.Qe ? e._parent.Ke?.he : e._parent?.he) ?? -1;
	n >= e.he && (e.he = n + 1);
	let r = e.he, i = t.et[r];
	if (i === void 0) t.et[r] = e;
	else {
		let t = i.We;
		t.ve = e, e.We = t, i.We = e;
	}
	r > t.Et && (t.Et = r);
}
function Vt(e, t) {
	let n = e.R;
	n & 12 || (n & 1 ? e.R = n & -4 | 10 : (e.R = n | 8, t.p && Gt(e)), n & 16 || Bt(e, t));
}
function Ht(e, t) {
	let n = e.R;
	n & 28 || (e.R = n | 16, Bt(e, t));
}
function Ut(e, t) {
	let n = e.R;
	if (!(n & 24)) return;
	e.R = n & -25;
	let r = e.he;
	if (e.We === e) t.et[r] = void 0;
	else {
		let n = e.ve, i = t.et[r], a = n ?? i;
		e === i ? t.et[r] = n : e.We.ve = n, a.We = e.We;
	}
	e.We = e, e.ve = void 0;
}
function Wt(e) {
	if (!e.p) {
		e.p = !0;
		for (let t = 0; t <= e.Et; t++) for (let n = e.et[t]; n !== void 0; n = n.ve) n.R & 8 && Gt(n);
	}
}
function Gt(e, t = 2) {
	let n = e.R;
	if (!((n & 3) >= t)) {
		e.R = n & -4 | t;
		for (let t = e.o; t !== null; t = t.t) Gt(t.u, 1);
	}
}
function Kt(e, t) {
	for (e.p = !1, e.Fe = 0; e.Fe <= e.Et; e.Fe++) {
		let n = e.et[e.Fe];
		for (; n !== void 0;) n.R & 8 ? t(n) : qt(n, e), n = e.et[e.Fe];
	}
	e.Et = 0;
}
function qt(e, t) {
	Ut(e, t);
	let n = e.he;
	for (let t = e.C; t; t = t.G) {
		let e = t.S;
		e.X && e.he >= n && (n = e.he + 1);
	}
	if (e.he !== n) {
		e.he = n, Jt(e, n);
		for (let n = e.o; n !== null; n = n.t) n.u !== e._parent && Ht(n.u, t);
	}
}
function Jt(e, t) {
	for (let n = e.pe; n; n = n.Ge) if (n.Qe) Jt(n, t);
	else if (n.he <= t) {
		let e = n.R & 24;
		Ut(n, D), n.he = t + 1, e && (e & 8 ? Vt : Ht)(n, D), Jt(n, t + 1);
	}
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/graph.js
var Yt;
function Xt(e) {
	Yt = e;
}
function Zt(e) {
	let t = e.S, n = e.G, r = e.t, i = e.en;
	return r === null ? t.Ze = i : r.en = i, i === null ? (t.o = r, r === null && (t.l & 4096 ? Yt(t) : t.T?.Ye && ie(t.T.Ye), t.X && t.l & 32 && !(t.R & 32) && !(t.m & 1) && (en ? en.push(t) : nn(t)))) : i.t = r, n;
}
function Qt(e) {
	let t = e._, n = t === null ? e.C : t.G;
	if (n !== null) {
		do
			n = Zt(n);
		while (n !== null);
		t === null ? e.C = null : t.G = null;
	}
}
function $t(e) {
	e.C && (e._ = null, Qt(e));
}
var en = null, tn = (e) => en = e;
function nn(e) {
	Ut(e, D), $t(e), ae(e, !0);
}
var rn = new te();
function an() {
	if (rn.size !== 0) {
		for (let e of rn) !e.o && e.l & 32 && !(e.m & 1) && !(e.R & 96) && nn(e);
		rn.clear();
	}
}
function on(e, t) {
	let n = t._;
	if (n !== null && n.S === e) return;
	let r = null, i = t.R & 4;
	if (i && (r = n === null ? t.C : n.G, r !== null && r.S === e)) {
		r.Ne = t.de, t._ = r;
		return;
	}
	let a = e.Ze;
	if (a !== null && a.u === t && (!i || a.Ne === t.de)) return;
	let o = t._ = e.Ze = {
		S: e,
		u: t,
		G: r,
		en: a,
		t: null,
		Ne: t.de
	};
	n === null ? t.C = o : n.G = o, a === null ? e.o = o : a.t = o, At();
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/async.js
function sn(e, t) {
	var n;
	return !e.T?.se?.has(t) && (((n = N(e)).se ?? (n.se = new te())).add(t), !0);
}
function cn(e, t) {
	let n = e.T?.se;
	return n?.delete(t) ? (n.size || (e.T.se = void 0), !0) : !1;
}
function ln(e) {
	e.T !== null && (e.T.Ee = null);
}
function un(e) {
	e.T !== null && (e.T.se = void 0);
}
function dn(e, t) {
	for (let n = e.C; n; n = n.G) {
		let e = n.S;
		if (e === t || e.T?.se?.has(t)) return !0;
	}
	return !1;
}
function fn(e, t) {
	N(e).fe = !0, t.source && sn(e, t.source), e.m & 2 || pn(e, t.source, t);
}
function pn(t, n, r) {
	if (!n) {
		t.T !== null && (t.T.U = null);
		return;
	}
	let i = r instanceof e && r.source === n ? r : t.T?.U;
	N(t).U = i instanceof e && i.source === n ? i : new e(n);
}
function mn(e, t) {
	for (let n = e.o; n !== null; n = n.t) t(n.u, n);
}
function hn(e, t) {
	let n = new te(), r = (e) => {
		let i = n.has(e);
		t(e, i) !== !1 && !i && (n.add(e), mn(e, r));
	};
	mn(e, r);
}
function gn(e) {
	e.X && e.l & 32 && !e.o && !(e.R & 32) && !(e.m & 1) && (e.R & 8 ? e.R |= d : nn(e));
}
function _n(e) {
	let t;
	if (hn(e, (e, n) => {
		!n && !e.o && e.l & 32 && (t ?? (t = [])).push(e);
	}), t) for (let e of t) gn(e);
}
function vn(e, n, r) {
	return !(e.l & 256 || r && e.R & 16384 && A.Y && !e.rr) || C ? !1 : (un(e), e.T && (e.T.fe = !1), (e.m &= 6) & 2 || pn(e), e.ue = n instanceof t ? n : new t(e, n), e.l |= 128 | _, bn(e), k(), !0);
}
function yn(e, t) {
	let n = !1;
	hn(e, (e, r) => {
		!r && e.T?.U === t && (zt(e), n = !0);
	}), n && k();
}
function bn(e, t = e) {
	cn(e, t);
	let n = !1, r;
	if (hn(e, (i, a) => {
		if (a || t !== e && dn(i, t) || !cn(i, t)) return !1;
		i.ie = O;
		let o = i.T?.se?.values().next().value, s = i.m & 2;
		o ? s || pn(i, o) : (i.m &= -2, s || pn(i), i.l & 256 && Ye(T(i)), i.T?.fe ? (zt(i), n = !0) : Pe && i.rr?.st(), i.T !== null && (i.T.fe = !1), !i.o && i.l & 32 && (r ?? (r = [])).push(i), Be?.(i, e));
	}), r) for (let e of r) gn(e);
	n && k();
}
function xn(e) {
	return typeof e == "object" && !!e && typeof e.then == "function";
}
function Sn(e) {
	let t = e.T?.Se;
	t != null && (e.T.Se = null, t());
}
function Cn(t, n, r, i) {
	let a = !1, o = !1;
	if (typeof n == "object" && n && qn(() => {
		a = n[Symbol.asyncIterator], o = !a && xn(n);
	}), !o && !a) return t.T !== null && (t.T.Ee = null), t.Ie = !1, n;
	N(t).Ee = n, t.T.ce = ht || 2147483647, t.T.se = void 0;
	let s, c = (r) => {
		if (t.T?.Ee !== n) return;
		let a = r instanceof e;
		a && t.Ie ? (ln(t), fn(t, r), t.ie = O) : ((a || !vn(t, r)) && (En(t, a ? 1 : 2, r), a || ae(t, !1, !0)), a && bn(t), t.ie = O, a || _n(t), i?.(r, a));
	}, l = (e, i) => {
		if (t.T?.Ee !== n || t.R & 2) return;
		let a = ze && Et.some((e) => e.ue !== y), o = t.m & 4;
		if (Tn(t), r) {
			try {
				r(e);
			} catch (e) {
				c(e);
				return;
			}
			t.l & 256 || (t.T.Te = null, t.l &= ~m), o && Tn(t, !0);
		} else F(t, () => e);
		t.ue === y && (t.Ie = !1, Qt(t)), bn(t), k(), (i || !a) && Lt(), i?.();
	}, u = () => t.l & 32 && !t.o && !(t.m & 1) ? (nn(t), !0) : !1, d = (e, r) => {
		let i = e[Symbol.asyncIterator](), a = !1, o = !1, d = !r, f = () => {
			if (!o) {
				o = !0;
				try {
					let e = i.return?.();
					xn(e) && e.then(void 0, () => {});
				} catch {}
			}
		};
		pe(f, r), N(t).Se = f;
		let p = () => {
			try {
				u() || m();
			} catch (e) {
				c(e);
			}
		}, m = () => {
			let e, r, f = !1, h = !1, g = !0, _ = i.next();
			if ((xn(_) ? _ : { then: (e) => void e(_) }).then((r) => {
				if (g && d) e = r, f = !0, r.done && (o = !0);
				else if (t.T?.Ee !== n) return;
				else r.done ? (o = !0, a ? (k(), Lt()) : l(void 0), u()) : (a = !0, l(r.value, p));
			}, (e) => {
				g && d ? (r = e, h = !0) : t.T?.Ee === n && (o = !0, c(e), u());
			}), g = !1, h) {
				if (o = !0, c(r), d) throw r;
				return !0;
			}
			return f && !e.done ? (s = e.value, a = !0, m()) : f && e.done;
		}, h = m();
		return d = !1, a || h;
	}, f = null, p = (e, t) => {
		let n = !1;
		if (typeof e == "object" && e && qn(() => {
			n = e[Symbol.asyncIterator];
		}), !n) return !1;
		s = void 0;
		let r = d(e, t);
		return t || (f = r), !0;
	};
	if (o) {
		let e = !1, r = !1, i, a = !0;
		if (n.then((r) => {
			if (a) s = r, e = !0;
			else {
				try {
					if (t.T?.Ee === n && !(t.R & 64) && p(r, t)) return;
					l(r);
				} catch (e) {
					c(e);
				}
				u();
			}
		}, (e) => {
			a ? (i = e, r = !0) : (c(e), u());
		}), a = !1, r) throw c(i), i;
		e ? p(s) || (t.Ie = !1) : f = !1;
	}
	if (a && p(n), f !== null) {
		if (!f) {
			if (t.Ie) return t.le;
			throw new e(M);
		}
		t.Ie = !1;
	}
	return s;
}
function wn(e, t = !1) {
	e.T?.se && un(e), e.T?.fe && (e.T.fe = !1), e.m = t ? 0 : e.m & 4, e.T?.U && pn(e);
	let n = Bn(e);
	n && n.call(e);
}
function Tn(e, t = !1) {
	let n = e.T?.se;
	n && (n.delete(e), n.size) ? (e.T.fe = !1, t && (e.m = 1), pn(e, n.values().next().value)) : wn(e, t);
}
function En(n, r, i) {
	r === 2 && !(i instanceof t) && !(i instanceof e) && (i = new t(n, i));
	let a = r === 1 && i instanceof e && i.source;
	a ? (n.m & 2 && (n.T.Te = n.T.U), sn(n, a)) : un(n), n.m = r | (r === 2 ? n.m & 12 ? 8 : 0 : r === 1 && n.m & 8 ? 4 : n.m & 4), a ? pn(n, a, i) : N(n).U = i;
	let o = Bn(n);
	o ? o.call(n) : Dn(n, r, i);
}
function Dn(t, n, r) {
	let i = n === 1 && r instanceof e && r.source;
	mn(t, (e, a) => {
		e.ie = O, e.l & 16384 || n === 1 && a.Ne !== e.de ? (n !== 1 && cn(e, t) && bn(e, t), zt(e), k()) : i && e.T?.se?.has(i) ? C === null && (e.l & 2304) == 256 && A.Y && !Ae?.(e, i.ie === O) && Ye(T(e)) : (i || n !== 1 && (e.T?.U !== r || e.T?.se)) && (Ot(e), n !== 1 || (e.l & 2304) != 256 || e.i || Ye(T(e)), En(e, n, r), e.rr?.st(n, r));
	});
}
xt._e = (e) => {
	e.i === 3 ? (Ut(e, D), e.Ae = !0, A.enqueue(2, e.Z)) : e.R & 32 && !(e.R & 65536) ? ot(e) : kn(e);
}, xt.Ce = ae;
var j = !1, M = null, On;
function kn(t, n = !1) {
	At();
	let r = t.i, f, p = C, m = Se && (On = n && (p || On)), h = t.l & _;
	if (!n) {
		if (Ut(t, D), t.T !== null && (t.T.Ee = null, Sn(t)), t.l & 256) {
			let e = T(t);
			e.P || t.l & 524288 || (t.l & 8421376 ? e !== w && !(t.m & 4 || t.l & 1048576) && (t.ue !== y && jt(t), t.ue = y, t.l &= -257) : qe(e, Ae?.(t, t.m & 4)));
		}
		if (r === 3 || t.l & 128) {
			let e = en;
			tn(f = []), ae(t), tn(e);
		} else (t.pe !== null || t.ke !== null) && In(t);
		t.l & 2097152 && (t.ue = y, t.l ^= _);
	}
	let g = t.m & 4, v = t.m & 2 && t.T?.U, b = !!(t.m & 1) && t.T?.se, ee = t.T?.se?.has(t), te = !1, ne = !!(t.R & 8192) && !((t.m & 1 || t.ue !== y && !(t.R & 1024)) && t.T !== null && !t.T.Ve), re = M;
	M = t, t._ = null, t.de++;
	let ie = t.R & d;
	t.R = 4 | t.R & (32 | o), t.ie = O;
	let x = t.ue === y ? t.le : t.ue, oe = t.he, se = !1, ce = !1, le = j;
	j = !0;
	try {
		if (t.l & 64) x = t.X(x), t.T !== null && (t.T.Ee = null), t.Ie = !1;
		else {
			let e = t.T?.Ee, n = t.X(x), r = typeof n == "object" && !!n, i = t.T?.Ee !== e;
			x = i || !r ? n : Cn(t, n), !i && !r && (t.T !== null && (t.T.Ee = null), t.Ie = !1);
		}
		t.m === 0 && t.T === null || wn(t, n);
	} catch (n) {
		let r = n instanceof e;
		if (r && t.Ie) fn(t, n);
		else if ((r || !(te = vn(t, n, !0))) && (r && (N(t).fe = !0), En(t, r ? 1 : 2, n), r && ee && !t.T?.Ee && bn(t)), (r || te) && b) for (let e of b) e !== t && !(t.T?.se?.has(e) && (e.m & 1 || dn(t, e))) && bn(t, e);
	} finally {
		if (j = le, se = (t.R & a) !== 0, ce = !!(t.R & (m ? p || r || !(t.m & 1) ? 128 | s : 0 : 128)), t.R = t.R & (96 | i | s | c | l | u) | (n ? t.R & 256 : 0), M = re, f) for (let e of f) gn(e);
		t.T !== null && (t.T.Ve = ne && !!(t.m & 1));
	}
	if (t.R & 64) {
		$t(t), ln(t);
		return;
	}
	let ue = !!t.T?.U || te;
	if (!ue) {
		let e = t.ue === y, i = e ? t.le : t.ue, a = w ?? Ke, o = e && g && !r || !!t.T?.Te || !!(v && a) || !!h || !fr(t, i, x);
		if (r && o && !(t.R & 262144 && !t.Ae && Object.is(t.ge, x)) && e && (t.Ae = !t.T?.U, n || A.enqueue(r, t.W ?? (t.W = xt.q.bind(null, t)), null)), !ue) {
			if (o) (n ? !(a !== null && (ce || Fn(re)?.R & 128)) : r && t.ue === y) ? t.le = x : (t.ue = x, v && (t.T.Te = v), n && (st(t, a), t.m |= 4, Ae?.(t, !m && w))), t.o !== null && jt(t);
			else if (t.he != oe) for (let e = t.o; e !== null; e = e.t) Ht(e.u, D);
		}
		if (!o && !t.T?.U && (v && yn(t, v), b)) for (let e of b) e !== t && bn(t, e);
		ee && !(t.m & 5) && bn(t);
	}
	if (n && ce && t.m & 1) {
		let e = w ?? Ke;
		e && !e.P && (r && Ae?.(t) === 2 || st(t, e));
	}
	t.T?.U || t.ue !== y || r && t.Ae || (n || r === 3 ? Qt(t) : it(t)), (t.ue !== y || t.T !== null && (t.T.me !== null || t.T.Le !== null) || t.m & 5 && (!n || t.m & 1)) && (t.l |= 128, Ot(t)), se && (zt(t), k()), ie && gn(t);
}
function An(e) {
	if (!(e.R & 68)) {
		if (e.R & 1) for (let t = e.C; t; t = t.G) {
			let n = t.S;
			if (n.X && An(n), e.R & 2) break;
		}
		(e.R & 2 || e.T?.U && e.ie < O && !e.T?.Ee) && kn(e), e.R &= 376 | r | i | s | c | l | u;
	}
}
function jn(e, t) {
	let n = t?.transparent ?? !1, r = typeof t == "object" && !!t && "loadingValue" in t, i = {
		id: ue(t, n, M),
		l: (n ? 4 : 0) | !!t?.ownedWrite | (!M || t?.lazy ? 32 : 0) | (t?.sync ? 64 : 0) | (t?.ae ? 2 : 0) | (t?.xe ?? 0),
		ye: t?.equals ?? Wn,
		ke: null,
		A: M?.A ?? b,
		be: 0,
		X: e,
		le: r ? t.loadingValue : void 0,
		he: 0,
		ve: void 0,
		We: null,
		C: null,
		_: null,
		de: 0,
		o: null,
		Ze: null,
		_parent: M,
		Ge: null,
		Me: null,
		pe: null,
		R: t?.lazy ? 512 : 0,
		m: r ? 0 : 4,
		ie: O,
		ue: y,
		we: -1,
		Ie: r,
		T: null
	};
	return t?.unobserved && (N(i).Ye = t.unobserved), Hn(i, t), i;
}
function N(e) {
	return e.T ?? (e.T = {
		Ee: null,
		Se: null,
		U: void 0,
		fe: void 0,
		se: void 0,
		Ye: void 0,
		De: void 0,
		me: null,
		Le: null,
		Re: null,
		Ve: !1,
		je: y,
		Be: -1,
		ce: 0,
		Ue: !1,
		I: 0,
		Te: null
	});
}
function Mn(e, t) {
	e.R |= 128, (t.m & 4 || e.i !== 1) && qe(T(t), !e.i && e.m & 4 || Ae?.(e));
}
function Nn(e, t) {
	let n = Re && e.l & 32768, r = Se && C !== null;
	if (!(n && He(e, t)) && !((!r || e.m & 4 && t.m & 1) && !n && (!(e.l & 1 << 23) || t.l & 1024))) {
		let i = T(t);
		if (r && C.over && E(C.over) === i && !n) return !1;
		if (!(!r && i === w && !n || Pn(e, i))) return Dt(e, i), (r || n) && Oe(e, t), !0;
	}
	return Mn(e, t), !1;
}
function Pn(e, t) {
	return (e.m & 4 || e.l & 1048576) && e.l & 256 && T(e) === t;
}
function Fn(e) {
	return e !== null && e.Qe ? e.Ke : e;
}
function In(e) {
	ne(e);
	let t = N(e);
	t.Le = e.ke, t.me = e.pe, e.ke = null, e.pe = null, e.be = 0;
}
function Ln(e, t, n, r, i) {
	let a = i?.transparent ?? !1, o = {
		id: ue(i, a, M),
		l: r << 23 | (a ? 4 : 0) | !!i?.ownedWrite | (i?.sync ? 64 : 0) | (i?.xe ?? 0),
		ye: !1,
		ke: null,
		A: M?.A ?? b,
		be: 0,
		X: e,
		le: void 0,
		he: 0,
		ve: void 0,
		We: null,
		C: null,
		_: null,
		de: 0,
		o: null,
		Ze: null,
		_parent: M,
		Ge: null,
		Me: null,
		pe: null,
		R: 512,
		m: 4,
		ie: O,
		ue: y,
		we: -1,
		Ie: !1,
		Ae: !1,
		ge: void 0,
		qe: t,
		Je: n,
		ze: void 0,
		i: r,
		T: null
	};
	return i?.unobserved && (N(o).Ye = i.unobserved), Hn(o, Vn), o;
}
var Rn = null;
function zn(e) {
	Rn = e;
}
function Bn(e) {
	return e.i ? Rn : null;
}
var Vn = { lazy: !0 };
function Hn(e, t) {
	e.We = e;
	let n = M?.Qe ? M.Ke : M;
	M && oe(M, e), n && (e.he = n.he + 1), Ue?.(e), !t?.lazy && kn(e, !0);
}
function Un(e, t) {
	let n = {
		ye: t?.equals ?? Wn,
		l: +!!t?.ownedWrite | (t?.ae ? 2 : 0),
		le: e,
		o: null,
		Ze: null,
		ie: O,
		ue: y,
		we: -1,
		T: null
	};
	return t?.unobserved && (N(n).Ye = t.unobserved), n;
}
function Wn(e, t) {
	return e === t;
}
function Gn(e, t, n, r, i) {
	return {
		ye: t,
		l: 1 | h,
		le: e,
		o: null,
		Ze: null,
		ie: O,
		ue: y,
		we: -1,
		T: null,
		O: n,
		Xe: r,
		acc: i,
		px: void 0,
		pxv: void 0
	};
}
var Kn = null;
function qn(e, t) {
	let n = j;
	j = !1;
	try {
		return e();
	} finally {
		j = n;
	}
}
var Jn = 0;
function Yn(e, t) {
	if (e.R & 512) e.R &= -513, kn(e, !0);
	else if (e.R & 64 && e.l & 32) {
		let t = e._parent;
		if (t !== null) {
			if (t.R & 64) {
				e.l &= -33;
				return;
			}
			e.R & 32 || oe(t, e);
		}
		kn(e, !0);
	}
}
function Xn(e, t) {
	return !t || e.ue === y || t.l & 16;
}
var Zn = !1;
function Qn() {
	Zn = !0;
}
function $n(e) {
	return A.Y || e.ue === y || e.l & 4194304 ? y : e.l & 256 ? e.T.Be === O ? e.T.je : y : e.le;
}
function er(e) {
	let t = e.T;
	t.Be !== O && (t.je = e.ue, t.Be = O, Zn = !0);
}
var tr = [];
function nr(e) {
	return e.R |= a, !0;
}
function rr() {
	if (Zn = !1, tr.length !== 0) {
		for (let e of tr) e.l &= ~v;
		tr.length = 0;
	}
}
function ir(e, t) {
	e.he >= D.Fe || e.R & 1 ? (Gt(t), Wt(D), An(e)) : t.l & 65536 && An(e);
	let n = e.he;
	e._parent === t ? e.R |= f : n >= t.he && Jt(t, t.he = n + 1);
}
function ar() {
	return M.R & i;
}
function P(e) {
	let t = M;
	if (t?.Qe && (t = t.Ke), Kn !== null) return Kn(e, t);
	if (typeof e.X == "function" && Yn(e), !e.X && e.T?.De === void 0 && (!Zn || e.ue === y) && !(e.l & 2048)) return t && (j && on(e, t), e.l & 256 && !(t.l & 16) && Nn(t, e)) || !t || e.ue === y || t.l & 16 || e.ue === e.le && Object.is(e.ue, e.le) ? e.le : (cr(t), e.ue);
	let n = !1;
	if (t && (j && (on(e, t), e.X && ir(e, t)), e.l & 256 && !(e.l & 2048) && !(t.l & 16) && (e.m & 4 ? Mn(t, e) : n = Nn(t, e))), e.m & 1 && !n) {
		if (t) {
			if (!(t.l & 16) || e.m & 4) throw !j && e !== t && on(e, t), e.T?.U;
		} else if (e.m & 4) throw e.T?.U;
	}
	if (e.X && e.m & 2) {
		if (j && e.ie < O && !(e.R & 32)) return kn(e), P(e);
		throw !n && e.l & 2097152 && sr(e, t), e.T?.U;
	}
	(n || !t) && or(e);
	let r = sr(e, n ? null : t);
	return !t && typeof e.X == "function" && e.l & 32 && !(e.m & 1) && !e.o && (rn.add(e), k()), r;
}
function or(e) {
	if (e.T?.Te) throw e.T.Te;
}
function sr(t, n) {
	if (t.ue !== y && t.m & 4 && (!n || n.l & 16)) {
		if (Jn > 0) {
			let e = Fn(M);
			if (e && t.l & 256 && Pn(e, T(t))) return t.ue;
		}
		throw new e(null);
	}
	let r = n && Zn ? $n(t) : y;
	if (r !== y) return nr(n), r;
	if (Xn(t, n)) return t.le;
	if (cr(n, t), t.l & 2097152) throw t.ue;
	return t.ue;
}
function cr(e, t) {
	t?.m & 4 || (e.R |= s);
}
function lr(e, t) {
	return w === null || Pn(e, w) || (t?.l & 2304) == 256 ? !1 : (Dt(e, w), !0);
}
function ur(e) {
	A.Y || e.l & 4194304 || (e.l |= v, tr.push(e));
}
var dr = null;
function fr(t, n, r) {
	if (t.ye === Wn) return n === r;
	try {
		return t.ye && t.ye(n, r);
	} catch (n) {
		if (!(n instanceof e)) return En(t, 2, n), !0;
	}
}
function F(e, t) {
	dr !== null && dr(e);
	let n = e.ue === y ? e.le : e.ue;
	if (typeof t == "function" && (t = t(n)), e.l & 256 && Ye(T(e)), !(e.m & 4 || e.T?.Te || !fr(e, n, t))) return t;
	let r = e.ue !== y;
	return r ? e.l & 256 && !A.Y && er(e) : Ot(e), e.ue = t, M !== null && ur(e), e.X !== void 0 && (e.ie = O), r && e.we === kt || (jt(e), k()), t;
}
function pr(e, t) {
	let n = e.l & 256 && !(e.R & 1024) && T(e) !== w;
	if (n && typeof t == "function") {
		let n = t(e.le);
		t = () => n;
	}
	return e.m & 2 && (e.T.Te = e.T.U, En(e, 0)), t = F(e, t), e.l &= ~_, n ? (e.R = e.R & -2 | 2, Vt(e, D), k()) : e.ue !== y && (e.R |= r), t;
}
function mr(e, t) {
	let n = M, r = j;
	M = e, j = !1;
	try {
		return t();
	} finally {
		M = n, j = r;
	}
}
function hr(e, t = !0) {
	try {
		return e();
	} finally {}
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/identities.js
var gr = null;
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/effect.js
function _r(e, t, n, r) {
	let i = Ln(e, t, n, r?.user ? 2 : 1, r);
	kn(i, !0), r?.defer ? Nt(i) : i.ue === y && (i.T?.Re?.P || i.i === 2 || r?.schedule ? A.enqueue(i.i, br.bind(null, i), i.T?.Re) : br(i, 0));
}
function vr() {
	let e = this.m, t = this.T?.U;
	if (e & 2) {
		if (A.notify(this, 1, 0), this.i === 2) {
			this.m & 2 && Mt(this);
			return;
		}
		yr(this, n(t));
	} else this.i === 2 ? e & 1 && this.Ae && !t?.source?.T?.Ve && (N(this).fe = !(this.Ae = !1)) : this.i === 1 && A.notify(this, 3, e, t);
}
function yr(e, t, n) {
	if (!A.notify(e, 2, 2)) throw yt(t), t;
}
function br(e, r) {
	if (!e.Ae || e.R & 64 || r && Ne?.(e) || r && Ve?.(e)) return;
	if (e.m & 2 && e.i === 2) {
		let t = n(e.T?.U);
		e.ge = e.le, e.Ae = !1;
		try {
			e.Je ? e.Je(t, () => {
				let t = e.ze;
				e.ze = void 0, t?.();
			}) : console.error(t);
		} catch (t) {
			yr(e, t);
		}
		return;
	}
	let i = e.T?.U == null, a = e.ze;
	e.ze = void 0;
	try {
		a?.(), e.ze = e.qe(e.le, e.ge);
	} catch (n) {
		N(e).U = new t(e, n), e.m |= 2, yr(e, n);
	} finally {
		e.ge = e.le, e.Ae = !1, i && Qt(e);
	}
}
xt.q = br;
function xr(e, t) {
	let n = !1, r, i = () => {
		if (!a.Ae || a.R & 64 || Ne?.(a)) return;
		let e = kt;
		n = !1;
		try {
			a.Ae = !1, kn(a);
		} finally {}
		for (let t = a.C; t !== null; t = t.G) {
			let o = t.S;
			if (o.ue !== y && !(o.l & 2048) && (o.ue !== o.le || !Object.is(o.ue, o.le))) {
				if (o.l & 256) n || (n = !0, T(o).rn[1].push(r || (r = () => {
					n && (a.Ae = !0, i());
				})));
				else if (o.we <= e || o.X) {
					zt(a), k();
					break;
				}
			}
		}
	}, a = jn(() => {
		let t = a.ze;
		a.ze = void 0, t?.();
		let n = hr(e);
		a.ze = n;
	}, {
		...t,
		lazy: !0
	});
	a.ze = void 0, a.l = a.l & -33 | 16, a.Ae = !0, a.i = 3, a.Z = i, zt(a), k();
}
zn(vr);
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/store/types.js
var Sr = Symbol(0), Cr = Symbol(0), I = Symbol(0), wr = Symbol(0), Tr = Symbol(0), Er = /* @__PURE__ */ new WeakSet(), Dr = !1;
function Or(e) {
	return Dr && Er.has(e);
}
function kr(e) {
	if (L(e)) {
		if (e[I] !== void 0) return;
		Dr = !0, Er.add(e);
	}
}
function Ar(e) {
	if (Array.isArray(e)) for (let t = 0, n = e.length; t < n; t++) kr(e[t]);
	else for (let t in e) kr(e[t]);
}
var jr = Object.prototype, Mr = /* @__PURE__ */ new WeakMap();
function L(e) {
	if (typeof e != "object" || !e || Object.isFrozen(e)) return !1;
	let t = Object.getPrototypeOf(e);
	if (t === jr || t === null || Array.isArray(e)) return !0;
	let n = Mr.get(t);
	return n === void 0 && (n = Object.prototype.toString.call(e) === "[object Object]" && (typeof Node > "u" || !(e instanceof Node)), Mr.set(t, n)), n;
}
var R = !1;
function Nr(e) {
	R = e;
}
var Pr = null;
function Fr(e) {
	Pr = e;
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/signals.js
function Ir(e) {
	let t = P.bind(null, e);
	return t[ee] = e, t;
}
function Lr(e, t) {
	if (typeof e == "function") {
		let n = jn(e, t);
		return n.l &= -33, [Ir(n), pr.bind(null, n)];
	}
	let n = Un(e, t);
	return gr !== null && gr(n), [Ir(n), F.bind(null, n)];
}
function Rr(e, t) {
	return Ir(jn(e, t));
}
function zr(e, t, n) {
	_r(e, t.effect || t, t.error, {
		user: !0,
		...n
	});
}
function Br(e, t, n) {
	_r(e, t, void 0, n);
}
function Vr(e) {
	let t = fe();
	t && !(t.l & 16) ? xr(() => qn(e), void 0) : A.enqueue(2, function t() {
		if (D.Et >= D.Fe) return A.enqueue(2, t);
		e();
	});
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/map.js
function Hr(e, t, n) {
	let r = typeof n?.keyed == "function" ? n.keyed : void 0, i = t.length > 1, a = t, o = {
		H: ge(),
		it: 0,
		st: e,
		ot: [],
		ft: a,
		ht: [],
		ln: [],
		Xe: r,
		ct: r || n?.keyed === !1 ? [] : void 0,
		lt: i && n?.keyed !== !1 ? [] : void 0,
		ut: n?.keyed === !1,
		L: n?.fallback
	}, s = jn(Yr.bind(o), void 0);
	return s.l &= -33, Ir(s);
}
var Ur = { ownedWrite: !0 };
function Wr(e, t, n, r) {
	let i = e.ot, a = e.it - 1, o = [], s = [], c = [], l = 256, u = r, d = r;
	for (; u <= a && d <= n - 1;) {
		let e = i[u], r = t[d];
		if (e === r) {
			let e = u;
			do
				d++;
			while (++u <= a && d < n && i[u] === t[d]);
			c.push(e, d - u + e, u - e);
			continue;
		}
		let f = -1, p = Math.min(32 - o.length, a - u, l);
		for (let e = 1; e <= p; e++) if (i[u + e] === r) {
			f = e;
			break;
		}
		l -= f === -1 ? p : f;
		let m = -1;
		p = Math.min(32 - s.length, n - 1 - d, l);
		for (let n = 1; n <= p; n++) if (t[d + n] === e) {
			m = n;
			break;
		}
		if (l -= m === -1 ? p : m, f !== -1 && (m === -1 || f <= m)) for (; f-- > 0;) o.push(u++);
		else if (m !== -1) for (; m-- > 0;) s.push(d++);
		else {
			if (l <= 0 || o.length === 32 || s.length === 32) return !1;
			o.push(u++), s.push(d++);
		}
	}
	for (; u <= a; u++) {
		if (o.length === 32) return !1;
		o.push(u);
	}
	for (; d <= n - 1; d++) {
		if (s.length === 32) return !1;
		s.push(d);
	}
	return Gr(e, t, n, r, o, s, c);
}
function Gr(e, t, n, r, i, a, o) {
	let s = e.ot, c, l, u;
	if (a.length !== 0) for (u = Array(i.length), l = 0; l < a.length; l++) {
		let e = -1;
		for (c = 0; c < i.length; c++) if (!u[c] && s[i[c]] === t[a[l]]) {
			e = c;
			break;
		}
		if (e === -1) return !1;
		u[e] = !0, a[l] = a[l] << 6 | e;
	}
	for (c = 0; c < i.length; c++) {
		let e = s[i[c]];
		if (e === void 0) return !1;
		for (l = r - 1; (l = s.indexOf(e, l + 1)) !== -1;) if (!i.includes(l)) return !1;
	}
	let d = e.ht, f = e.ln, p = d.slice(0, n), m = f.slice(0, n);
	for (let e = 0; e < o.length; e += 3) {
		let t = o[e], n = o[e + 1];
		if (t !== n) for (let r = 0; r < o[e + 2]; r++) p[n + r] = d[t + r], m[n + r] = f[t + r];
	}
	for (l = 0; l < a.length; l++) {
		let e = a[l] >> 6, t = i[a[l] & 63];
		p[e] = d[t], m[e] = f[t];
	}
	for (e.ht = p, e.ln = m, e.it = n, e.ot = t, c = 0; c < i.length; c++) u !== void 0 && u[c] || f[i[c]].dispose();
	return !0;
}
function Kr(e, t, n, r, i, a, o, s, c) {
	let l = e.Xe, u = e.ot, d = e.ln, f = [], p = n;
	for (let m = n; m <= i; p++, m++) {
		let i = l ? l(t[m]) : t[m];
		for (; p <= r && (l ? l(u[p]) : u[p]) !== i;) f.push(d[p++]);
		if (p > r) return o.fill(void 0), null;
		a[m] = e.ht[p], o[m - n] = d[p], s && (s[m - n] = e.ct[p]), c && (c[m - n] = e.lt[p]);
	}
	for (; p <= r; p++) f.push(d[p]);
	return f;
}
function qr(e, t, n, r, i, a, o, s, c) {
	let l = e.ln, u = e.ct, d = e.lt, f = e.it, p = n - f, m, h;
	if (p > 0) for (l.length = n, u && (u.length = n), d && (d.length = n), m = f - 1, h = n - 1; m > i; m--, h--) l[h] = l[m], u && (u[h] = u[m]), d && (d[h] = d[m]);
	else if (p < 0) {
		for (m = i + 1, h = a + 1; m < f; m++, h++) l[h] = l[m], u && (u[h] = u[m]), d && (d[h] = d[m]);
		l.length = n, u && (u.length = n), d && (d.length = n);
	}
	for (h = r; h <= a; h++) l[h] = o[h - r], u && Jr(u[h] = s[h - r], t[h]), d && F(d[h] = c[h - r], h);
	for (h = a + 1; h < n; h++) u && Jr(u[h], t[h]), d && p !== 0 && F(d[h], h);
}
var Jr = (e, t) => e.le === t && e.ue === y || F(e, t);
function Yr() {
	this.H.Ke = fe();
	let e = this.st() || [];
	e[Sr], e = Pr?.(e[I]) ?? e;
	let t = e.length;
	return mr(this.H, Xr.bind(this, e, t)), this.ht;
}
function Xr(e, t) {
	let n = e.slice(0), r, i, a, o, s, c = this.ct ? this.ut ? () => (o[a] = Un(n[i], Ur), this.ft(Ir(o[a]), i)) : () => (o[a] = Un(n[i], Ur), s && (s[a] = Un(i, Ur)), this.ft(Ir(o[a]), s ? Ir(s[a]) : void 0)) : this.lt ? () => {
		let e = n[i];
		return s[a] = Un(i, Ur), this.ft(e, Ir(s[a]));
	} : () => {
		let e = n[i];
		return this.ft(e);
	};
	if (t === 0) this.it !== 0 && (this.H.dispose(!1), this.ln = [], this.ot = [], this.ht = [], this.it = 0, this.ct && (this.ct = []), this.lt && (this.lt = [])), this.L && !this.ht.length && (this.ln[0]?.dispose(), this.ht[0] = mr(this.ln[0] = ge(), this.L));
	else if (this.it === 0) {
		let e = Array(t), l = Array(t);
		o = this.ct && Array(t), s = this.lt && Array(t);
		try {
			for (i = 0; i < t; i++) a = i, e[i] = mr(l[i] = ge(), c);
		} catch (e) {
			for (r = 0; r <= i; r++) l[r]?.dispose();
			throw e;
		}
		this.ln[0] && this.ln[0].dispose(), this.ht = e, this.ln = l, o && (this.ct = o), s && (this.lt = s), this.ot = n, this.it = t;
	} else {
		let e, l, u, d, f, p, m, h, g;
		for (e = 0, l = Math.min(this.it, t); e < l && (this.ot[e] === n[e] || this.ct && Zr(this.Xe, this.ot[e], n[e])); e++) this.ct && Jr(this.ct[e], n[e]);
		for (l = this.it - 1, u = t - 1; l >= e && u >= e && (this.ot[l] === n[u] || this.ct && Zr(this.Xe, this.ot[l], n[u])); l--, u--);
		if (e === t && this.it === t) {
			this.ot = n;
			return;
		}
		if (t <= this.it && l - e > 64 && this.ct === void 0 && this.lt === void 0) {
			let r = e + (u - e >> 1), i = n[r], a = Math.min(l, r + 32), o = Math.max(e, r - 32);
			for (; o <= a && this.ot[o] !== i;) o++;
			if (o <= a && Wr(this, n, t, e)) return;
		}
		let _ = t - this.it, v = u - e + 1, y = Array(t), b = Array(v);
		o = this.ct ? Array(v) : void 0, s = this.lt ? Array(v) : void 0;
		let ee = _ < 0 ? Kr(this, n, e, l, u, y, b, o, s) : null;
		if (ee !== null) ee.length !== 0 && (h = ee);
		else {
			for (p = /* @__PURE__ */ new Map(), m = Array(v), i = u; i >= e; i--) d = n[i], f = this.Xe ? this.Xe(d) : d, r = p.get(f), m[i - e] = r === void 0 ? -1 : r, p.set(f, i);
			for (r = e; r <= l; r++) d = this.ot[r], f = this.Xe ? this.Xe(d) : d, i = p.get(f), i !== void 0 && i !== -1 ? (y[i] = this.ht[r], b[i - e] = this.ln[r], o && (o[i - e] = this.ct[r]), s && (s[i - e] = this.lt[r]), i = m[i - e], p.set(f, i)) : (h ?? (h = [])).push(this.ln[r]);
			try {
				for (i = e; i <= u; i++) b[i - e] === void 0 && ((g ?? (g = [])).push(b[i - e] = ge()), a = i - e, y[i] = mr(b[i - e], c));
			} catch (e) {
				if (g) for (r = 0; r < g.length; r++) g[r].dispose();
				throw e;
			}
		}
		for (r = 0; r < e; r++) y[r] = this.ht[r];
		for (i = u + 1; i < t; i++) y[i] = this.ht[i - _];
		if (qr(this, n, t, e, l, u, b, o, s), this.ht = y, this.it = t, this.ot = n, h) for (r = 0; r < h.length; r++) h[r].dispose();
	}
}
function Zr(e, t, n) {
	return !e || e(t) === e(n);
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/store/target.js
var z = Symbol(0), Qr = /* @__PURE__ */ new WeakMap();
function $r(e, t) {
	(t.rr?.map ?? Qr).set(e, t);
}
function ei(e) {
	return e[z] !== void 0;
}
function ti(e, t) {
	let n = e[z];
	return n !== void 0 && n.rr === t ? n : (t?.map ?? Qr).get(e);
}
function ni(e) {
	let t = e;
	for (; t && !t.d;) t.d = !0, t = t.u;
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/store/hooks.js
var B = null, ri = null, ii = Symbol(0);
function ai(e, t, n, r) {
	this.v = e, this.ch = e[I] !== void 0, this.pb = null, this.n = null, this.h = null, this.k = null, this.dk = null, this.u = t, this.pk = n, this.px = null, this.d = !1, this.a = !1, this.sc = 0, this.kc = 0, this.nc = 0, this.rr = r, this.o = r !== null && r.opt === !0, this.s = !1, this.ovl = !1, this.del = null, this.wk = null;
}
function oi(e, t, n, r = t?.rr ?? null) {
	let i = new ai(e, t, n, r);
	return i.px = new Proxy(Array.isArray(e) ? [] : {}, i), $r(e, i), i;
}
function V(e, t = null, n = null, r = t?.rr ?? null) {
	if (Dr && Or(e)) return e;
	let i = ti(e, r);
	if (i !== void 0) return i.px;
	let a = e[I];
	return a?.px === e && (r === null || a.rr === r) ? e : oi(e, t, n, r).px;
}
function H(e) {
	if (typeof e != "object" || !e) return e;
	let t = e[I];
	return t !== void 0 && (t.px === e || ti(e, t.rr) === t) && t.v !== void 0 ? (t.ovl && zi(t), t.pb ?? t.v) : e;
}
var si = function(e, t) {
	return Wn(e, t) || ui(this.O, e, t);
};
function ci(e, t) {
	return e === t || e !== e && t !== t;
}
var li = function(e, t) {
	return e === t;
};
function ui(e, t, n) {
	if (typeof t != "object" || !t || typeof n != "object" || !n) return !1;
	let r = ti(t, e.rr);
	return r !== void 0 && r === ti(n, e.rr);
}
var di = /* @__PURE__ */ new Set();
function fi(e) {
	let t = e.O, n = e.Xe;
	if (n === Sr) t.k === e && (t.k = null);
	else if (n === Cr) return;
	else n === ii ? t.dk === e && (t.dk = null) : t.n?.[n] === e ? (delete t.n[n], t.nc--) : t.h?.[n] === e && delete t.h[n];
	t.rr !== null && t.nc === 0 && t.k === null && t.dk === null && (t.h === null || Reflect.ownKeys(t.h).length === 0) && t.rr.live.delete(t);
}
function pi(e, t, n) {
	e.rr !== null && e.rr.live.add(e), ni(e), ri !== null && ri.ro(e, t, n);
}
var mi = (e) => e.ue !== y || e.l & 2048 || e.O.k?.l & 256;
Xt((e) => {
	mi(e) ? di.add(e) : fi(e);
});
function hi(e, t, n, r) {
	if (t.ye && t.ye(t.le, n)) return;
	Ot(t), t.ue = n;
	let i = e.k;
	if (i !== null) {
		if (i.l & 256 && Da(e, r)) {
			let e = T(i);
			(!(i.l & 2048) || e.folded) && st(t, E(e._parent ?? e));
		}
		i.l & 4194304 && ur(t);
	}
}
function gi(e, t, n = -1) {
	let r = e.n ?? (e.n = Object.create(null)), i = r[t];
	if (i === void 0) {
		let a = e.pb, o = i = Gn(wa(e)[t], si, e, t, n === -1 ? Oi(a ?? e.v, t) : n === 1);
		a !== null && !o.acc && hi(e, o, e.del?.has(t) ? void 0 : a[t], t), r[t] = i, e.nc++, pi(e, o, t);
	}
	return i;
}
function _i(e, t) {
	let n = e.h ?? (e.h = Object.create(null)), r = n[t];
	if (r === void 0) {
		let i = r = Gn(t in wa(e), Wn, e, t, !1), a = e.pb;
		a !== null && hi(e, i, t in a && !e.del?.has(t), t), n[t] = r, pi(e, i, t);
	}
	return r;
}
function vi(e) {
	let t = e.k;
	return t === null && (t = e.k = Gn(e.v, li, e, Sr, !1), pi(e, t, Sr), e.pb !== null && !ea && (t.le = Qi(e), t.ue = e.pb, Ot(t))), t;
}
function yi(e, t) {
	if (e.k === null && C === null && (M === null || A.Y) && !bi(e)) return;
	let n = vi(e);
	n.ue === y && Ot(n), n.ue = t, M !== null && ur(n), e.rr !== null && !W && za(e, n);
}
function bi(e) {
	let t = e.rr?.node;
	return t != null && !W && !!(t.l & 256);
}
var xi = (e) => {
	for (let t = 0; t < Ki.length; t++) {
		let n = Ki[t];
		n.k === null && n.pb !== null && st(vi(n), e);
	}
	B?.park(e);
};
function Si(e, t) {
	(e.l & 10240) == 10240 ? F(e, t) : (e.l & 256 && Ye(T(e)), jt(e), k());
}
var U = Object.prototype.hasOwnProperty, Ci = Object.getPrototypeOf, wi = Object.setPrototypeOf, Ti = Object.prototype.__lookupGetter__, Ei = Object.prototype.__lookupSetter__, Di = Object.prototype.propertyIsEnumerable;
function Oi(e, t) {
	return U.call(e, t) && (Ti.call(e, t) !== void 0 || Ei.call(e, t) !== void 0);
}
function ki(e, t) {
	if (t.sc || Mi(t), t.sc === 2) {
		let n = { ...e };
		return n[z] = t, n;
	}
	let n;
	if (!t.a && t.kc <= e.length + 1 && Ci(e) === Array.prototype) n = e.slice();
	else {
		let r = Object.getOwnPropertyDescriptors(e);
		for (let n of Reflect.ownKeys(r)) {
			let i = r[n];
			n === "length" && Array.isArray(e) || (i.configurable = !0, !i.get && !i.set ? i.writable = !0 : t.a = !0);
		}
		n = Object.defineProperties(Array.isArray(e) ? wi([], Ci(e)) : Object.create(Ci(e)), r);
	}
	return n[z] = t, n;
}
function Ai(e, t) {
	let n = Object.create(null);
	for (let t of Reflect.ownKeys(e)) n[t] = e[t];
	return wi(n, Object.prototype), n[z] = t, n;
}
function ji(e, t, n) {
	let r = Object.getOwnPropertyDescriptor(t, n);
	r.get || r.set || !r.enumerable || !r.writable || !r.configurable ? Object.defineProperty(e, n, r) : e[n] = r.value;
}
function Mi(e) {
	let t = e.v, n = Reflect.ownKeys(t), r = Ci(t) === Object.prototype;
	for (let i of n) {
		if (Oi(t, i)) {
			e.a = !0, r = !1;
			break;
		}
		r && !Di.call(t, i) && (r = !1);
	}
	return e.sc = r ? 2 : 1, e.kc = n.length, !e.a;
}
var Ni = 32, Pi = 1024, Fi = 16, Ii = /* @__PURE__ */ new Set(), Li = (e) => {
	let t = Ci(e);
	return t === Object.prototype || t === Array.prototype || t === null;
};
function Ri(e, t) {
	if (e.kc > Pi) return !1;
	if (e.del?.size) return !0;
	let n = e.wk;
	if (n !== null && n !== Ii && n.u === void 0 && n.size <= Fi) return !1;
	let r = e.v, i = 0;
	for (let e of Reflect.ownKeys(t)) if (!U.call(r, e) && ++i > Fi) return !0;
	return !1;
}
function zi(e) {
	let t = e.pb;
	if (!e.ovl) return t;
	let n = Wi(e, e.sc === 2 ? Ai(e.v, e) : ki(e.v, e), t);
	return e.pb = n, e.k?.ue === t && (e.k.ue = n), n;
}
function Bi(t) {
	let n = t.pb;
	if (B !== null && t.o && W && !ba.has(t)) return t.pb = B.draft(t);
	if (n !== null && !ei(n)) {
		n = t.pb = ki(n, t);
		let e = t.k;
		e !== null && !(e.l & 256) && (e.ue = n);
	} else if (n === null) {
		let r = t.v;
		if (ea || Zi(t), !t.ch && !Array.isArray(r) && (t.sc === 0 ? Mi(t) : !t.a) && t.kc > Ni && ei(r)) n = t.pb = Object.create(r), t.ovl = !0;
		else try {
			n = t.pb = ki(r, t);
		} catch (t) {
			if (!(t instanceof e)) throw t;
			return {};
		}
		ea || yi(t, n);
	}
	return n;
}
function Vi(e) {
	if (ei(e.v)) return;
	let t = e.v;
	if (e.v = ki(t, e), e.ch = !1, e.u) {
		Vi(e.u);
		let n = e.u.v, r = Hi(e, t);
		n[r] === t && (n[r] = e.v);
	}
}
function Hi(e, t) {
	let n = e.pk, r = e.u.v;
	if (r[n] === t || r[n] === e.v || !Array.isArray(r)) return n;
	let i = r.indexOf(t);
	return i === -1 ? n : (e.pk = i, i);
}
function Ui(e, t) {
	Vi(e), Wi(e, e.v, t);
}
function Wi(e, t, n) {
	for (let r of Reflect.ownKeys(n)) e.sc === 2 ? t[r] = n[r] : ji(t, n, r);
	if (e.del !== null) {
		for (let n of e.del) delete t[n];
		e.kc -= e.del.size, e.del = null;
	}
	return e.ovl = !1, t;
}
function Gi(e, t, n = !0) {
	ea || Zi(e);
	let r;
	e.pb === null ? r = e.v : (e.ovl && zi(e), r = e.pb), ea ? (e.pb = null, e.k !== null && (e.k.le = t)) : (e.pb = t, yi(e, t)), e.v = t, e.ch = t[I] !== void 0, e.ovl = !1, e.del = null, e.sc = 0, e.a = !1, e.wk = null, t[z]?.rr === e.rr ? t[z] = e : $r(t, e), B !== null && e.o && B.judge(e, t), n && r !== t && _a(e, r, t);
}
var Ki = [], qi = [], Ji = [], Yi = [], Xi = null;
function Zi(e) {
	e.pb === null && (k(), Xi !== null && Xi.set(e, Ki.length), Ki.push(e), qi.push(e.v));
}
function Qi(e) {
	if (Xi === null) {
		Xi = /* @__PURE__ */ new Map();
		for (let e = 0; e < Ki.length; e++) Xi.set(Ki[e], e);
	}
	let t = Xi.get(e);
	return t === void 0 ? e.v : qi[t];
}
function $i() {
	if (Ki.length !== 0) {
		let e = Ki, t = qi;
		Ki = Ji, qi = Yi, Ji = e, Yi = t, Xi = null;
		for (let n = 0; n < e.length; n++) {
			let r = e[n];
			if (r.pb === null) continue;
			let i = r.k;
			i !== null && i.ue !== y ? (Ki.push(r), qi.push(t[n])) : na(r, t[n]);
		}
		e.length = 0, t.length = 0;
	}
	if (di.size !== 0) for (let e of di) e.o === null && !mi(e) && (di.delete(e), fi(e));
}
xt.k = (e) => !!((e.O?.rr)?.node?.m & 1), Ie(xi, () => {
	$i(), B?.sweep();
}), xt.so = gi, xt.fo = L;
var ea = !1;
function ta(e) {
	let t = ea;
	ea = !0;
	try {
		e();
	} finally {
		ea = t;
	}
}
function na(e, t) {
	{
		let n = e.k, r = e.pb;
		if (r !== null) {
			if (r !== e.v) {
				if (e.ovl && (e.v !== t || !Ri(e, r) && n?.T?.De !== t)) Ui(e, r);
				else if (e.v !== t) {
					Vi(e);
					let n = e.v, i = e.wk;
					if (i !== null && i !== Ii) for (let e = i; e !== void 0; e = e.u) for (let t of e) U.call(r, t) ? ji(n, r, t) : delete n[t];
					else {
						for (let e of Reflect.ownKeys(r)) e !== z && ji(n, r, e);
						for (let e of Reflect.ownKeys(t)) e !== z && !U.call(r, e) && delete n[e];
					}
				} else e.v = e.ovl ? zi(e) : r, e.ch = e.v[I] !== void 0;
			}
			e.pb = null, e.wk = null;
		}
		if (n !== null && (n.o === null ? e.k = null : n.le = e.v), e.v !== t && e.u) {
			let n = Hi(e, t);
			e.u.v[n] === t && (Vi(e.u), e.u.v[n] = e.v);
		}
	}
}
var ra = !1, W = !1;
function ia() {
	return W;
}
function aa(e, t, n) {
	if (e.rr === null || !W) return !1;
	if (t !== void 0) return (t.l & 262400) == 256 && T(t) !== w;
	let r = e.k;
	return r !== null && !!(r.l & 256) && T(r) !== w && Da(e, n);
}
function oa(e) {
	let t = e.pb;
	if (t === null) return;
	if (B !== null && e.o) {
		if (W) {
			e.pb = null, e.wk = null, e.pb = B.writes(e, t);
			return;
		}
		B.pair(e, t), B.judge(e, t);
	}
	let n = e.v, r = e.n, i = e.wk, a = i === Ii || e.a === !0 || !Li(e.ovl ? e.v : t) ? null : i;
	if (e.rr !== null && !ra && a !== null) {
		for (let t of a) if (aa(e, r?.[t], t)) {
			ra = !0;
			break;
		}
	}
	if (r !== null) {
		let i = a ?? Reflect.ownKeys(r);
		for (let a of i) {
			let i = r[a];
			if (i === void 0) continue;
			let o = !1;
			if (i.acc === !0 || (o = U.call(t, a)) && Ti.call(t, a) !== void 0) {
				i.acc = Oi(t, a);
				let e = Object.getOwnPropertyDescriptor(n, a), r = Object.getOwnPropertyDescriptor(t, a);
				if (!r || r.get || r.set) {
					(e?.get !== r?.get || e?.set !== r?.set || e?.value !== r?.value) && F(i, () => ca);
					continue;
				}
				(e?.get || e?.set || !Wn(e?.value, r.value)) && F(i, () => r.value);
				continue;
			}
			let s = o || !(e.del?.has(a) || a === "__proto__") ? t[a] : void 0;
			B !== null && e.o && B.covers(e, a, !1) ? sa(i, s) : (F(i, () => s), e.rr !== null && (W ? i.l |= g : (i.l &= ~g, za(e, i))));
		}
	}
	let o = e.h;
	if (o !== null) {
		let n = a ?? Reflect.ownKeys(o);
		for (let r of n) {
			let n = o[r];
			if (n !== void 0) {
				if (B !== null && e.o && B.covers(e, r, !0)) {
					sa(n, r in t && !e.del?.has(r));
					continue;
				}
				F(n, r in t && !e.del?.has(r)), e.rr !== null && !W && za(e, n);
			}
		}
	}
	let s = e.k;
	if (s !== null && (s.o !== null || s.l & 2048)) {
		let r;
		if (e.ovl) {
			if (r = !!e.del?.size, !r) {
				for (let e of Reflect.ownKeys(t)) if (!U.call(n, e)) {
					r = !0;
					break;
				}
			}
		} else r = Array.isArray(t) && Array.isArray(n) ? ua(n, t) : da(n, t);
		r && Si(s, t);
	}
}
function sa(e, t) {
	e.le = t, e.ue !== y && (e.ue = t);
}
var ca = Symbol();
function la(e, t) {
	if (typeof e != "object" || !e || typeof t != "object" || !t) return !1;
	let n = ti(e, null);
	return n !== void 0 && n === ti(t, null);
}
function ua(e, t) {
	if (e.length !== t.length) return !0;
	for (let n = 0; n < t.length; n++) {
		let r = e[n], i = t[n];
		if (!Wn(r, i) && !la(r, i)) return !0;
	}
	return !1;
}
function da(e, t) {
	let n = Reflect.ownKeys(t);
	if (Reflect.ownKeys(e).length - +ei(e) != n.length - +ei(t)) return !0;
	for (let t of n) if (t !== z && !(t in e)) return !0;
	return !1;
}
function fa(e, t) {
	let n = e.O;
	B !== null && n.o && B.covers(n, e.Xe, n.h?.[e.Xe] === e) ? sa(e, typeof t == "function" ? t() : t) : (F(e, t), C !== null && !W && e.O.rr !== null && za(e.O, e));
}
function pa(e, t, n, r, i = !0) {
	if (e.acc === !0 || i && U.call(r, t) && Ti.call(r, t) !== void 0) {
		e.acc = Oi(r, t);
		let i = Object.getOwnPropertyDescriptor(n, t), a = Object.getOwnPropertyDescriptor(r, t);
		if (!a || a.get || a.set) {
			(i?.get !== a?.get || i?.set !== a?.set || i?.value !== a?.value) && fa(e, () => ca);
			return;
		}
		let o = i?.value, s = a?.value;
		(i?.get || i?.set || !Wn(o, s) && !la(o, s)) && fa(e, typeof s == "function" ? () => s : s);
	} else {
		let i = n[t], a = r[t];
		(n[I] || !Wn(i, a) && !la(i, a)) && fa(e, typeof a == "function" ? () => a : a);
	}
}
function ma(e) {
	return e.acc === !0;
}
function ha(e, t, n, r, i, a) {
	e.acc === !0 ? pa(e, t, i, a, !1) : !Wn(n, r) && !la(n, r) && fa(e, typeof r == "function" ? () => r : r);
}
function ga(e, t, n) {
	let r = e.h, i = t[I];
	if (r !== null) for (let e of Reflect.ownKeys(r)) (i || e in t != e in n) && fa(r[e], e in n);
	let a = e.k;
	a !== null && (a.o !== null || a.l & 2048) && (i || (Array.isArray(n) && Array.isArray(t) ? ua(t, n) : da(t, n))) && Si(a, n);
}
function _a(e, t, n) {
	let r = e.n;
	if (r !== null) for (let e of Reflect.ownKeys(r)) pa(r[e], e, t, n);
	ga(e, t, n);
}
var va = 0, ya = null, ba = /* @__PURE__ */ new Set();
function xa(e) {
	if (e.rr !== null) return e.rr;
	let t = e;
	for (; t.u !== null;) t = t.u;
	return t;
}
function G(e) {
	return ya !== null && ya.has(xa(e));
}
function Sa(e, t, n) {
	return typeof n == "object" && n && n[I] !== void 0 ? Ca(e, V(n, e, t)) : n;
}
function Ca(e, t) {
	if (ya !== null && G(e)) {
		let e = t?.[I];
		e?.v !== void 0 && ya.add(xa(e));
	}
	return t;
}
function wa(e) {
	let t = e.k;
	return t === null ? e.pb === null ? e.v : Qi(e) : t.ue === y ? e.v : t.le;
}
function Ta() {
	let e = M;
	return e === null ? null : (e.Qe && (e = e.Ke ?? null), e === null || e.l & 16 ? null : e);
}
function Ea(e, t, n = !1) {
	if (B !== null && W && e.o && !ba.has(e) && G(e)) {
		let t = Bi(e);
		return ba.add(e), t;
	}
	let r = e.pb;
	if (r === null) return e.v;
	if (G(e) || R) {
		if (R && !W) {
			let n = t === void 0 ? void 0 : e.n?.[t];
			if (n !== void 0) (n.l & 2304) == 256 && qe(T(n));
			else {
				let n = e.k;
				n !== null && (n.l & 2304) == 256 && (t === void 0 || Da(e, t)) && qe(T(n));
			}
		}
		return r;
	}
	let i = e.k;
	if (t !== void 0) {
		let n = e.n?.[t];
		if (n?.l & 2048 && i?.T?.Re !== (n.T.Re || 0)) return wa(e);
	}
	let a = i !== null && !!(i.l & 256);
	if (a && t !== void 0 && !Da(e, t, n)) return r;
	let o = Ta();
	if (o === null) return S() !== null || Ma(e) ? r : Kn === null || !a && t !== void 0 && !Na(e, t, n) ? a ? i.le : e.v : i === null ? wa(e) : P(i);
	if (!a) {
		if (o.R & 16384 && !(o.l & 32784)) return r;
		if (t !== void 0 && !Na(e, t, n)) return wa(e);
		if (i === null) return o.l & 32768 && lr(o) ? wa(e) : (cr(o), r);
	}
	return qn(() => P(i));
}
function Da(e, t, n = !0) {
	return Pa(e, e.k.le, e.k.ue, t, n) && !ja(e, t);
}
var Oa = /* @__PURE__ */ new WeakMap();
function ka(e) {
	let t = Oa.get(e);
	return t === void 0 && Oa.set(e, t = new Set(Object.values(e))), t;
}
function Aa(e, t, n) {
	return typeof e == "object" && !!e && typeof t == "object" && !!t && (n === null || ci(n(e), n(t)));
}
function ja(e, t) {
	let n = e.k, r = n.le, i = r[t], a = n.ue[t], o = Array.isArray(r) ? e.rr?.key : null;
	if (e.s || o === void 0 || !Aa(i, a, o) || !L(i) || !L(a) || Array.isArray(i) !== Array.isArray(a) || ti(i, e.rr) !== void 0 || ti(a, e.rr) !== void 0 || ka(r).has(a) || ka(n.ue).has(i)) return !1;
	let s = V(i, e, t)[I];
	return s?.v === i && (Gi(s, a, !1), st(vi(s), T(n)), !0);
}
function Ma(e) {
	return e.rr !== null && M === null && !(e.k?.l & 256);
}
function Na(e, t, n = !0) {
	return Pa(e, wa(e), e.pb, t, n);
}
function Pa(e, t, n, r, i) {
	if (e.ch || n[I] !== void 0 || Ci(n) !== Ci(t) || !Li(t)) return !0;
	if (e.del?.has(r)) return r in t;
	let a = U.call(n, r) || e.ovl && U.call(e.v, r);
	if (a !== U.call(t, r)) return !0;
	if (!a) return !1;
	if ((i || e.a) && (Oi(t, r) || Oi(n, r) || Di.call(t, r) !== Di.call(n, r))) return !0;
	let o = n[r], s = t[r];
	return !Wn(s, o) && !ui(e, s, o);
}
function Fa(e, t, n) {
	let r;
	return e.ue !== y && !(e.l & 256) && n.rr !== null && (M === null || n.rr.node?.m & 4) ? (M !== null && j && on(e, M), r = e.ue) : r = P(e), r === ca ? t : r;
}
function Ia(e, t, n, r, i, a = -1) {
	let o = e.ch && r === e.v, s = n;
	if (!G(e) && !R && (i === void 0 && S() !== null && (i = gi(e, t, a)), i !== void 0)) {
		let t = Fa(i, n, e);
		o ? i.le = n : s = t;
	}
	if (e.s) return Sa(e, t, s);
	if (e.ch && !o && typeof s == "object" && s && s[I]?.px !== s && (s = Ba(e, t, s)), i !== void 0) {
		if (i.pxv === s && s !== void 0) return Ca(e, i.px);
		if (!L(s)) return s;
		let n = V(s, e, t);
		return i.px = n, i.pxv = s, Ca(e, n);
	}
	return L(s) ? Ca(e, V(s, e, t)) : s;
}
function La(e, t) {
	for (let n = t.o; n !== null; n = n.t) if (n.u === e) return !0;
	return !1;
}
function Ra(e) {
	let t = e.rr.node;
	if (!(t === null || R || G(e))) {
		if (t.m & 3 || t.l & 2097152) {
			if (Kn === null && t.m & 1 && B?.stands(e)) return;
			let n = M;
			if (n !== null && n.i === 1 && t.m & 1 && t.l & 256 && w !== T(t) && !La(n, t)) return;
			n?.C !== void 0 && t.l & 2097152 && on(t, n), P(t);
		} else {
			let e = M;
			e?.Qe && (e = e.Ke), e && ir(t, e), qn(() => P(t));
		}
	}
}
function za(e, t, n = C) {
	let r = e.rr?.node;
	r != null && r.l & 256 && t.ue !== y && !(t.l & 2304) && (st(t, T(r)), t.T.Ve = r.T.Ve);
}
function Ba(e, t, n) {
	let r = e.v[I];
	if (r.ch) {
		let e = Ba(r, t, n);
		return e === n ? n : V(e, r, t);
	}
	let i = ti(n, r.rr);
	return i === void 0 ? (r.v[t] === n || r.pb?.[t] === n) && L(n) ? V(n, r, t) : n : i.px;
}
function Va(e) {
	if (!G(e) && !R && S() !== null) {
		let t = P(vi(e));
		if (B !== null && e.o) {
			let t = B.frame(e);
			if (t !== y) return t;
		}
		return t;
	}
	let t = Ea(e);
	return Ha(e) ? B.view(e, t) : t;
}
function Ha(e) {
	return B !== null && e.o && !G(e) && !R;
}
var Ua = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]);
function Wa(e, t) {
	let n = e.wk;
	ba.has(e) || (ba.add(e), n !== null && n !== Ii && (n = /* @__PURE__ */ new Set(), n.u = e.wk, e.wk = n)), n !== Ii && (e.wk ?? (e.wk = /* @__PURE__ */ new Set())).add(t);
}
ai.prototype = {
	get(e, t, n) {
		let r = this;
		if (typeof t != "string") {
			if (t === I) return r;
			if (t === wr) return n;
			if (t === z || t === Tr) return;
			if (t === ee) return r.rr?.node ?? void 0;
			if (t === Sr) {
				if (r.rr !== null && Ra(r), !G(r) && S() !== null) {
					P(vi(r));
					let e = Ea(r);
					e[I] !== void 0 && e[Sr];
				}
				return;
			}
		}
		if (Kn !== null && ri !== null && S() === null && ri.io(r, t), r.rr !== null && Ra(r), B !== null && r.o && !R) {
			if (G(r)) B.drafted(r, t);
			else {
				let e = B.read(r, t);
				if (e !== y) return e;
			}
		}
		let i = r.n?.[t];
		if (ya === null && !R) {
			let e = i;
			if (e !== void 0 && e.acc !== !0 && !r.ch) {
				let n = Fa(e, void 0, r);
				if (typeof n != "object" || !n) return n;
				if (r.s) return Sa(r, t, n);
				if (e.pxv === n) return e.px;
				if (L(n)) {
					let i = V(n, r, t);
					return e.px = i, e.pxv = n, i;
				}
				return n;
			}
		}
		let a = Ea(r, t);
		if (a === r.pb && r.del?.has(t)) {
			!G(r) && S() !== null && P(gi(r, t));
			return;
		}
		let o = -1;
		{
			let e;
			if (i === void 0 ? !G(r) && S() !== null ? (e = Oi(a, t), a === (r.pb ?? r.v) && (o = +!!e)) : e = !1 : e = i.acc === !0, e) {
				!G(r) && S() !== null && P(i ?? gi(r, t, o));
				let e = Reflect.get(a, t, n);
				return r.s ? Sa(r, t, e) : L(e) ? Ca(r, V(e, r, t)) : e;
			}
		}
		let s = r.ovl && a === r.pb;
		if ((t === "constructor" ? R || G(r) : t === "__proto__" || t === "prototype") && !U.call(a, t) && !(s && U.call(r.v, t))) return;
		let c = a[t];
		if (c === void 0 && !U.call(a, t) && !(s && U.call(r.v, t))) {
			if (c = Reflect.get(a, t, n), typeof c == "function") return c;
			if (r.ch && a === r.v) return Ia(r, t, c, a, i, o);
			if (c === void 0 && !G(r)) {
				S() !== null && gi(r, t, o);
				let e = r.n?.[t];
				if (e) {
					let n = Fa(e, void 0, r);
					return r.s ? Sa(r, t, n) : L(n) ? Ca(r, V(n, r, t)) : n;
				}
			}
			return r.s ? Sa(r, t, c) : L(c) ? Ca(r, V(c, r, t)) : c;
		}
		return typeof c == "function" && !U.call(a, t) && !(s && U.call(r.v, t)) ? c : Ia(r, t, c, a, i, o);
	},
	has(e, t) {
		let n = this;
		if (t === I || t === wr || t === Sr) return !0;
		if (t === z || t === Tr) return !1;
		if (Kn !== null && ri !== null && S() === null && ri.io(n, t), n.rr !== null && Ra(n), B !== null && n.o && !R && G(n) && B.drafted(n, t, !0), Ha(n)) {
			let e = B.has(n, t);
			if (e !== void 0) return e;
		}
		let r = Ea(n, t);
		if (!G(n) && !R && S() !== null) {
			let e = _i(n, t), i = P(e);
			if (!n.ch || r !== n.v) return !!i;
			let a = t in r;
			return e.le = a, a;
		}
		return t in r && !(r === n.pb && n.del?.has(t));
	},
	ownKeys() {
		let e = this;
		return Kn !== null && ri !== null && S() === null && ri.io(e, void 0), e.rr !== null && Ra(e), B !== null && e.o && !R && G(e) && B.drafted(e, void 0, !0), Ja(e, Va(e));
	},
	getOwnPropertyDescriptor(e, t) {
		let n = this;
		if (t === z || t === Tr) return;
		let r = S();
		Kn !== null && ri !== null && r === null && ri.io(n, t), n.rr !== null && Ra(n);
		let i = r !== null && !G(n) && !R, a = i && Ga(n, r);
		if (!a && Ha(n)) {
			let r = B.descriptor(n, t, Array.isArray(e));
			if (r !== void 0) return r === null ? void 0 : r;
		}
		let o;
		if (a) o = Va(n);
		else if (i) {
			let e = P(_i(n, t));
			if (o = Ea(n, t, !0), !e && (!n.ch || !(t in o))) return;
		} else o = Ea(n, t, !0);
		let s;
		if (s ?? (s = Ya(n, o, t)), s !== void 0) return t === "length" && Array.isArray(e) || (s.configurable = !0), s;
	},
	set(e, t, n) {
		let r = this, i = G(r);
		if (!i && !R || t === "__proto__") return !0;
		let a = r.s || r.rr && n?.[I]?.rr !== r.rr ? n : H(n), o = Bi(r);
		W && r.k?.l & 256 && di.add(gi(r, t)), Array.isArray(o) ? (Wa(r, t), t === "length" ? r.wk = Ii : Wa(r, "length")) : (Wa(r, t), t in o || r.kc++);
		let s = Ua.has(t);
		return s || r.ovl && r.sc !== 2 && !U.call(o, t) ? Object.defineProperty(o, t, {
			value: a,
			writable: !0,
			enumerable: !0,
			configurable: !0
		}) : o[t] = a, r.del?.delete(t), s || (r.s && typeof a == "object" && a && kr(a), i || oa(r)), !0;
	},
	defineProperty(e, t, n) {
		let r = this, i = G(r);
		if (!i && !R || t === "__proto__") return !0;
		(n.get || n.set) && (r.a = !0), "value" in n && (n = {
			...n,
			value: H(n.value)
		});
		let a = Bi(r);
		return (r.a || !(n.enumerable && n.writable && n.configurable)) && (r.sc = 1), Wa(r, t), Object.defineProperty(a, t, n), r.del?.delete(t), i || oa(r), !0;
	},
	deleteProperty(e, t) {
		let n = this, r = G(n);
		if (!r && !R) return !0;
		let i = Bi(n);
		Wa(n, t);
		let a = n.ovl && U.call(n.v, t);
		return U.call(i, t) && (delete i[t], a || n.kc--), a && (n.del ?? (n.del = /* @__PURE__ */ new Set())).add(t), r || oa(n), !0;
	},
	getPrototypeOf() {
		return Ci(this.v);
	},
	preventExtensions: () => !1,
	setPrototypeOf: () => !1
};
function Ga(e, t) {
	let n = e.k;
	if (n === null) return !1;
	let r = n.Ze;
	return r !== null && r.u === t && (!(t.R & 4) || r.Ne === t.de);
}
function Ka(e, t, n = !0) {
	dr !== null && dr(e);
	let r = e[I], i = ya;
	ya = /* @__PURE__ */ new Set(), ya.add(xa(r));
	let a = W;
	W = n, va === 0 && ba.size && ba.clear(), va++;
	let o;
	try {
		o = t(e), B !== null && n && r.o && !R && o !== void 0 && o !== e && L(o) && (B.reconcile(e, H(o), r.rr?.key ?? null), o = void 0);
	} finally {
		if (va--, ya = i, va === 0 && ba.size) {
			let e = [...ba];
			ba.clear();
			for (let t of e) oa(t);
			if (ea) for (let t of e) t.pb !== null && na(t, t.v);
		}
		W = a;
	}
	if (o !== void 0 && o !== e && L(o) && Gi(r, H(o)), n && ra) {
		ra = !1;
		let e = r.rr.node;
		e.R & 2 || (e.R = e.R & -2 | 2, Vt(e, D), k());
	}
}
function qa(e, t) {
	let n = t?.shallow === !0, r = V(e);
	return gr !== null && gr(r[I]), n && (r[I].s = !0, Ar(e)), [r, (e) => Ka(r, e)];
}
Fr((e) => {
	if (e?.s && !(e.ch || e.a || ya || R || e.rr?.opt)) return e.rr && Ra(e), Ea(e);
});
function Ja(e, t) {
	let n;
	if (e.ovl && t === e.pb) {
		n = Reflect.ownKeys(e.v);
		let r = e.del;
		r?.size && (n = n.filter((e) => !r.has(e)));
		for (let r of Reflect.ownKeys(t)) U.call(e.v, r) || n.push(r);
	} else n = Reflect.ownKeys(t);
	for (let e = n.length - 1; e >= 0 && typeof n[e] == "symbol"; e--) if (n[e] === z) {
		n.splice(e, 1);
		break;
	}
	return n;
}
function Ya(e, t, n) {
	let r = Object.getOwnPropertyDescriptor(t, n);
	if (e.ovl && t === e.pb) {
		if (e.del?.has(n)) return;
		r === void 0 && (r = Object.getOwnPropertyDescriptor(e.v, n));
	}
	return r;
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/store/reconcile.js
function Xa(e, t, n, r = !1) {
	if (t == null) throw Error("");
	let i = t[I];
	if (i?.px !== t) throw Error("");
	let a = n === null ? null : typeof n == "string" ? (e) => e?.[n] : n;
	if (B !== null && i.o && ia()) {
		B.reconcile(t, H(e), a);
		return;
	}
	if (r && e !== t && e?.[I] !== void 0) {
		if ((i.pb ?? i.v) === e) return;
		Gi(i, e);
		return;
	}
	let o = H(e);
	if (a) {
		let e = i.pb ?? i.v, t = a(e);
		if (t !== void 0 && !ci(a(o), t)) {
			if (!r) throw Error("");
			ei(e) ? delete e[z] : (i.rr?.map ?? Qr).delete(e), Gi(i, o);
			return;
		}
	}
	Za(i, o, a, r);
}
function Za(e, t, n, r = !1) {
	let i = e.ovl ? zi(e) : e.pb ?? e.v;
	if (t === i && !ei(i)) return;
	let a = B !== null && e.o ? (B.pair(e, t, !0), B.view(e, i)) : i, o = Array.isArray(t), s = e.s === !0;
	if (Gi(e, t, !1), s && Ar(t), e.dk, Array.isArray(a) !== o || i[I]) {
		_a(e, i, t);
		return;
	}
	if (o) {
		let o = e.n, c = 0;
		if (n && !s) {
			let s = a.length, l = t.length, u = 0;
			for (let d = Math.min(s, l); u < d; u++) {
				let s = t[u], l = a[u];
				if (l !== s && !Aa(l, s, n)) break;
				if (typeof s == "object" && s && (l !== s || ei(s)) && $a(H(l), s, n, r, e, u), o !== null) {
					let e = o[u];
					e !== void 0 && (c++, ha(e, u, i[u], s, i, t));
				}
			}
			let d = u, f = null;
			for (; u < t.length; u++) {
				let s = t[u];
				if (typeof s == "object" && s) {
					let t = n(s), i;
					if (t !== void 0) {
						if (f === null) {
							f = /* @__PURE__ */ new Map();
							for (let e = d; e < a.length; e++) {
								let t = H(a[e]);
								if (typeof t == "object" && t) {
									let r = n(t);
									if (r === void 0) continue;
									let i = f.get(r);
									i === void 0 ? f.set(r, e) : Array.isArray(i) ? i.push(e) : f.set(r, [i, e]);
								}
							}
						}
						let e = f.get(t);
						e === void 0 ? i = void 0 : Array.isArray(e) ? (i = H(a[e.shift()]), e.length === 1 && f.set(t, e[0])) : (i = H(a[e]), f.delete(t));
					} else i = H(a[u]);
					$a(i, s, n, r, e, u);
				}
				if (o !== null) {
					let e = o[u];
					e !== void 0 && (c++, pa(e, u, i, t, !1));
				}
			}
		} else {
			let l = Math.min(a.length, t.length), u = t.length;
			for (let d = 0; d < u; d++) {
				let u = t[d];
				if (!s && d < l && typeof u == "object" && u && $a(H(a[d]), u, n, r, e, d), o !== null) {
					let e = o[d];
					e !== void 0 && (c++, pa(e, d, i, t, !1));
				}
			}
		}
		if (o !== null && c < e.nc) for (let e of Reflect.ownKeys(o)) {
			let n = typeof e == "string" ? +e : NaN;
			n >= 0 && n < t.length || pa(o[e], e, i, t, !1);
		}
		ga(e, i, t);
		return;
	}
	let c = e.n, l = 0;
	for (let o in t) {
		let u = t[o], d = i[o], f = typeof u == "object" && !!u;
		if (d === u && (!f || !ei(u)) && (c === null || c[o] === void 0 || !ma(c[o]))) c?.[o] !== void 0 && l++;
		else if (f && !s && $a(H(a[o]), u, n, r, e, o), c !== null) {
			let e = c[o];
			e !== void 0 && (l++, ha(e, o, d, u, i, t));
		}
	}
	let u = Object.getOwnPropertySymbols(t);
	for (let a = 0; a < u.length; a++) {
		let o = u[a];
		if (o === z) continue;
		let d = t[o];
		if (!s && typeof d == "object" && d && $a(H(i[o]), d, n, r, e, o), c !== null) {
			let e = c[o];
			e !== void 0 && (l++, ha(e, o, i[o], d, i, t));
		}
	}
	if (c !== null && l < e.nc) for (let e of Reflect.ownKeys(c)) Qa.call(t, e) || pa(c[e], e, i, e === "__proto__" ? Object.create(null) : t, !1);
	ga(e, i, t);
}
var Qa = Object.prototype.hasOwnProperty;
function $a(e, t, n, r, i, a) {
	if (typeof e != "object" || !e) return;
	let o = i.rr;
	t = H(t);
	let s = ti(e, o), c = ti(t, o);
	if (s !== void 0 && s.pk !== a && (s.pk != a && i.v[s.pk] === s.v ? s = void 0 : s.u === i && (s.pk = a)), c !== void 0 && c !== s) {
		if (c.v === t) {
			c.u === i && (c.pk = a);
			return;
		}
		(o?.map ?? Qr).delete(t);
	}
	if (s !== void 0 && L(t) && !(Dr && Or(t)) && Array.isArray(e) === Array.isArray(t)) {
		if (typeof a != "number" && n) {
			let r = n(e), i = n(t);
			if (r !== void 0 && i !== void 0 && !ci(r, i)) return;
		}
		(r || n === null || s.d) && Za(s, t, n, r);
	}
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/store/projection.js
function eo(e, t, n, r, i, a) {
	let o = (e) => {
		if (!t()) return !0;
		Nr(!0);
		let r = ht;
		a !== void 0 && gt(a());
		try {
			n ? n(e) : e();
		} finally {
			Nr(!1), gt(r);
		}
		return i && i(), !0;
	}, s = (e) => {
		Nr(!0);
		try {
			return e();
		} finally {
			Nr(!1);
		}
	}, c = new Proxy(Array.isArray(e) ? [] : {}, {
		get(o, c) {
			let l = s(() => e[c]);
			return !r && typeof l == "object" && l && c !== I ? eo(l, t, n, !1, i, a) : l;
		},
		has: (t, n) => s(() => n in e),
		set: (t, n, r) => o(() => {
			e[n] = r;
		}),
		deleteProperty: (t, n) => o(() => {
			delete e[n];
		}),
		ownKeys: () => s(() => Reflect.ownKeys(e)),
		getPrototypeOf: () => Ci(e),
		getOwnPropertyDescriptor(t, n) {
			let r = s(() => Reflect.getOwnPropertyDescriptor(e, n));
			return r && (r.configurable = !0), r;
		},
		defineProperty: (t, n, r) => o(() => {
			Reflect.defineProperty(e, n, r);
		})
	}), l = e[I];
	return l !== void 0 && $r(c, l), c;
}
function to(e, t) {
	return t ? Array.isArray(e) ? e.slice() : { ...e } : JSON.parse(JSON.stringify(e));
}
function no(t) {
	let n = t.node, r = new e(n);
	t.Tt = !0;
	let i = B?.ask(t);
	oo(t, (e) => {
		e.o === null || i?.(e) || (sn(e, n), Dn(e, 1, r));
	});
}
function ro(e, t) {
	oo(e, (e) => {
		e.o !== null && mn(e, (e) => {
			e.m & 2 && e.T.U === t || zt(e);
		});
	}), k();
}
function io(e) {
	if (!e.Tt) return;
	e.Tt = !1;
	let t = e.node;
	oo(e, (e) => {
		e.o !== null && bn(e, t);
	}), jt(t);
}
function ao(e, t) {
	e & 1 ? no(this) : e ? e & 2 && ro(this, t) : io(this);
}
function oo(e, t) {
	for (let n of e.live) {
		let e = n.n;
		if (e !== null) for (let n of Reflect.ownKeys(e)) t(e[n]);
		let r = n.h;
		if (r !== null) for (let e of Reflect.ownKeys(r)) t(r[e]);
		n.k !== null && t(n.k), n.dk !== null && t(n.dk);
	}
}
function so(t, n, r, i, a) {
	let o = fe(), s = t[I], c = s.rr, l = c.run = (c.run || 0) + 1, u, d = o.Ie ? to(s.v, s.s) : null, f = () => ht || (o.T !== null && o.T.Ee !== null ? o.T.ce : 0), p = eo(t, () => c.run === l && !me(o), a, s.s, () => {
		!(o.m & 1) && !o.Ie && k();
	}, f), m = l === 1, h = () => Ka(p, (e) => {
		u = n(d ?? e);
		let a = (n, a = 1) => {
			if (d && (n === void 0 || n === d) && (n = to(d, s.s)), n !== e && n !== void 0) {
				let e = () => {
					let e = ht;
					gt(f());
					try {
						Ka(t, (e) => Xa(n, e, r, !0), !1);
					} finally {
						gt(e);
					}
				};
				i ? i(e, n) : e();
			}
			m && o.m & 4 || io(c), a && jt(o);
		}, l = Cn(o, u, a, (e, t) => {
			m && o.m & 4 || (t ? no(c) : ro(c, e));
		});
		o.Ie || a(l, o.m & 3);
	}, !1);
	try {
		m ? ta(h) : h();
	} catch (t) {
		throw m || (t instanceof e ? no(c) : ro(c, t)), t;
	}
	return o.m & 1 && o.T.Ee !== null && !o.Ie && !m && no(c), o;
}
function co(e, t, n, r) {
	t || (t = {});
	let i = n?.key === void 0 ? "id" : n.key, a = {
		map: /* @__PURE__ */ new WeakMap(),
		node: null,
		live: /* @__PURE__ */ new Set(),
		st: ao,
		It: !!n?.shallow,
		opt: r,
		key: typeof i == "function" ? i : i === null ? null : (e) => L(e) ? e[i] : void 0
	}, o = V(t, null, null, a);
	a.It && (o[I].s = !0, Ar(t));
	let s;
	if (n?.seedLoadingValue && (s = { loadingValue: void 0 }), e) {
		let t = jn(() => {
			a.node || (a.node = fe()), so(o, e, i);
		}, s);
		t.l &= -33, a.node = t, t.rr = a;
	}
	return o;
}
function lo(e, t, n) {
	let r = co(e, t, n);
	return [r, (e) => Ka(r, e)];
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/store/index.js
function uo(e, t, n) {
	return typeof e == "function" ? lo(e, t, n) : qa(e, t);
}
function fo(e, t = "id") {
	return (n) => Xa(e, n, t);
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/flatten.js
function po(e, t) {
	if (typeof e == "function" && !e.length) {
		if (t?.doNotUnwrap) return e;
		do
			e = e();
		while (typeof e == "function" && !e.length);
	}
	if (!t?.skipNonRendered || e != null && e !== !0 && e !== !1 && e !== "") {
		if (Array.isArray(e)) {
			let n = [];
			return mo(e, n, t) ? () => {
				let e = [];
				return mo(n, e, {
					...t,
					doNotUnwrap: !1
				}), e;
			} : n;
		}
		return e;
	}
}
function mo(t, n = [], r) {
	let i = null, a = !1;
	for (let o = 0; o < t.length; o++) try {
		let e = t[o];
		if (typeof e == "function" && !e.length) {
			if (r?.doNotUnwrap) {
				n.push(e), a = !0;
				continue;
			}
			do
				e = e();
			while (typeof e == "function" && !e.length);
		}
		Array.isArray(e) ? a = mo(e, n, r) || a : r?.skipNonRendered && (e == null || e === !0 || e === !1 || e === "") || n.push(e);
	} catch (t) {
		if (!(t instanceof e)) throw t;
		i = t;
	}
	if (i) throw i;
	return a;
}
// node_modules/.pnpm/solid-js@2.0.0/node_modules/solid-js/dist/solid.js
var ho = !1, go = {
	hydrating: !1,
	registry: void 0,
	done: !1
}, _o, vo = (...e) => Rr(...e), yo = Lr, bo = (...e) => typeof e[0] == "function" && go.hydrating ? _o(uo, e[0], e[1] ?? {}, e[2]) : uo(...e), xo = _e, So = Br, Co = (...e) => zr(...e);
function K(e, t, n, r) {
	return qn(() => e(t || {}));
}
var wo = (e) => {
	throw `Stale read from <${e}>.`;
};
function q(e) {
	let t = "fallback" in e ? {
		keyed: e.keyed,
		fallback: () => e.fallback
	} : { keyed: e.keyed }, n = fe(), r, i = () => mr(n, () => Hr(() => e.each, e.children, t));
	return go.hydrating && (r = i()), () => (r ?? (r = i()))();
}
function To(e) {
	let t = e.keyed, n = Rr(() => e.when, void 0), r = t ? n : Rr(n, {
		equals: (e, t) => !e == !t,
		sync: !0
	});
	return Rr(() => {
		let i = r();
		if (i) {
			let a = e.children;
			return typeof a == "function" && a.length > 0 ? qn(t ? () => a(i) : () => a(() => (r() || wo("Show"), n())), ho) : a;
		}
		return e.fallback;
	}, { sync: !0 });
}
// node_modules/.pnpm/solid-js@2.0.0/node_modules/solid-js/dist/internal.js
var Eo = ar, Do = go, Oo = /*#__PURE__*/ Symbol("slot"), ko = /*#__PURE__*/ Symbol("index"), Ao = {
	transparent: !0,
	sync: !0
}, jo = { sync: !0 };
function J(e, t, n) {
	So(e, t, n ? {
		sync: !0,
		...n,
		transparent: !n.scope
	} : Ao);
}
function Y(e) {
	return vo(() => e(), jo);
}
function Mo(e, t, n, r) {
	let i = n.length, a = t.length, o = i, s = 0, c = 0, l, u, d, f;
	for (; s < a && t[s] === n[c];) s++, c++;
	if (s === a && c === o) return;
	let p = e.moveBefore && e.isConnected, m = r || e, h = (t, n) => {
		p && t.isConnected ? e.moveBefore(t, n) : e.insertBefore(t, n), (r || t[Oo]) && (t[Oo] = m);
	};
	if (!a) {
		for (let e of n) h(e, r);
		return;
	}
	let g = (t) => t && t.parentNode === e && (!(t = t[Oo]) || t === m), _ = (t) => {
		for (; t < i && !g(n[t]);) t++;
		return n[t] || (u && u.parentNode !== e ? r || null : u);
	};
	for (u = g(f = t[a - 1]) ? f.nextSibling : r || null; s < a || c < o;) if (t[s] === n[c]) s++, c++;
	else {
		for (; a > s && o > c && t[a - 1] === n[o - 1];) a--, o--;
		if (a === s) for (f = _(o); c < o;) h(n[c++], f);
		else if (!g(f = t[s])) s++;
		else if (n[c] === t[a - 1] && (f === n[o - 1] || !l && f === n[c + 1] && t[s + 1] === n[c + 2])) do
			h(t[--a], f), c++;
		while (s < a - 1 && c < o && f === n[o - 1] && n[c] === t[a - 1]);
		else if (c < o && f === n[o - 1] && t[s + 1] !== n[o - 2] && g(n[c]) && g(t[a - 1])) h(f, _(o)), s++, o--;
		else {
			if (!l) for (l = 1, d = c; d < o;) n[d][ko] = d++;
			if ((d = f[ko]) >= 0 && n[d] === f) {
				if (c < d && d < o) {
					let i = s, l = 1;
					for (; ++i < a && i < o && t[i] === n[d + l];) l++;
					if (l > d - c) for (; c < d;) h(n[c++], f);
					else {
						let t = n[c++];
						s++, p ? h(t, f) : e.replaceChild(t, f), (r || t[Oo]) && (t[Oo] = m);
					}
				} else s++;
			} else f.remove(), s++;
		}
	}
}
var No = "_$$", Po = "_$SOLID_EVENT_OWNER", Fo = {}, Io = /* @__PURE__ */ new Set(), Lo = /* @__PURE__ */ new Map();
function Ro(e, t, n, r = {}) {
	let i;
	Vo(t);
	try {
		xo((a) => {
			i = a, r.onError && (fe()[_t] = r.onError);
			let o = e();
			t === document ? J(() => po(o), () => {}) : Q(t, () => o, t.firstChild ? null : void 0, n, {
				...r.insertOptions,
				schedule: !0
			});
		}, { id: r.renderId }), Lt();
	} catch (e) {
		throw i && i(), Ho(t), e;
	}
	return () => {
		i(), Ho(t), t.textContent = "";
	};
}
function zo(e, t, n) {
	let r = document.createElement("template");
	r.innerHTML = e;
	let i = r.content.firstChild;
	return n === 2 ? i.firstChild : i;
}
function X(e, t) {
	let n;
	return (r) => (n || (n = zo(e, r, t)), t === 1 ? document.importNode(n, !0) : n.cloneNode(!0));
}
function Bo(e) {
	for (let t of e) Io.has(t) || (Io.add(t), Lo.forEach((e, n) => Go(t, n, e)));
}
function Vo(e) {
	let t = Uo(e, e);
	t && (t.roots = (t.roots || 0) + 1);
}
function Ho(e) {
	let t = Lo.get(e);
	t && (t.roots > 1 ? t.roots-- : delete t.roots), Wo(e, e);
}
function Uo(e, t = e) {
	if (!e || !t) return;
	let n = Lo.get(e);
	return n || Lo.set(e, n = {
		owners: /* @__PURE__ */ new Map(),
		handlers: /* @__PURE__ */ new Map()
	}), n.owners.set(t, (n.owners.get(t) || 0) + 1), Io.forEach((t) => Go(t, e, n)), n;
}
function Wo(e, t = e) {
	let n = Lo.get(e);
	if (!n) return;
	let r = n.owners.get(t);
	r > 1 ? n.owners.set(t, r - 1) : n.owners.delete(t), n.owners.size || (n.handlers.forEach((t, n) => e.removeEventListener(n, t)), Lo.delete(e));
}
function Go(e, t, n) {
	if (n.handlers.has(e)) return;
	let r = (e) => os(e, t, n);
	n.handlers.set(e, r), t.addEventListener(e, r);
}
var Ko = (e) => e._$host || e.parentNode || e.host;
function qo(e, t) {
	let n = 0;
	for (; e;) {
		if (t.owners.has(e)) return {
			owner: e,
			distance: n
		};
		n++, e = Ko(e);
	}
}
function Jo(e, t, n) {
	if (is(e)) return;
	let r = e.nodeName;
	t === "value" && r === "SELECT" ? ls(e, n) : (t === "value" || t === "defaultValue") && (r === "INPUT" || r === "TEXTAREA") ? n == null && /^(checkbox|radio)$/.test(e.type) ? e.removeAttribute("value") : e[t] = n ?? "" : e[t] = n, Qo(e, t);
}
var Yo = null, Xo = [];
function Zo(e, t) {
	for (let n = 0; n < e.length; n++) e[n](t);
}
function Qo(e, t) {
	Yo !== null && e._$claimed && Xo.some((e) => e.includes(t.slice(t.indexOf(":") + 1))) && Zo(Yo, e);
}
function $o(e, t) {
	return Yo !== null && !e._$claimed && (e._$claimed = !0, t === void 0 ? Zo(Yo, e) : mr(t, () => Zo(Yo, e))), e;
}
function Z(e, t, n) {
	if (is(e)) return;
	let r = t === "multiple" && e.localName === "select";
	if (n == null || n === !1) e.removeAttribute(t);
	else if (e.setAttribute(t, n === !0 ? "" : n), r && !e._$multiple) {
		let t = e.options;
		for (let e = 0; e < t.length; e++) t[e].defaultSelected && (t[e].selected = !0);
	}
	r && (e._$multiple = !0), Qo(e, t);
}
var es = { scope: !0 }, ts = null, ns = null, rs = null;
function Q(e, t, n, r, i) {
	let a = n !== void 0;
	if (a && !r && (r = []), ts !== null && (r = ts.claimInitial(e, a, r)), typeof t != "function" && (t = ds(t, r, a, !0), typeof t != "function")) {
		ss(e, t, r, n), rs !== null && i && i.host && rs(t, i.host);
		return;
	}
	if (a && r.length === 0) {
		let t = document.createTextNode("");
		e.insertBefore(t, n), r = [t];
	}
	let o = !1;
	J(() => {
		ts !== null && (r = ts.reclaimRegion(r, e, n));
		let s = ds(t(), r, a, !0), c = o;
		return o = !0, typeof s == "function" ? (J(() => (ts !== null && (r = ts.reclaimRegion(r, e, n)), ds(s, r, a)), (t) => {
			r = ss(e, t, r, n), rs !== null && i && i.host && rs(r, i.host);
		}, c && !(i && i.schedule) ? {
			...i,
			schedule: !0
		} : i), Fo) : s;
	}, (t) => {
		t !== Fo && (r = ss(e, t, r, n), rs !== null && i && i.host && rs(r, i.host));
	}, t.$s ? i ? {
		...i,
		scope: !0
	} : es : i);
}
function is(e) {
	return !Do.hydrating || Do.isClaiming && !Do.isClaiming() ? !1 : !e || e.isConnected ? !0 : as !== null && as.claimed(e);
}
var as = null;
function os(e, t, n) {
	if (ts !== null && ts.dedupEvent(e)) return;
	let r = e[Po], i;
	if (r) {
		if (r === !0 || r === t || !t.contains(r)) return;
		i = r;
	}
	let a = n.owners.size === 1 && n.owners.has(t) ? t : qo(e.target, n)?.owner;
	if (!a || a === i) return;
	e[Po] = a;
	let o = i || e.target, s = No + e.type, c = (t, n) => Object.defineProperty(e, t, {
		configurable: !0,
		value: n
	}), l = () => {
		let t = o[s];
		if (t && !o.disabled) {
			c("currentTarget", o);
			let n = o[`${s}Data`];
			if (n === void 0 ? typeof t == "function" ? t.call(o, e) : t.handleEvent(e) : t.call(o, n, e), e.cancelBubble) return;
		}
		return o.host && typeof o.host != "string" && !o.host._$host && o.contains(e.target) && c("target", o.host), !0;
	}, u = () => o === a || o.parentNode === a, d = () => {
		for (; o && l() && !u();) o = Ko(o);
	};
	if (i) i === e.target && (o = Ko(i)), o && o !== a && d();
	else if (e.composedPath) {
		let t = e.composedPath();
		if (t.length) {
			c("target", t[0]);
			for (let e = 0; e < t.length && (o = t[e], l()); e++) {
				if (o._$host) {
					o = o._$host, d();
					break;
				}
				if (u()) break;
			}
		} else d();
	} else d();
	delete e.target, delete e.currentTarget;
}
function ss(e, t, n, r) {
	if (ts !== null && is(e)) {
		if (t && t !== n) {
			let e = Array.isArray(t);
			for (let r of e ? t : [t]) if (r && r.nodeType) {
				if (!is(r)) return n;
			} else if (e && (typeof r == "string" || typeof r == "number")) return n;
		}
		return t;
	}
	if (t === n) return t;
	if (ts !== null && Do.hydrating && t && t.length !== 0) {
		let r = [].concat(n ?? []);
		if ([].concat(t).every((t) => (t === r[0] && r.shift(), t?.parentNode === e)) && !r.length) return t;
	}
	let i = typeof t;
	if (i === "string" || i === "number") {
		let r = typeof n;
		r === "string" || r === "number" ? e.firstChild.data = t : fs(e, n) ? e.textContent = t : (ps(e, n), e.insertBefore(document.createTextNode(t), e.firstChild));
	} else if (t === void 0) ms(e, n, r);
	else if (t.nodeType) Array.isArray(n) ? ms(e, n, r ?? null, t) : n != null && n.nodeType ? n.parentNode === e ? e.replaceChild(t, n) : e.appendChild(t) : n != null && e.firstChild ? e.replaceChild(t, e.firstChild) : e.appendChild(t), (r || t[Oo]) && (t[Oo] = r || e);
	else if (Array.isArray(t)) {
		let i = Array.isArray(n);
		for (let e = 0, r = t.length; e < r; e++) {
			let r = t[e], a = typeof r;
			if (a === "string" || a === "number") {
				let a = i ? n[e] : void 0;
				if (a && a.nodeType === 3) {
					let n = a._$d;
					n !== r && (n !== void 0 || a.data !== "" + r) && (a.data = a._$d = r), t[e] = a;
				} else t[e] = document.createTextNode(r);
			}
		}
		t.length === 0 ? ms(e, n, r) : i ? Mo(e, n, t, r) : (n != null && ms(e, n), Mo(e, [], t));
	}
	return ns && ns(e), t;
}
function cs(e) {
	(e = e.currentTarget || e)._$v = null, e.removeEventListener("change", cs, !0);
}
function ls(e, t) {
	let n = e._$v && e._$v.map;
	if (t != null && t.map ? n || e.addEventListener("change", cs, !0) : n && e.removeEventListener("change", cs, !0), t == null) return e._$v = null, queueMicrotask(() => e.value = t) || (e.value = t);
	e._$v = t, (ns || (ns = us))(e), queueMicrotask(() => ns(e));
}
function us(e) {
	e && e._$v == null && (e = e.parentNode);
	let t = e && e._$v;
	if (t != null) {
		if (t.map) {
			let n = [...e.options];
			for (let e = 0; e < n.length; e++) n[e].selected = t.some((t) => t == n[e].value);
			t.every((e) => n.some((t) => t.value == e)) && cs(e);
		} else e.value = t, e.selectedIndex > -1 && e.value == t && (e._$v = null);
	}
}
function ds(e, t, n, r) {
	if (e = po(e, {
		skipNonRendered: !0,
		doNotUnwrap: r
	}), r && typeof e == "function") return e;
	if (n && !Array.isArray(e) && (e = [e ?? ""]), ts !== null && Do.hydrating && Array.isArray(e)) for (let n = 0, r = e.length; n < r; n++) {
		let r = e[n], i = t && t[n], a = typeof r;
		(a === "string" || a === "number") && i && i.nodeType === 3 && is(i) && (e[n] = i);
	}
	return e;
}
function fs(e, t) {
	if (t == null) return !0;
	if (Array.isArray(t)) return t.length ? e.firstChild === t[0] && e.lastChild === t[t.length - 1] : e.firstChild === null;
	if (t === "") return e.firstChild === null;
	if (t.nodeType) return e.firstChild === t && e.lastChild === t;
	let n = e.firstChild;
	return n !== null && n.nodeType === 3 && e.lastChild === n;
}
function ps(e, t) {
	if (Array.isArray(t)) for (let n = 0; n < t.length; n++) {
		let r = t[n];
		r.parentNode === e && r.remove();
	}
	else if (t.nodeType) t.parentNode === e && t.remove();
	else {
		let t = e.firstChild;
		t && t.nodeType === 3 && t.remove();
	}
}
function ms(e, t, n, r) {
	if (n === void 0) return fs(e, t) ? e.textContent = "" : ps(e, t);
	if (t.length) {
		let i = !1;
		for (let a = t.length - 1; a >= 0; a--) {
			let o = t[a];
			if (r !== o) {
				let t = o[Oo], s = o.parentNode === e && (!t || t === (n || e));
				r && !i && !a ? s ? e.replaceChild(r, o) : e.insertBefore(r, n) : s && o.remove();
			} else i = !0;
		}
	} else r && e.insertBefore(r, n);
	r && (n || r[Oo]) && (r[Oo] = n || e);
}
// mcp.js
var hs = "2026-07-28";
function gs(e, t = {}, n, r) {
	let i = {
		Authorization: `Bearer ${r}`,
		Accept: "application/json, text/event-stream",
		"Content-Type": "application/json",
		"MCP-Protocol-Version": hs,
		"Mcp-Method": e
	};
	e === "tools/call" && (i["Mcp-Name"] = t.name), e === "resources/read" && (i["Mcp-Name"] = t.uri);
	let a = {
		jsonrpc: "2.0",
		id: n,
		method: e,
		params: {
			...t,
			_meta: {
				"io.modelcontextprotocol/protocolVersion": hs,
				"io.modelcontextprotocol/clientInfo": {
					name: "local-fabric",
					version: "1"
				},
				"io.modelcontextprotocol/clientCapabilities": {}
			}
		}
	};
	return {
		method: "POST",
		headers: i,
		body: JSON.stringify(a)
	};
}
function _s(e, t = "") {
	let n = 0;
	async function r(n, r, i, a) {
		let o = await fetch(t + "/mcp", {
			...gs(n, r, i, e),
			cache: "no-store",
			signal: a
		});
		if (!o.ok) throw Error(o.status + " " + await o.text());
		return o;
	}
	async function i(e, t) {
		let i = ++n, a = await (await r(e, t, i)).json();
		if (a.id !== i) throw Error("MCP response ID mismatch");
		if (a.error) throw Error(a.error.message);
		if (a.result?.resultType !== "complete") throw Error("Expected complete result");
		return a.result;
	}
	async function a(e) {
		let t = await i("resources/read", { uri: e });
		return JSON.parse(t.contents[0].text);
	}
	async function o(e, t) {
		let n = await i("tools/call", {
			name: e,
			arguments: t
		});
		if (n.isError) throw Error(n.content[0].text);
		return n.content[0].text;
	}
	async function* s(e, t) {
		let i = ++n, a = (await r("subscriptions/listen", { notifications: { resourceSubscriptions: e } }, i, t)).body.pipeThrough(new TextDecoderStream()).getReader(), o = "", s = !1;
		try {
			for (;;) {
				let { value: e, done: t } = await a.read();
				if (t) return;
				o += e;
				let n;
				for (; (n = o.indexOf("\n\n")) !== -1;) {
					let e = o.slice(0, n);
					o = o.slice(n + 2);
					let t = e.split("\n").find((e) => e.startsWith("data: "));
					if (!t) continue;
					let r = JSON.parse(t.slice(6));
					if (r.id === i && r.result?.resultType === "complete") return;
					if (r.params?._meta?.["io.modelcontextprotocol/subscriptionId"] !== i) throw Error("Subscription ID mismatch");
					if (s) r.method === "notifications/resources/updated" && (yield {
						initial: !1,
						uris: [r.params.uri]
					});
					else {
						if (r.method !== "notifications/subscriptions/acknowledged") throw Error("Expected subscription acknowledgment");
						s = !0, yield {
							initial: !0,
							uris: r.params.notifications.resourceSubscriptions ?? []
						};
					}
				}
			}
		} finally {
			await a.cancel().catch(() => {}), a.releaseLock();
		}
	}
	return {
		read: a,
		call: o,
		rpc: i,
		watch: s
	};
}
// connection.js
var vs, [ys, bs] = yo(""), [xs, Ss] = yo("Disconnected"), [Cs, ws] = yo(""), [Ts, Es] = bo([]), [Ds, Os] = bo({}), [ks, As] = yo(null), [js, Ms] = yo([]);
async function Ns(e) {
	try {
		await e();
	} catch (e) {
		ws(e.message);
	}
}
var Ps = (e) => new Promise((t) => setTimeout(t, e));
async function Fs(e, t, n) {
	await vs.call(e, t), ws("Accepted; waiting for " + n);
	for (let e = 0; e < 120; e++) {
		await Ps(500);
		let e = await vs.read("fabric://status");
		if (e[n] !== "pending") {
			ws(n + ": " + e[n]);
			return;
		}
	}
	ws("Still pending. Check status before retrying.");
}
function Is() {
	Co(ys, (e) => {
		if (!e) {
			Es(fo([])), Os(fo({})), As(null), Ms([]);
			return;
		}
		let t = new AbortController(), n = _s(e);
		vs = n;
		let r = t.signal;
		return (async () => {
			for (; !r.aborted;) {
				try {
					Ss("Connecting");
					for await (let { initial: e, uris: t } of n.watch([
						"fabric://devices/metadata",
						"fabric://devices/state",
						"fabric://automation/actions",
						"fabric://automation/rules"
					], r)) {
						e && Ss("Live");
						for (let e of t) {
							let t = await n.read(e);
							if (r.aborted) return;
							e === "fabric://devices/metadata" && Es(fo(Object.entries(t.devices).map(([e, t]) => ({
								...t,
								device_id: Number(e)
							})), "device_id")), e === "fabric://devices/state" && Os(fo(t.devices)), e === "fabric://automation/actions" && Ms(t), e === "fabric://automation/rules" && As(t);
						}
					}
				} catch (e) {
					if (r.aborted) return;
					if (e.message.startsWith("401 ")) {
						bs(""), ws("Token rejected. Use the current serial token.");
						return;
					}
					ws(e.message);
				}
				Ss("Reconnecting"), await Ps(1e3);
			}
		})(), () => t.abort();
	});
}
// fields.jsx
var Ls = /* @__PURE__ */ X("<label><!><!>"), Rs = /* @__PURE__ */ X("<select>"), zs = /* @__PURE__ */ X("<input required>"), Bs = /* @__PURE__ */ X("<option>"), Vs = (e) => Object.entries(e || {});
function Hs(e, t) {
	let n = {};
	for (let [r, i] of Vs(t)) {
		let t = e.elements.namedItem(r).value;
		n[r] = i.type === "boolean" ? t === "true" : ["integer", "number"].includes(i.type) ? Number(t) : t;
	}
	return n;
}
function Us(e) {
	return K(q, {
		get each() {
			return Object.keys(e.schema || {});
		},
		children: (t) => {
			let n = () => e.schema[t];
			var r = Ls(), i = r.firstChild, a = i.nextSibling;
			return Q(r, t, i), Q(r, (() => {
				var r = Y(() => !!(n().enum || n().type === "boolean"));
				return () => r() ? (() => {
					var r = Rs();
					return Z(r, "name", t), Q(r, K(q, {
						get each() {
							return n().enum || [!0, !1];
						},
						children: (e) => (() => {
							var t = Bs();
							return Q(t, () => String(e?.label ?? e)), J(() => String(e?.value ?? e), (e) => {
								t.value = e;
							}), t;
						})()
					})), J(() => String(e.defaults?.[t] ?? n().enum?.[0]?.value ?? n().enum?.[0] ?? !0), (e) => {
						Jo(r, "value", e);
					}), r;
				})() : (() => {
					var r = zs();
					return Z(r, "name", t), J(() => ({
						e: ["integer", "number"].includes(n().type) ? "number" : "text",
						t: n().step ?? (n().type === "integer" ? 1 : "any"),
						a: n().min,
						o: n().max,
						i: e.defaults?.[t] ?? n().min ?? "",
						n: Eo()
					}), ({ e, t, a: n, o: i, i: a, n: o }, s) => {
						e !== s?.e && Z(r, "type", e), t !== s?.t && Z(r, "step", t), n !== s?.a && Z(r, "min", n), i !== s?.o && Z(r, "max", i), a === s?.i && o || Jo(r, "value", a);
					}), r;
				})();
			})(), a), r;
		}
	});
}
// rules/PropertyFields.jsx
var Ws = /* @__PURE__ */ X("<label><select><option value>Choose…</option><!><!>"), Gs = /* @__PURE__ */ X("<option> (unavailable)"), Ks = /* @__PURE__ */ X("<option>"), qs = /* @__PURE__ */ X("<label>Operator<select>"), Js = /* @__PURE__ */ X("<label>Value <!><!>"), Ys = /* @__PURE__ */ X("<select required>"), Xs = /* @__PURE__ */ X("<input required>"), $ = (e) => e?.clock ? "clock:" + e.clock : e?.delay_s === void 0 ? e?.native ? "local:" + e.native : e?.device ? [
	e.device,
	e.endpoint,
	e.cluster,
	e.property ?? e.name
].join("/") : "" : "delay";
function Zs(e) {
	return Ts.flatMap((t) => Object.entries(Ds[t.device_id]?.endpoints ?? {}).flatMap(([n, r]) => Object.entries(r.clusters ?? {}).flatMap(([r, i]) => Object.entries(i[e] ?? {}).map(([i, a]) => ({
		device: t.device_id,
		endpoint: +n,
		cluster: r,
		[e === "properties" ? "property" : "name"]: i,
		meta: a,
		label: t.name + " · " + n + " · " + r + " / " + i
	})))));
}
function Qs(e) {
	var t = Ws(), n = t.firstChild, r = n.firstChild.nextSibling, i = r.nextSibling;
	return Q(t, () => e.label, n), n.addEventListener("change", (t) => e.change(t.currentTarget.value)), Q(n, (() => {
		var t = Y(() => !(!e.value || e.options.some((t) => $(t) === e.value)));
		return () => t() ? (() => {
			var t = Gs(), n = t.firstChild;
			return Q(t, () => e.value, n), J(() => e.value, (e) => {
				t.value = e;
			}), t;
		})() : void 0;
	})(), r), Q(n, K(q, {
		get each() {
			return e.options;
		},
		children: (t) => (() => {
			var n = Ks();
			return Q(n, () => t.label), J(() => ({
				e: $(t),
				t: e.value === $(t),
				a: Eo()
			}), ({ e, t, a: r }, i) => {
				e === i?.e && r || (n.value = e), t === i?.t && r || (n.selected = t);
			}), n;
		})()
	}), i), J(() => ({
		e: e.required,
		t: e.value,
		a: Eo()
	}), ({ e, t, a: r }, i) => {
		e !== i?.e && Z(n, "required", e), t === i?.t && r || Jo(n, "value", t);
	}), t;
}
var $s = {
	boolean: ["true", "false"],
	enum: ["==", "!="],
	string: ["==", "!="],
	number: [
		">",
		"<",
		">=",
		"<=",
		"==",
		"!="
	]
};
function ec(e) {
	let t = [...e.enum ?? []];
	return e.value != null && !t.some((t) => (t?.value ?? t) === e.value) && t.push({
		value: e.value,
		label: e.label ?? e.value
	}), t;
}
function tc(e, t) {
	if (!e) return;
	let { label: n, meta: r, ...i } = e, a = {
		...i,
		type: r.type,
		op: t ?? $s[r.type][0]
	};
	if (a.op !== "changes" && a.type !== "boolean") {
		let e = ec(r)[0];
		a.value = a.type === "enum" ? e?.value ?? e : a.type === "number" ? r.value ?? 0 : "";
	}
	return a;
}
function nc(e) {
	let t = () => e.options.find((t) => $(t) === $(e.test)), n = () => t()?.meta, r = () => e.trigger ? {
		true: "becomes true",
		false: "becomes false",
		"==": "becomes equal to",
		"!=": "becomes different from",
		">": "crosses above",
		"<": "crosses below",
		">=": "reaches or exceeds",
		"<=": "reaches or falls below",
		changes: "changes"
	} : {
		true: "is true",
		false: "is false",
		"==": "is equal to",
		"!=": "is not equal to"
	};
	return Y(() => Y(() => !!n())() ? [(() => {
		var i = qs(), a = i.firstChild.nextSibling;
		return a.addEventListener("change", (n) => e.change(tc(t(), n.currentTarget.value))), Q(a, K(q, {
			get each() {
				return [...$s[n().type], ...e.trigger ? ["changes"] : []];
			},
			children: (t) => (() => {
				var n = Ks();
				return n.value = t, Q(n, () => r()[t] ?? t), J(() => e.test.op === t, (e) => {
					n.selected = e;
				}), n;
			})()
		})), J(() => e.test.op, (e) => {
			Jo(a, "value", e);
		}), i;
	})(), K(To, {
		get when() {
			return Y(() => e.test.op !== "changes")() && n().type !== "boolean";
		},
		get children() {
			var t = Js(), r = t.firstChild.nextSibling, i = r.nextSibling;
			return Q(t, () => n().unit, r), Q(t, (() => {
				var t = Y(() => n().type === "enum");
				return () => t() ? (() => {
					var t = Ys();
					return t.addEventListener("change", (t) => e.change({
						...e.test,
						value: JSON.parse(t.currentTarget.value)
					})), Q(t, K(q, {
						get each() {
							return ec(n());
						},
						children: (t) => (() => {
							var n = Ks();
							return Q(n, () => t?.label ?? String(t)), J(() => ({
								e: (t?.value ?? t) === e.test.value,
								t: JSON.stringify(t?.value ?? t),
								a: Eo()
							}), ({ e, t, a: r }, i) => {
								e === i?.e && r || (n.selected = e), t === i?.t && r || (n.value = t);
							}), n;
						})()
					})), t;
				})() : (() => {
					var t = Xs();
					return t._$$input = (t) => e.change({
						...e.test,
						value: n().type === "number" ? t.currentTarget.value === "" ? null : t.currentTarget.valueAsNumber : t.currentTarget.value
					}), J(() => ({
						e: n().type === "number" ? "number" : "text",
						t: n().step,
						a: n().min,
						o: n().max,
						i: e.test.value ?? "",
						n: Eo()
					}), ({ e, t: n, a: r, o: i, i: a, n: o }, s) => {
						e !== s?.e && Z(t, "type", e), n !== s?.t && Z(t, "step", n), r !== s?.a && Z(t, "min", r), i !== s?.o && Z(t, "max", i), a === s?.i && o || Jo(t, "value", a);
					}), t;
				})();
			})(), i), t;
		}
	})] : void 0);
}
Bo(["input"]);
// rules/ClockFields.jsx
var rc = /* @__PURE__ */ X("<div role=group aria-label=\"Days of week\"class=days><span>Days"), ic = /* @__PURE__ */ X("<label>Schedule<select><option value=at>At</option><option value=during>During"), ac = /* @__PURE__ */ X("<label><input type=time required>"), oc = /* @__PURE__ */ X("<button type=button>"), sc = (e) => {
	let [t, n] = e.split(":").map(Number);
	return t * 60 + n;
}, cc = (e) => [Math.floor(e / 60), e % 60].map((e) => String(e).padStart(2, "0")).join(":"), lc = [
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat",
	"Sun"
], uc = {
	clock: "minute",
	label: "Local clock · every minute"
};
function dc(e) {
	let t = () => e.input.weekdays ?? (e.input.weekday ? [e.input.weekday] : [
		1,
		2,
		3,
		4,
		5,
		6,
		7
	]);
	function n(n) {
		let r = t().includes(n) ? t().filter((e) => e !== n) : [...t(), n].sort((e, t) => e - t);
		if (!r.length) return;
		let { weekday: i, ...a } = e.input;
		e.change({
			...a,
			weekdays: r
		});
	}
	function r(t) {
		let { start: n, end: r, at: i, ...a } = e.input;
		e.change(t ? {
			...a,
			at: n ?? 1080
		} : {
			...a,
			start: i ?? 1080,
			end: Math.min(1440, (i ?? 1080) + 60)
		});
	}
	return [
		Y(() => Y(() => !e.condition)() ? (() => {
			var t = ic(), n = t.firstChild.nextSibling, i = n.firstChild, a = i.nextSibling;
			return n.addEventListener("change", (e) => r(e.currentTarget.value === "at")), J(() => ({
				e: e.input.at === void 0 ? "during" : "at",
				t: e.input.at !== void 0,
				a: e.input.at === void 0,
				o: Eo()
			}), ({ e, t, a: r, o }, s) => {
				e === s?.e && o || Jo(n, "value", e), t === s?.t && o || (i.selected = t), r === s?.a && o || (a.selected = r);
			}), t;
		})() : void 0),
		K(q, {
			get each() {
				return e.input.at === void 0 ? ["start", "end"] : ["at"];
			},
			children: (t) => (() => {
				var n = ac(), r = n.firstChild;
				return Q(n, t === "at" ? "Time" : t === "start" ? "From" : "Until", r), r._$$input = (n) => {
					let r = n.currentTarget.value;
					r && e.change({
						..."at" in e.input ? {} : {
							start: 0,
							end: 1440
						},
						...e.input,
						[t]: t === "end" && r === "00:00" ? 1440 : sc(r)
					});
				}, J(() => cc((e.input[t] ?? (t === "end" ? 1440 : 0)) % 1440), (e) => {
					r.value = e ?? "";
				}), n;
			})()
		}),
		(() => {
			var e = rc();
			return Q(e, () => lc.map((e, r) => (() => {
				var i = oc();
				return i._$$click = () => n(r + 1), Q(i, e), J(() => ({
					e: t().includes(r + 1) ? "true" : "false",
					t: t().length === 1 && t()[0] === r + 1
				}), ({ e, t }, n) => {
					e !== n?.e && Z(i, "aria-pressed", e), t !== n?.t && Z(i, "disabled", t);
				}), i;
			})()), null), e;
		})()
	];
}
Bo(["input", "click"]);
// rules/WhenFields.jsx
var fc = /* @__PURE__ */ X("<fieldset class=when><legend>When</legend><button type=button>Add input</button><!><!><!>"), pc = /* @__PURE__ */ X("<fieldset><!><!><!><!><!>"), mc = /* @__PURE__ */ X("<label>Lua input name<input required pattern=[A-Za-z_][A-Za-z0-9_]* maxLength=23>"), hc = /* @__PURE__ */ X("<button type=button>Remove input"), gc = /* @__PURE__ */ X("<small>Choose a property test instead of “changes” to combine inputs."), _c = /* @__PURE__ */ X("<small> If conditions are checked only then."), vc = /* @__PURE__ */ X("<small>Lua runs when any watched value changes. Read values by name, e.g. event.current.<!>.");
function yc(e) {
	let t = () => Array.isArray(e.when) ? e.when : [e.when ?? {}], n = () => Array.isArray(e.when);
	function r(t) {
		if (!t.length) {
			e.change(void 0);
			return;
		}
		if (t.length === 1 && !t[0].clock && (e.visual || !n())) {
			let { name: n, ...r } = t[0];
			e.change(r.device ? r : void 0);
			return;
		}
		let r = new Set(t.map((e) => e.name)), i = 1;
		e.change(t.map((e) => {
			if (e.name !== void 0 || !$(e)) return e;
			let t;
			if (e.clock && !r.has("clock")) t = "clock";
			else {
				for (; r.has("input" + i);) i++;
				t = "input" + i++;
			}
			return r.add(t), {
				...e,
				name: t
			};
		}));
	}
	let i = (e, n) => r(t().map((t, r) => r === e ? n : t)), a = () => t().some((e) => e.op === "changes");
	var o = fc(), s = o.firstChild.nextSibling, c = s.nextSibling, l = c.nextSibling, u = l.nextSibling;
	return Q(o, K(q, {
		keyed: !1,
		get each() {
			return t();
		},
		children: (a, o) => {
			let s = (e) => i(o, {
				...e,
				...a().name === void 0 ? {} : { name: a().name }
			}), c = () => [...t().some((e, t) => t !== o && e.clock) ? [] : [uc], ...e.options.filter((e) => !t().some((t, n) => n !== o && $(t) === $(e)))];
			var l = pc(), u = l.firstChild, d = u.nextSibling, f = d.nextSibling, p = f.nextSibling, m = p.nextSibling;
			return Q(l, K(Qs, {
				required: !0,
				get label() {
					return o === 0 ? "When input" : e.visual ? "And input" : "Watched input";
				},
				get value() {
					return $(a());
				},
				get options() {
					return c();
				},
				change: (t) => {
					if (t === "clock:minute") {
						s({
							clock: "minute",
							...e.visual ? { at: 1080 } : {}
						});
						return;
					}
					let n = e.options.find((e) => $(e) === t);
					s(e.visual ? tc(n) : e.select(t));
				}
			}), u), Q(l, (() => {
				var t = Y(() => !!(e.visual && a().clock));
				return () => t() ? K(dc, {
					get input() {
						return a();
					},
					change: s
				}) : void 0;
			})(), d), Q(l, (() => {
				var n = Y(() => !!(e.visual && a().device));
				return () => n() ? K(nc, {
					get options() {
						return e.options;
					},
					get test() {
						return a();
					},
					get trigger() {
						return t().length === 1;
					},
					change: s
				}) : void 0;
			})(), f), Q(l, (() => {
				var t = Y(() => !!(!e.visual && n() && $(a())));
				return () => t() ? (() => {
					var e = mc(), t = e.firstChild.nextSibling;
					return t._$$input = (e) => i(o, {
						...a(),
						name: e.currentTarget.value
					}), J(() => a().name, (e) => {
						t.value = e ?? "";
					}), e;
				})() : void 0;
			})(), p), Q(l, (() => {
				var e = Y(() => !!(t().length > 1 || $(a())));
				return () => e() ? (() => {
					var e = hc();
					return e._$$click = () => r(t().filter((e, t) => t !== o)), e;
				})() : void 0;
			})(), m), l;
		}
	}), s), s._$$click = () => r([...t(), {}]), Q(o, (() => {
		var e = Y(() => !!a());
		return () => e() ? gc() : void 0;
	})(), c), Q(o, (() => {
		var n = Y(() => !!(e.visual && t().length > 1));
		return () => n() ? (() => {
			var e = _c(), n = e.firstChild;
			return Q(e, () => t().some((e) => e.at !== void 0) ? "Run at the selected minute if the other When tests are already true." : "Run when all When tests become true together.", n), e;
		})() : void 0;
	})(), l), Q(o, (() => {
		var r = Y(() => !(e.visual || !n()));
		return () => r() ? (() => {
			var e = vc(), n = e.firstChild.nextSibling;
			return Q(e, () => t().find((e) => e.name)?.name, n), e;
		})() : void 0;
	})(), u), J(() => t().length >= 4 || a() || t().some((e) => !$(e)), (e) => {
		Z(s, "disabled", e);
	}), o;
}
Bo(["click", "input"]);
// rules/ActionSteps.jsx
var bc = /* @__PURE__ */ X("<fieldset><legend>Then, in order</legend><button type=button>Add step"), xc = /* @__PURE__ */ X("<fieldset data-then-step><legend>Step </legend><!><!><button type=button>Remove step"), Sc = /* @__PURE__ */ X("<label>Delay (seconds)<input required type=number min=1 max=86400 step=1>"), Cc = /* @__PURE__ */ X("<div><!><!>"), wc = /* @__PURE__ */ X("<p>");
function Tc(e) {
	let t = (t, n) => e.change(e.steps.map((e, r) => r === t ? n : e));
	var n = bc(), r = n.firstChild.nextSibling;
	return Q(n, K(q, {
		keyed: !1,
		get each() {
			return e.steps;
		},
		children: (n, r) => (() => {
			var i = xc(), a = i.firstChild, o = a.nextSibling, s = o.nextSibling, c = s.nextSibling;
			return Q(a, r + 1, null), Q(i, K(Qs, {
				label: "Action",
				required: !0,
				get options() {
					return e.options;
				},
				get value() {
					return $(n());
				},
				change: (n) => t(r, n === "delay" ? { delay_s: 1 } : e.select(n) ?? {})
			}), o), Q(i, (() => {
				var e = Y(() => n().delay_s !== void 0);
				return () => e() ? [" ", (() => {
					var e = Sc(), i = e.firstChild.nextSibling;
					return i._$$input = (e) => t(r, { delay_s: e.currentTarget.valueAsNumber }), J(() => n().delay_s, (e) => {
						i.value = e ?? "";
					}), e;
				})()] : void 0;
			})(), s), Q(i, K(To, {
				get when() {
					return e.descriptor(n());
				},
				children: (e) => (() => {
					var i = Cc(), a = i.firstChild, o = a.nextSibling;
					return i._$$input = (i) => t(r, {
						...n(),
						arguments: Hs(i.currentTarget.closest("fieldset"), e().meta.arguments)
					}), Q(i, (() => {
						var t = Y(() => !!n().native);
						return () => t() ? (() => {
							var t = wc();
							return Q(t, () => e().meta.description), t;
						})() : void 0;
					})(), a), Q(i, K(Us, {
						get schema() {
							return e().meta.arguments;
						},
						get defaults() {
							return n().arguments;
						}
					}), o), i;
				})()
			}), c), c._$$click = () => e.change(e.steps.filter((e, t) => t !== r)), i;
		})()
	}), r), r._$$click = () => e.change([...e.steps, {}]), J(() => e.steps.length >= 8, (e) => {
		Z(r, "disabled", e);
	}), n;
}
Bo(["click", "input"]);
// rules/RuleEditor.jsx
var Ec = /* @__PURE__ */ X("<section id=rules class=rules><h2>Automation rules</h2><label>Rule slot<select></select></label><form><label>Title<input maxLength=64></label><label>Enabled<input type=checkbox></label><fieldset class=definition><legend>Rule definition</legend><label>Mode<select><option value=visual>Visual</option><option value=raw>Raw Lua</option></select></label><!><!></fieldset><!><button class=primary>Save rule</button><button type=button>Delete rule</button><small>"), Dc = /* @__PURE__ */ X("<option>: <!>"), Oc = /* @__PURE__ */ X("<label>Lua body<textarea required>"), kc = /* @__PURE__ */ X("<fieldset class=conditions><button type=button>Add condition"), Ac = /* @__PURE__ */ X("<legend>If all conditions hold"), jc = /* @__PURE__ */ X("<fieldset><!><button type=button>Remove condition"), Mc = /* @__PURE__ */ X("<details><summary>View saved rule as Lua</summary><pre>"), Nc = () => ({
	mode: "visual",
	enabled: !0,
	conditions: [],
	title: ""
});
function Pc() {
	let [e, t] = yo(1), [n, r] = yo(Nc()), i = vo(() => Zs("properties")), a = vo(() => [...Zs("actions"), ...js().map((e) => ({
		native: e.name,
		label: e.name,
		meta: e
	}))]);
	function o(e, n = ks()) {
		t(e), r(n?.[e - 1] ? { ...n[e - 1] } : Nc());
	}
	Vr(() => {
		o(1);
	});
	async function s(e) {
		let t = await vs.read("fabric://automation/rules");
		As(t), o(e, t);
	}
	let c = (e, t) => r({
		...n(),
		[e]: t
	}), l = (e, t) => {
		let n = e.find((e) => $(e) === t);
		if (!n) return;
		let { label: r, meta: i, ...a } = n;
		return a;
	}, u = () => Array.isArray(n().action) ? n().action : [n().action ?? {}], d = vo(() => [{
		delay_s: 1,
		label: "Delay"
	}, ...a()]), f = (e) => a().find((t) => $(t) === $(e));
	async function p(t) {
		let r = { ...n() };
		if (delete r.diagnostic, delete r.generated, !r.when || Array.isArray(r.when) && !r.when.length || r.mode === "visual" && !r.action) throw Error("Select a trigger and action");
		if (r.mode === "visual") {
			let e = u().map((e, n) => {
				if (e.delay_s !== void 0) return e;
				let r = f(e);
				if (!r) throw Error("Select an available action for each step");
				return {
					...e,
					arguments: Hs(t.querySelectorAll("[data-then-step]")[n], r.meta.arguments)
				};
			});
			if (!e.length) throw Error("Add an action or delay");
			r.action = e.length === 1 ? e[0] : e, delete r.source;
		}
		await vs.call("rule.save", {
			slot: e(),
			definition: r
		}), await s(e()), ws("Rule saved on board");
	}
	var m = Ec(), h = m.firstChild.nextSibling, g = h.firstChild.nextSibling, _ = h.nextSibling, v = _.firstChild, y = v.firstChild.nextSibling, b = v.nextSibling, ee = b.firstChild.nextSibling, te = b.nextSibling, ne = te.firstChild.nextSibling, re = ne.firstChild.nextSibling, ie = ne.nextSibling, x = ie.nextSibling, ae = te.nextSibling, oe = ae.nextSibling, se = oe.nextSibling, ce = se.nextSibling;
	return g.addEventListener("change", (e) => o(+e.currentTarget.value)), Q(g, K(q, {
		get each() {
			return (ks() ?? []).map((e, t) => t + 1);
		},
		children: (e) => (() => {
			var t = Dc(), n = t.firstChild, r = n.nextSibling;
			return t.value = e, Q(t, e, n), Q(t, () => ks()?.[e - 1]?.title || "Untitled / empty", r), t;
		})()
	})), _.addEventListener("submit", (e) => {
		e.preventDefault(), Ns(() => p(e.currentTarget));
	}), y._$$input = (e) => c("title", e.currentTarget.value), ee.addEventListener("change", (e) => c("enabled", e.currentTarget.checked)), re.addEventListener("change", (e) => {
		let t = e.currentTarget.value, i = n();
		(i.when || i.action || i.conditions?.length || i.source) && !confirm("Clear this draft and switch mode? The saved rule keeps running until you save a replacement.") ? e.currentTarget.value = i.mode : r({
			mode: t,
			title: i.title ?? "",
			enabled: i.enabled,
			...t === "visual" ? { conditions: [] } : { source: "" }
		});
	}), Q(te, K(yc, {
		get visual() {
			return n().mode === "visual";
		},
		get when() {
			return n().when;
		},
		get options() {
			return i();
		},
		select: (e) => l(i(), e),
		change: (e) => c("when", e)
	}), ie), Q(te, (() => {
		var e = Y(() => n().mode === "raw");
		return () => e() ? (() => {
			var e = Oc(), t = e.firstChild.nextSibling;
			return t._$$input = (e) => c("source", e.currentTarget.value), J(() => ({
				e: Array.isArray(n().when) ? "-- event.current.<input name>, event.previous.<input name>" : "if not event.current then return end",
				t: n().source ?? "",
				a: Eo()
			}), ({ e, t: n, a: r }, i) => {
				e !== i?.e && Z(t, "placeholder", e), n === i?.t && r || (t.value = n ?? "");
			}), e;
		})() : void 0;
	})(), x), Q(_, (() => {
		var e = Y(() => n().mode === "visual");
		return () => e() ? (() => {
			var e = kc(), t = e.firstChild;
			return Q(e, (() => {
				var e = Y(() => !!n().conditions?.length);
				return () => e() ? [Ac(), K(q, {
					keyed: !1,
					get each() {
						return n().conditions;
					},
					children: (e, t) => {
						let r = (e) => c("conditions", n().conditions.map((n, r) => r === t ? e : n));
						var a = jc(), o = a.firstChild, s = o.nextSibling;
						return Q(a, K(Qs, {
							required: !0,
							label: t === 0 ? "If input" : "And condition",
							get options() {
								return [uc, ...i()];
							},
							get value() {
								return $(e());
							},
							change: (e) => r(e === "clock:minute" ? {
								clock: "minute",
								start: 1080,
								end: 1320
							} : tc(i().find((t) => $(t) === e)) ?? {})
						}), o), Q(a, (() => {
							var t = Y(() => !!e().clock);
							return () => t() ? K(dc, {
								condition: !0,
								get input() {
									return e();
								},
								change: r
							}) : K(nc, {
								get options() {
									return i();
								},
								get test() {
									return e();
								},
								change: r
							});
						})(), s), s._$$click = () => c("conditions", n().conditions.filter((e, n) => n !== t)), a;
					}
				})] : void 0;
			})(), t), t._$$click = () => c("conditions", [...n().conditions ?? [], {}]), J(() => (n().conditions?.length ?? 0) >= 4, (e) => {
				Z(t, "disabled", e);
			}), e;
		})() : void 0;
	})(), ae), Q(_, (() => {
		var e = Y(() => n().mode === "visual");
		return () => e() ? K(Tc, {
			get steps() {
				return u();
			},
			get options() {
				return d();
			},
			descriptor: f,
			select: (e) => l(a(), e),
			change: (e) => c("action", e)
		}) : void 0;
	})(), oe), se._$$click = () => Ns(async () => {
		confirm("Delete this rule?") && (await vs.call("rule.remove", { slot: e() }), await s(e()));
	}), Q(_, (() => {
		var t = Y(() => !!ks()?.[e() - 1]?.generated);
		return () => t() ? (() => {
			var t = Mc(), n = t.firstChild.nextSibling;
			return Q(n, () => ks()[e() - 1].generated), t;
		})() : void 0;
	})(), ce), Q(ce, () => ks()?.[e() - 1]?.diagnostic), J(() => ({
		e: e(),
		t: n().title || "",
		a: n().enabled,
		o: n().mode,
		i: Eo()
	}), ({ e, t, a: n, o: r, i }, a) => {
		e === a?.e && i || Jo(g, "value", e), t === a?.t && i || (y.value = t ?? ""), n === a?.a && i || (ee.checked = n), r === a?.o && i || Jo(re, "value", r);
	}), m;
}
Bo(["input", "click"]);
// DevicePanel.jsx
var Fc = /* @__PURE__ */ X("<article><h3> <small>#<!> · <!><!></small></h3><!><button>Remove node"), Ic = /* @__PURE__ */ X("<button type=button>Edit name &amp; room"), Lc = /* @__PURE__ */ X("<form><label>Name<input name=name required maxlength=63></label><label>Room<input name=room maxlength=63></label><button>Save identity</button><button type=button>Cancel"), Rc = /* @__PURE__ */ X("<fieldset><legend> · endpoint <!></legend><div class=values>"), zc = /* @__PURE__ */ X("<span class=value>: <strong></strong> <!>"), Bc = /* @__PURE__ */ X("<form><button>"), Vc = /* @__PURE__ */ X("<section id=devices><h2>Devices <small></small></h2><form><label>Onboarding code<input name=code required></label><button>Commission</button><button type=button>Cancel</button></form><div class=\"mt-3 grid items-start gap-3 grid-cols-[repeat(auto-fit,minmax(min(100%,22rem),1fr))]\">"), Hc = /* @__PURE__ */ X("<label class=\"mt-2 max-w-60\">Filter by room<select><option value>All rooms"), Uc = /* @__PURE__ */ X("<option>"), Wc = /* @__PURE__ */ X("<p>No devices reported yet.");
function Gc(e) {
	let t = e.device, n = () => Ds[t.device_id], [r, i] = yo(null);
	var a = Fc(), o = a.firstChild, s = o.firstChild, c = s.nextSibling, l = c.firstChild.nextSibling, u = l.nextSibling.nextSibling, d = u.nextSibling, f = o.nextSibling, p = f.nextSibling;
	return Q(o, () => t.name, s), Q(c, () => t.device_id, l), Q(c, (() => {
		var e = Y(() => !n());
		return () => e() ? "loading" : n().online ? "online" : "offline";
	})(), u), Q(c, (() => {
		var e = Y(() => !!t.room);
		return () => e() ? " · " + t.room : "";
	})(), d), Q(a, K(To, {
		get when() {
			return r();
		},
		get fallback() {
			var e = Ic();
			return e._$$click = () => i({
				name: t.name,
				room: t.room
			}), e;
		},
		children: (e) => {
			var n = Lc(), r = n.firstChild, a = r.firstChild.nextSibling, o = r.nextSibling, s = o.firstChild.nextSibling, c = o.nextSibling.nextSibling;
			return n.addEventListener("submit", (e) => {
				e.preventDefault();
				let { name: n, room: r } = e.currentTarget.elements, a = {
					device_id: t.device_id,
					name: n.value.trim(),
					room: r.value.trim()
				};
				Ns(async () => {
					await vs.call("device.set_identity", a), i(null);
				});
			}), c._$$click = () => i(null), J(() => ({
				e: e().name,
				t: e().room,
				a: Eo()
			}), ({ e, t, a: n }, r) => {
				e === r?.e && n || (a.value = e ?? ""), t === r?.t && n || (s.value = t ?? "");
			}), n;
		}
	}), f), Q(a, K(q, {
		get each() {
			return Object.keys(n()?.endpoints ?? {});
		},
		children: (e) => K(q, {
			get each() {
				return Object.keys(n()?.endpoints?.[e]?.clusters || {});
			},
			children: (r) => {
				let i = () => n()?.endpoints?.[e]?.clusters?.[r];
				var a = Rc(), o = a.firstChild, s = o.firstChild, c = s.nextSibling, l = o.nextSibling;
				return Q(o, r, s), Q(o, e, c), Q(l, K(q, {
					get each() {
						return Object.entries(i()?.properties ?? {});
					},
					children: ([e, t]) => (() => {
						var n = zc(), r = n.firstChild, i = r.nextSibling, a = i.nextSibling.nextSibling;
						return Q(n, e, r), Q(i, () => String(t.label ?? t.value ?? "unknown")), Q(n, () => t.unit, a), n;
					})()
				})), Q(a, K(q, {
					get each() {
						return Object.keys(i()?.actions || {});
					},
					children: (a) => (() => {
						var o = Bc(), s = o.firstChild;
						return o.addEventListener("submit", (n) => {
							n.preventDefault();
							let o = Hs(n.currentTarget, i().actions[a].arguments);
							Ns(() => Fs("device.action", {
								device_id: t.device_id,
								endpoint_id: +e,
								cluster: r,
								action: a,
								arguments: o
							}, "control"));
						}), Q(o, K(Us, { get schema() {
							return i().actions[a].arguments;
						} }), s), Q(s, a), J(() => !n()?.online, (e) => {
							Z(s, "disabled", e);
						}), o;
					})()
				}), null), a;
			}
		})
	}), p), p._$$click = () => {
		confirm("Remove the underlying Matter node and all sibling devices?") && Ns(() => Fs("device.remove", { device_id: t.device_id }, "membership"));
	}, a;
}
function Kc() {
	let [e, t] = yo(""), n = () => [...new Set(Ts.map((e) => e.room).filter(Boolean))].sort(), r = () => n().includes(e()) ? e() : "";
	var i = Vc(), a = i.firstChild, o = a.firstChild.nextSibling, s = a.nextSibling, c = s.firstChild.nextSibling.nextSibling, l = s.nextSibling;
	return Q(o, () => Ts.length), s.addEventListener("submit", (e) => {
		e.preventDefault();
		let t = e.currentTarget.code.value;
		Ns(() => Fs("commission.start", { code: t }, "membership"));
	}), c._$$click = () => Ns(() => vs.call("commission.cancel", {})), Q(i, (() => {
		var e = Y(() => !!n().length);
		return () => e() ? (() => {
			var e = Hc(), i = e.firstChild.nextSibling;
			return i.addEventListener("change", (e) => t(e.currentTarget.value)), Q(i, K(q, {
				get each() {
					return n();
				},
				children: (e) => (() => {
					var t = Uc();
					return t.value = e, Q(t, e), J(() => e === r(), (e) => {
						t.selected = e;
					}), t;
				})()
			}), null), J(() => r(), (e) => {
				Jo(i, "value", e);
			}), e;
		})() : void 0;
	})(), l), Q(l, K(q, {
		get each() {
			return Ts.filter((e) => !r() || e.room === r());
		},
		get fallback() {
			return Wc();
		},
		children: (e) => K(Gc, { device: e })
	})), i;
}
Bo(["click"]);
// app.jsx
var qc = /* @__PURE__ */ X("<header class=\"sticky top-0 z-10 flex min-h-13 items-center gap-2 sm:gap-3\"><h1>Local Fabric</h1><span class=board>ESP32-S31</span><span class=connection>"), Jc = /* @__PURE__ */ X("<output aria-live=polite>"), Yc = /* @__PURE__ */ X("<nav class=\"ml-auto flex gap-3\"aria-label=\"Control panels\"><a href=#devices>Devices"), Xc = /* @__PURE__ */ X("<a href=#rules>Rules"), Zc = /* @__PURE__ */ X("<section><h2>New access token</h2><p>Copy this before dismissing. If you lose it, run <code>fabric token</code> on the board’s UART.</p><input aria-label=\"New access token\"readonly><button>Dismiss"), Qc = /* @__PURE__ */ X("<details><summary>Settings</summary><p>Rotate the shared access token for this board. You will need to update every client.</p><button type=button>Rotate access token"), $c = /* @__PURE__ */ X("<section><form><label>Board access token (UART: fabric token)<input type=password name=secret required autocomplete=off></label><button>Connect");
function el() {
	let [e, t] = yo(""), [n, r] = yo(!1);
	async function i() {
		if (!n() && confirm("Replace this board’s access token? Every client will be disconnected.")) {
			r(!0);
			try {
				let e = await fetch("/settings/token/rotate", {
					method: "POST",
					cache: "no-store",
					headers: { Authorization: "Bearer " + ys() }
				});
				if (!e.ok) throw Error(e.status + " " + await e.text());
				t(await e.text()), bs(""), ws("Token replaced. Copy the new token, then reconnect.");
			} finally {
				r(!1);
			}
		}
	}
	return Is(), [
		(() => {
			var e = qc(), t = e.firstChild.nextSibling.nextSibling;
			return Q(t, (() => {
				var e = Y(() => !!ys());
				return () => e() ? xs() : "Locked";
			})()), Q(e, (() => {
				var e = Y(() => !!ys());
				return () => e() ? (() => {
					var e = Yc(), t = e.firstChild;
					return $o(t), Q(e, (() => {
						var e = Y(() => !!ks());
						return () => e() ? (() => {
							var e = Xc();
							return $o(e), e;
						})() : void 0;
					})(), null), e;
				})() : void 0;
			})(), null), e;
		})(),
		(() => {
			var e = Jc();
			return Q(e, Cs), e;
		})(),
		Y(() => Y(() => !!e())() ? (() => {
			var n = Zc(), r = n.firstChild.nextSibling.nextSibling, i = r.nextSibling;
			return r.addEventListener("focus", (e) => e.currentTarget.select()), i._$$click = () => t(""), J(() => e(), (e) => {
				r.value = e ?? "";
			}), n;
		})() : void 0),
		Y(() => Y(() => !!ys())() ? [
			K(To, {
				get when() {
					return xs() === "Live";
				},
				get children() {
					var e = Qc(), t = e.firstChild.nextSibling.nextSibling;
					return t._$$click = () => Ns(i), J(() => n(), (e) => {
						Z(t, "disabled", e);
					}), e;
				}
			}),
			K(Kc, {}),
			K(To, {
				get when() {
					return ks();
				},
				get children() {
					return K(Pc, {});
				}
			})
		] : (() => {
			var e = $c();
			return e.firstChild.addEventListener("submit", (e) => {
				e.preventDefault(), ws(""), t(""), bs(e.currentTarget.secret.value.trim().replace(/^Bearer /, ""));
			}), e;
		})())
	];
}
Ro(el, document.getElementById("app")), Bo(["click"]);
