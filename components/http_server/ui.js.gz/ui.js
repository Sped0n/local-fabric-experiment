// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/error.js
var e = class extends Error {
	constructor(e) {
		let t = Error, n = t.stackTraceLimit;
		n && (t.stackTraceLimit = 0), super(), n && (t.stackTraceLimit = n), this.source = e;
	}
}, t = class extends Error {
	constructor(e, t) {
		try {
			var n = String(t instanceof Error ? t.message : t);
		} catch {}
		super(n, { cause: t }), this.source = e;
	}
};
function n(e) {
	return e instanceof t ? e.cause : e;
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/constants.js
var r = 1024, i = 2048, a = 4096, o = 8192, s = 16384, c = 1 << 17, l = 1 << 18, u = 1 << 19, d = 1 << 22, f = 1 << 23, p = 1 << 20, m = 1024, h = 4096, g = 1 << 18, _ = 1 << 21, v = 1 << 22, y = {}, b = {}, ee = Symbol("refresh"), te = Set;
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/owner.js
function ne(e) {
	let t = e.pe;
	for (; t;) t.R |= 32, ne(t), t = t.Ge;
}
var re;
function ie(e) {
	try {
		e();
	} catch (e) {
		re || (re = [e]), D();
	}
}
function ae(e) {
	let t = re;
	if (re = void 0, t && !e) throw t[0];
}
function oe(e, t = !1, n) {
	let r = e.R;
	if (r & 64) return;
	t && (n || e.T === null || e.T.me === null && e.T.Le === null || oe(e, !1, !0), e.R = r | 64, e.X && (dn(e), (e.m & 1 && e.T?.Re != null || r & 2048 || Ot.length) && D()));
	let i = n ? e.T.me : e.pe;
	for (n ? e.T.me = null : e.pe = null; i;) i.l &= -33, Gt(i, T), tn(i), i.Me = i, oe(i, !0), i = i.Ge;
	if (n || (e.be = 0), t && !n && !(r & 32) && e._parent !== null && !(e._parent.R & 64)) {
		let t = e.Me, n = e.Ge;
		t === null ? e._parent.pe = n : t.Ge = n, n !== null && (n.Me = t), e.Me = null;
	}
	if (ce(e, n), t && e.ze) {
		let t = e.ze;
		e.ze = void 0, ie(t);
	}
}
function se(e, t) {
	let n = e.pe;
	t.Me = null, t.Ge = n, n !== null && (n.Me = t), e.pe = t;
}
function ce(e, t) {
	let n = t ? e.T.Le : e.ke;
	if (n) {
		if (t ? e.T.Le = null : e.ke = null, Array.isArray(n)) for (let e = n.length - 1; e >= 0; e--) ie(n[e]);
		else ie(n);
	}
}
function le(e, t) {
	for (; e.l & 4 && e._parent;) e = e._parent;
	if (e.id != null) return fe(e.id, t ? e.be++ : e.be);
	throw Error();
}
function ue(e) {
	return le(e, !0);
}
function de(e, t, n) {
	return e?.id ?? (t ? n?.id : n?.id == null ? void 0 : ue(n));
}
function fe(e, t) {
	let n = t.toString(36), r = n.length - 1;
	return e + (r ? String.fromCharCode(64 + r) : "") + n;
}
function x() {
	return k ? A : null;
}
function pe() {
	return A;
}
function me(e, t = A) {
	return t && (t.ke ? Array.isArray(t.ke) ? t.ke.push(e) : t.ke = [t.ke, e] : t.ke = e), e;
}
function he(e) {
	return !!(e.R & 64);
}
function ge(e = !0) {
	oe(this, e), re && !O.Y && ae();
}
function _e(e) {
	let t = A, n = e?.transparent ?? !1, r = {
		id: de(e, n, t),
		l: n ? 4 : 0,
		R: 0,
		Qe: !0,
		Ke: t?.Qe ? t.Ke : t,
		pe: null,
		Ge: null,
		Me: null,
		ke: null,
		A: t?.A || b,
		be: 0,
		T: null,
		_parent: t,
		dispose: ge
	};
	return t && se(t, r), r;
}
function ve(e, t) {
	let n = _e(t);
	return gr(n, () => e(ge.bind(n, !0)));
}
// \0@oxc-project+runtime@0.156.0/helpers/esm/typeof.js
function ye(e) {
	"@babel/helpers - typeof";
	return ye = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
		return typeof e;
	} : function(e) {
		return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
	}, ye(e);
}
// \0@oxc-project+runtime@0.156.0/helpers/esm/toPrimitive.js
function be(e, t) {
	if (ye(e) != "object" || !e) return e;
	var n = e[Symbol.toPrimitive];
	if (n !== void 0) {
		var r = n.call(e, t || "default");
		if (ye(r) != "object") return r;
		throw TypeError("@@toPrimitive must return a primitive value.");
	}
	return (t === "string" ? String : Number)(e);
}
// \0@oxc-project+runtime@0.156.0/helpers/esm/toPropertyKey.js
function xe(e) {
	var t = be(e, "string");
	return ye(t) == "symbol" ? t : t + "";
}
// \0@oxc-project+runtime@0.156.0/helpers/esm/defineProperty.js
function Se(e, t, n) {
	return (t = xe(t)) in e ? Object.defineProperty(e, t, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[t] = n, e;
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/scheduler.js
var Ce = null, we = null, Te = null, Ee = null, De = null, Oe = null, ke = null, Ae = null, je = null, Me = null, Ne = null, Pe = null, Fe = null, Ie = null;
function Le(e, t) {
	Fe = e, Ie = t;
}
var Re = null, ze = null, Be = null, Ve = null, He = null, Ue = null, We = void 0, Ge = [];
function Ke(e, t = null) {
	let n = {
		ln: [],
		rn: [[], []],
		fn: [],
		eo: null,
		_parent: t,
		P: e,
		Pe: null,
		tt: 0,
		nt: !1,
		nn: null,
		Ue: !1,
		un: !1,
		I: null
	};
	return e || Ge.push(n), n;
}
var qe = null, S = null, Je = null;
function Ye(e, t) {
	if (O.Y && !t || S !== null) return Ze(e);
	Je === null ? Je = w(e) : Qe(w(e), Je), D();
}
function C(e) {
	return e.T.Re = w(e.T.Re);
}
function Xe(e) {
	return e = w(e), Ge.indexOf(e) === -1 ? null : e;
}
function w(e) {
	for (; e.eo !== null;) e = e.eo;
	return e;
}
function Ze(e) {
	let t = S;
	t === null ? S = e === null ? Ke(!1) : w(e) : e !== null && Qe(w(e), t), O.Y || D();
}
function Qe(e, t) {
	var n, r;
	e = w(e), t = w(t), e === t || e.P || t.P || (e.eo = t, t.tt += e.tt, (n = t).nt || (n.nt = e.nt), Dt(t.ln, e.ln), Dt(t.rn[0], e.rn[0]), Dt(t.rn[1], e.rn[1]), Dt(t.fn, e.fn), e.I !== null && Dt((r = t).I ?? (r.I = []), e.I), Ge.splice(Ge.indexOf(e), 1));
}
function $e(e) {
	let t = et;
	et ?? (et = e);
	let n = e.tt !== 0 || nt(e.ln, e) || !!De?.(e);
	return et = t, n;
}
var et = null;
function tt(e, t) {
	let n = e.T?.se;
	if (n === void 0) return !0;
	for (let e of n) {
		let n = e.T?.Re;
		if (n == null || w(n) === t) return !0;
	}
	return !1;
}
function nt(e, t, n = !1) {
	for (let r = 0; r < e.length; r++) {
		let i = e[r];
		if (!(!(i.m & 1) || i.R & 64 || i.l & 8192 || i.T.Re !== null && C(i) !== t || n && !tt(i, t))) {
			if (i.i === 1) {
				if (rt(i, et ?? t)) return !0;
			} else for (let e = i.o; e !== null; e = e.t) {
				let n = e.u;
				if ((n.i === 1 && n.m & 1 || n.R & 2048 || n.l & 16384 && n.m === 1) && (e.Ne === n.de || n.T?.U != null) && !(n.R & 64) && rt(n, et ?? t)) return !0;
			}
		}
	}
	return !1;
}
function rt(e, t) {
	return !Me?.(e) && !(e.R & 32 && it(e, t));
}
function it(e, t) {
	for (; e?.R & 32;) e = e._parent;
	return e?.l & 256 && e.T?.Re != null && C(e) === w(t);
}
var at = [];
function ot(e) {
	at.push(e);
}
var st = [];
function ct(e) {
	Gt(e, T), e.R &= -4, st.push(e);
}
function lt(e, t) {
	e.l |= 256, ut(e, t);
}
function ut(e, t) {
	let n = j(e);
	n.Re !== t && (n.Re = t, t.ln.push(e));
}
function dt(e, t) {
	for (let n = e.pe; n !== null; n = n.Ge) n.T?.Re?.P || (n.X !== void 0 && (n.l & 256 || lt(n, t), n.l |= p), dt(n, t));
}
var T = {
	et: Array(2e3).fill(void 0),
	p: !1,
	Fe: 0,
	Et: 0
}, E = 0, ft = !1, pt = !1, mt = !1, ht = 0, gt = 0, _t = 0;
function vt(e) {
	_t = e;
}
function D() {
	pt ? St() : ft || (ft = !0, !ht && !O.Y && queueMicrotask(zt));
}
var yt = Symbol.for("solid-js/root-error-hook"), bt = "[REACTIVITY_HALTED]";
function xt(e) {
	if (pt) return;
	pt = !0, ae(!0);
	let t = bt, n = e !== void 0 && globalThis.reportError;
	n || e === void 0 ? console.error(t) : console.error(t, e), n && n(e);
}
function St() {
	mt || (mt = !0, console.error(bt));
}
var Ct = class e {
	constructor() {
		Se(this, "rn", [[], []]), Se(this, "Y", !1);
	}
	flush() {
		if (!this.Y) {
			this.Y = !0, ar(), qe = null, Je = null;
			try {
				sn(), Jt(T, e._e), this.settle(), E++, ft = T.Et >= T.Fe || Ot.length !== 0, this.run(1), this.run(2);
			} finally {
				this.Y = !1, Je = null;
			}
		}
	}
	settle() {
		Te?.() && Jt(T, e._e);
		let t = S;
		S = null, we?.(t);
		let n = t !== null && !t.P ? w(t) : null;
		if (n !== null) {
			let e = Ot.length;
			for (let t = 0; t < e; t++) {
				let e = Ot[t];
				if (!(e.l & 2304) && (e.T === null || e.T.Re === null || !e.T.Re.P)) {
					if (e.ue === y && e.m & 4 && e.i !== 1) continue;
					if (e.ue !== y && !(e.m & 5) && e.T?.me == null && e.T?.Le == null && !e.T?.Te && mr(e, e.le, e.ue)) {
						e.ue = y, e.l &= -129;
						continue;
					}
					lt(e, n);
				}
				e.l & 128 && dt(e, n);
			}
			Ot.length = 0, Fe?.(n), st.splice(0);
		} else {
			Rt();
			for (let e = 0; e < at.length; e++) {
				let t = at[e];
				t.T?.U == null && !t.Ae && en(t);
			}
		}
		at.length && (at.length = 0);
		let r = this.rn;
		this.rn = [[], []];
		for (let e = Ge.length - 1; e >= 0; e--) {
			let t = Ge[e];
			$e(t) || (Ge.splice(e, 1), Ee?.(t), Tt(t), e = Ge.length);
		}
		Ie?.();
		let i = n && Xe(n);
		Re?.(i);
		let a = i !== null;
		for (let e = 0; e < 2; e++) a && Dt(i.rn[e], r[e]), this.rn[e] = a || this.rn[e].length ? [].concat(a ? [] : r[e], this.rn[e]) : r[e];
		if (st.length !== 0) {
			let e = st.splice(0).sort((e, t) => e.he - t.he);
			for (let t = 0; t < e.length; t++) e[t].R & 64 || jn(e[t]);
		}
		Ne?.();
	}
	run(e) {
		let t = this.rn[e - 1];
		t.length && (this.rn[e - 1] = [], Bt(t, e));
	}
	enqueue(e, t, n = qe) {
		e && (n?.P ? n : this).rn[e - 1].push(t), D();
	}
	notify(e, t, n, r) {
		return Ae?.(e, n & t, r) ? !0 : t & 1 ? (n & 1 && qe === null && Ze(null), !0) : !1;
	}
};
function wt(e) {
	let t;
	for (let n = 0; n < e.fn.length; n++) {
		let r = e.fn[n], a = r.T?.U?.source;
		if (!(r.R & 64 || r.m & 2 && (r.i || !(r.l & 8388608)) && a !== r && (a?.m ?? 2) & 2) && r.R & 2048) {
			t = 1, e.P || (r.R &= ~i), r.Ae = !1;
			for (let e = r.pe; e !== null; e = e.Ge) e.i && (e.Ae = !1);
			Oe?.(r), Vt(r);
		}
	}
	return e.fn.length = 0, t;
}
function Tt(e) {
	let t = wt(e);
	for (let t = 0; t < e.ln.length; t++) {
		let n = e.ln[t];
		n.T.Re !== null && C(n) === e && (n.T.Re = null, Lt(n));
	}
	S === e && (S = null), t ? O.rn[1].push(() => Et(e)) : Et(e);
}
function Et(e) {
	for (let t = 0; t < 2; t++) Dt(O.rn[t], e.rn[t]), e.rn[t] = [];
}
function Dt(e, t) {
	for (let n = 0; n < t.length; n++) e.push(t[n]);
}
var Ot = [];
function kt(e, t) {
	t.fn.push(e), e.R |= i;
}
function At(e) {
	Ot.push(e), O.Y || er();
}
var jt = 0;
function Mt() {
	jt++;
}
function Nt(e) {
	e.we = jt;
	let t = !!(e.l & 512) && e.T?.De !== void 0;
	for (let n = e.o; n !== null; n = n.t) {
		let r = n.u;
		r.R & 4 && n.Ne === r.de && (n !== r._ || !e.X) && (r.R |= a), t && r.l & 8 ? r.R |= 256 : (Vt(r), r.R & 8388608 && qt(r._parent, 1));
	}
}
function Pt(e) {
	e.Ae = !0, O.enqueue(e.i, e.W ?? (e.W = Ct.q.bind(null, e)));
}
function Ft(e) {
	return e.ue !== y && (e.le = e.ue, e.ue = y);
}
function It(e) {
	return !(e.m & 4) && !!e.T?.Ee && !e.T.Ve && (e.ue = y, !0);
}
function Lt(e) {
	if (!e.X) {
		e.l &= -385, Ft(e);
		return;
	}
	let t = !!(e.m & 1) && (e.ue === y || It(e)), n = e.l & _;
	if (!t && e.T && (e.T.Te = null), e.l = t ? e.l & -1048833 | m : e.l & -3147137, n) {
		let t = e.ue;
		e.ue = y, e.ie = E + 1, On(e, 2, t);
	} else Ft(e) && (e.m &= -5, e.T != null && (e.T.Ve = !1, e.T.je = y), e.i && e.i !== 3 && Pt(e));
	e.Ie = !1, e.R &= ~r, e.T?.U ?? en(e), e.m & 1 || (e.m &= -5), t || e.T == null || e.T.me === null && e.T.Le === null || Ct.Ce(e, !1, !0);
}
function Rt() {
	for (let e = 0; e < Ot.length; e++) {
		let t = Ot[e];
		t.l & 2304 || Lt(t);
	}
	Ot.length = 0;
}
var O = new Ct();
function zt(e) {
	if (gt > 0) return e ? e() : void 0;
	if (e) {
		ht++;
		try {
			return e();
		} finally {
			try {
				zt();
			} finally {
				ht--;
			}
		}
	}
	if (!O.Y && !pt) {
		for (; ft;) O.flush();
		ae();
	}
}
function Bt(e, t) {
	for (let n = 0; n < e.length; n++) e[n](t);
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/heap.js
function Vt(e) {
	T.Fe > e.he && (T.Fe = e.he), Ut(e, T);
}
function Ht(e, t) {
	let n = (e._parent?.Qe ? e._parent.Ke?.he : e._parent?.he) ?? -1;
	n >= e.he && (e.he = n + 1);
	let r = e.he, i = t.et[r];
	if (i === void 0) t.et[r] = e;
	else {
		let t = i.We;
		t.ve = e, e.We = t, i.We = e;
	}
	r > t.Et && (t.Et = r);
}
function Ut(e, t) {
	let n = e.R;
	n & 12 || (n & 1 ? e.R = n & -4 | 10 : (e.R = n | 8, t.p && qt(e)), n & 16 || Ht(e, t));
}
function Wt(e, t) {
	let n = e.R;
	n & 28 || (e.R = n | 16, Ht(e, t));
}
function Gt(e, t) {
	let n = e.R;
	if (!(n & 24)) return;
	e.R = n & -25;
	let r = e.he;
	if (e.We === e) t.et[r] = void 0;
	else {
		let n = e.ve, i = t.et[r], a = n ?? i;
		e === i ? t.et[r] = n : e.We.ve = n, a.We = e.We;
	}
	e.We = e, e.ve = void 0;
}
function Kt(e) {
	if (!e.p) {
		e.p = !0;
		for (let t = 0; t <= e.Et; t++) for (let n = e.et[t]; n !== void 0; n = n.ve) n.R & 8 && qt(n);
	}
}
function qt(e, t = 2) {
	let n = e.R;
	if (!((n & 3) >= t)) {
		e.R = n & -4 | t;
		for (let t = e.o; t !== null; t = t.t) qt(t.u, 1);
	}
}
function Jt(e, t) {
	for (e.p = !1, e.Fe = 0; e.Fe <= e.Et; e.Fe++) {
		let n = e.et[e.Fe];
		for (; n !== void 0;) n.R & 8 ? t(n) : Yt(n, e), n = e.et[e.Fe];
	}
	e.Et = 0;
}
function Yt(e, t) {
	Gt(e, t);
	let n = e.he;
	for (let t = e.C; t; t = t.G) {
		let e = t.S;
		e.X && e.he >= n && (n = e.he + 1);
	}
	if (e.he !== n) {
		e.he = n, Xt(e, n);
		for (let n = e.o; n !== null; n = n.t) n.u !== e._parent && Wt(n.u, t);
	}
}
function Xt(e, t) {
	for (let n = e.pe; n; n = n.Ge) if (n.Qe) Xt(n, t);
	else if (n.he <= t) {
		let e = n.R & 24;
		Gt(n, T), n.he = t + 1, e && (e & 8 ? Ut : Wt)(n, T), Xt(n, t + 1);
	}
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/graph.js
var Zt;
function Qt(e) {
	Zt = e;
}
function $t(e) {
	let t = e.S, n = e.G, r = e.t, i = e.en;
	return r === null ? t.Ze = i : r.en = i, i === null ? (t.o = r, r === null && (t.l & 4096 ? Zt(t) : t.T?.Ye && ie(t.T.Ye), t.X && t.l & 32 && !(t.R & 32) && !(t.m & 1) && (nn ? nn.push(t) : an(t)))) : i.t = r, n;
}
function en(e) {
	let t = e._, n = t === null ? e.C : t.G;
	if (n !== null) {
		do
			n = $t(n);
		while (n !== null);
		t === null ? e.C = null : t.G = null;
	}
}
function tn(e) {
	e.C && (e._ = null, en(e));
}
var nn = null, rn = (e) => nn = e;
function an(e) {
	Gt(e, T), tn(e), oe(e, !0);
}
var on = new te();
function sn() {
	if (on.size !== 0) {
		for (let e of on) !e.o && e.l & 32 && !(e.m & 1) && !(e.R & 96) && an(e);
		on.clear();
	}
}
function cn(e, t) {
	let n = t._;
	if (n !== null && n.S === e) return;
	let r = null, i = t.R & 4;
	if (i && (r = n === null ? t.C : n.G, r !== null && r.S === e)) {
		r.Ne = t.de, t._ = r;
		return;
	}
	let a = e.Ze;
	if (a !== null && a.u === t && (!i || a.Ne === t.de)) return;
	let o = t._ = e.Ze = {
		S: e,
		u: t,
		G: r,
		en: a,
		t: null,
		Ne: t.de
	};
	n === null ? t.C = o : n.G = o, a === null ? e.o = o : a.t = o, Mt();
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/async.js
function ln(e, t) {
	var n;
	return !e.T?.se?.has(t) && (((n = j(e)).se ?? (n.se = new te())).add(t), !0);
}
function un(e, t) {
	let n = e.T?.se;
	return n?.delete(t) ? (n.size || (e.T.se = void 0), !0) : !1;
}
function dn(e) {
	e.T !== null && (e.T.Ee = null);
}
function fn(e) {
	e.T !== null && (e.T.se = void 0);
}
function pn(e, t) {
	for (let n = e.C; n; n = n.G) {
		let e = n.S;
		if (e === t || e.T?.se?.has(t)) return !0;
	}
	return !1;
}
function mn(e, t) {
	j(e).fe = !0, t.source && ln(e, t.source), e.m & 2 || hn(e, t.source, t);
}
function hn(t, n, r) {
	if (!n) {
		t.T !== null && (t.T.U = null);
		return;
	}
	let i = r instanceof e && r.source === n ? r : t.T?.U;
	j(t).U = i instanceof e && i.source === n ? i : new e(n);
}
function gn(e, t) {
	for (let n = e.o; n !== null; n = n.t) t(n.u, n);
}
function _n(e, t) {
	let n = new te(), r = (e) => {
		let i = n.has(e);
		t(e, i) !== !1 && !i && (n.add(e), gn(e, r));
	};
	gn(e, r);
}
function vn(e) {
	e.X && e.l & 32 && !e.o && !(e.R & 32) && !(e.m & 1) && (e.R & 8 ? e.R |= d : an(e));
}
function yn(e) {
	let t;
	if (_n(e, (e, n) => {
		!n && !e.o && e.l & 32 && (t ?? (t = [])).push(e);
	}), t) for (let e of t) vn(e);
}
function bn(e, n, r) {
	return !(e.l & 256 || r && e.R & 16384 && O.Y && !e.rr) || qe ? !1 : (fn(e), e.T && (e.T.fe = !1), (e.m &= 6) & 2 || hn(e), e.ue = n instanceof t ? n : new t(e, n), e.l |= 128 | _, Sn(e), D(), !0);
}
function xn(e, t) {
	let n = !1;
	_n(e, (e, r) => {
		!r && e.T?.U === t && (Vt(e), n = !0);
	}), n && D();
}
function Sn(e, t = e) {
	un(e, t);
	let n = !1, r;
	if (_n(e, (i, a) => {
		if (a || t !== e && pn(i, t) || !un(i, t)) return !1;
		i.ie = E;
		let o = i.T?.se?.values().next().value, s = i.m & 2;
		o ? s || hn(i, o) : (i.m &= -2, s || hn(i), i.l & 256 && Ze(C(i)), i.T?.fe ? (Vt(i), n = !0) : Fe && i.rr?.st(), i.T !== null && (i.T.fe = !1), !i.o && i.l & 32 && (r ?? (r = [])).push(i), Ve?.(i, e));
	}), r) for (let e of r) vn(e);
	n && D();
}
function Cn(e) {
	return typeof e == "object" && !!e && typeof e.then == "function";
}
function wn(e) {
	let t = e.T?.Se;
	t != null && (e.T.Se = null, t());
}
function Tn(t, n, r, i) {
	let a = !1, o = !1;
	if (typeof n == "object" && n && Yn(() => {
		a = n[Symbol.asyncIterator], o = !a && Cn(n);
	}), !o && !a) return t.T !== null && (t.T.Ee = null), t.Ie = !1, n;
	j(t).Ee = n, t.T.ce = _t || 2147483647, t.T.se = void 0;
	let s, c = (r) => {
		if (t.T?.Ee !== n) return;
		let a = r instanceof e;
		a && t.Ie ? (dn(t), mn(t, r), t.ie = E) : ((a || !bn(t, r)) && (On(t, a ? 1 : 2, r), a || oe(t, !1, !0)), a && Sn(t), t.ie = E, a || yn(t), i?.(r, a));
	}, l = (e, i) => {
		if (t.T?.Ee !== n || t.R & 2) return;
		let a = Be && Ot.some((e) => e.ue !== y), o = t.m & 4;
		if (Dn(t), r) {
			try {
				r(e);
			} catch (e) {
				c(e);
				return;
			}
			t.l & 256 || (t.T.Te = null, t.l &= ~m), o && Dn(t, !0);
		} else N(t, () => e);
		t.ue === y && (t.Ie = !1, en(t)), Sn(t), D(), (i || !a) && zt(), i?.();
	}, u = () => t.l & 32 && !t.o && !(t.m & 1) ? (an(t), !0) : !1, d = (e, r) => {
		let i = e[Symbol.asyncIterator](), a = !1, o = !1, d = !r, f = () => {
			if (!o) {
				o = !0;
				try {
					let e = i.return?.();
					Cn(e) && e.then(void 0, () => {});
				} catch {}
			}
		};
		me(f, r), j(t).Se = f;
		let p = () => {
			try {
				u() || m();
			} catch (e) {
				c(e);
			}
		}, m = () => {
			let e, r, f = !1, h = !1, g = !0, _ = i.next();
			if ((Cn(_) ? _ : { then: (e) => void e(_) }).then((r) => {
				if (g && d) e = r, f = !0, r.done && (o = !0);
				else if (t.T?.Ee !== n) return;
				else r.done ? (o = !0, a ? (D(), zt()) : l(void 0), u()) : (a = !0, l(r.value, p));
			}, (e) => {
				g && d ? (r = e, h = !0) : t.T?.Ee === n && (o = !0, c(e), u());
			}), g = !1, h) {
				if (o = !0, c(r), d) throw r;
				return !0;
			}
			return f && !e.done ? (s = e.value, a = !0, m()) : f && e.done;
		}, h = m();
		return d = !1, a || h;
	}, f = null, p = (e, t) => {
		let n = !1;
		if (typeof e == "object" && e && Yn(() => {
			n = e[Symbol.asyncIterator];
		}), !n) return !1;
		s = void 0;
		let r = d(e, t);
		return t || (f = r), !0;
	};
	if (o) {
		let e = !1, r = !1, i, a = !0;
		if (n.then((r) => {
			if (a) s = r, e = !0;
			else {
				try {
					if (t.T?.Ee === n && !(t.R & 64) && p(r, t)) return;
					l(r);
				} catch (e) {
					c(e);
				}
				u();
			}
		}, (e) => {
			a ? (i = e, r = !0) : (c(e), u());
		}), a = !1, r) throw c(i), i;
		e ? p(s) || (t.Ie = !1) : f = !1;
	}
	if (a && p(n), f !== null) {
		if (!f) {
			if (t.Ie) return t.le;
			throw new e(A);
		}
		t.Ie = !1;
	}
	return s;
}
function En(e, t = !1) {
	e.T?.se && fn(e), e.T?.fe && (e.T.fe = !1), e.m = t ? 0 : e.m & 4, e.T?.U && hn(e);
	let n = Hn(e);
	n && n.call(e);
}
function Dn(e, t = !1) {
	let n = e.T?.se;
	n && (n.delete(e), n.size) ? (e.T.fe = !1, t && (e.m = 1), hn(e, n.values().next().value)) : En(e, t);
}
function On(n, r, i) {
	r === 2 && !(i instanceof t) && !(i instanceof e) && (i = new t(n, i));
	let a = r === 1 && i instanceof e && i.source;
	a ? (n.m & 2 && (n.T.Te = n.T.U), ln(n, a)) : fn(n), n.m = r | (r === 2 ? n.m & 12 ? 8 : 0 : r === 1 && n.m & 8 ? 4 : n.m & 4), a ? hn(n, a, i) : j(n).U = i;
	let o = Hn(n);
	o ? o.call(n) : kn(n, r, i);
}
function kn(t, n, r) {
	let i = n === 1 && r instanceof e && r.source;
	gn(t, (e, a) => {
		e.ie = E, e.l & 16384 || n === 1 && a.Ne !== e.de ? (n !== 1 && un(e, t) && Sn(e, t), Vt(e), D()) : i && e.T?.se?.has(i) ? qe === null && (e.l & 2304) == 256 && O.Y && !je?.(e, i.ie === E) && Ze(C(e)) : (i || n !== 1 && (e.T?.U !== r || e.T?.se)) && (At(e), n !== 1 || (e.l & 2304) != 256 || e.i || Ze(C(e)), On(e, n, r), e.rr?.st(n, r));
	});
}
Ct._e = (e) => {
	e.i === 3 ? (Gt(e, T), e.Ae = !0, O.enqueue(2, e.Z)) : e.R & 32 && !(e.R & 65536) ? ct(e) : jn(e);
}, Ct.Ce = oe;
var k = !1, A = null, An;
function jn(t, n = !1) {
	Mt();
	let r = t.i, f, p = qe, m = Ce && (An = n && (p || An)), h = t.l & _;
	if (!n) {
		if (Gt(t, T), t.T !== null && (t.T.Ee = null, wn(t)), t.l & 256) {
			let e = C(t);
			e.P || t.l & 524288 || (t.l & 8421376 ? e !== S && !(t.m & 4 || t.l & 1048576) && (t.ue !== y && Nt(t), t.ue = y, t.l &= -257) : Ye(e, je?.(t, t.m & 4)));
		}
		if (r === 3 || t.l & 128) {
			let e = nn;
			rn(f = []), oe(t), rn(e);
		} else (t.pe !== null || t.ke !== null) && Rn(t);
		t.l & 2097152 && (t.ue = y, t.l ^= _);
	}
	let g = t.m & 4, v = t.m & 2 && t.T?.U, b = !!(t.m & 1) && t.T?.se, ee = t.T?.se?.has(t), te = !1, ne = !!(t.R & 8192) && !((t.m & 1 || t.ue !== y && !(t.R & 1024)) && t.T !== null && !t.T.Ve), re = A;
	A = t, t._ = null, t.de++;
	let ie = t.R & d;
	t.R = 4 | t.R & (32 | o), t.ie = E;
	let ae = t.ue === y ? t.le : t.ue, se = t.he, ce = !1, le = !1, ue = k;
	k = !0;
	try {
		if (t.l & 64) ae = t.X(ae), t.T !== null && (t.T.Ee = null), t.Ie = !1;
		else {
			let e = t.T?.Ee, n = t.X(ae), r = typeof n == "object" && !!n, i = t.T?.Ee !== e;
			ae = i || !r ? n : Tn(t, n), !i && !r && (t.T !== null && (t.T.Ee = null), t.Ie = !1);
		}
		t.m === 0 && t.T === null || En(t, n);
	} catch (n) {
		let r = n instanceof e;
		if (r && t.Ie) mn(t, n);
		else if ((r || !(te = bn(t, n, !0))) && (r && (j(t).fe = !0), On(t, r ? 1 : 2, n), r && ee && !t.T?.Ee && Sn(t)), (r || te) && b) for (let e of b) e !== t && !(t.T?.se?.has(e) && (e.m & 1 || pn(t, e))) && Sn(t, e);
	} finally {
		if (k = ue, ce = (t.R & a) !== 0, le = !!(t.R & (m ? p || r || !(t.m & 1) ? 128 | s : 0 : 128)), t.R = t.R & (96 | i | s | c | l | u) | (n ? t.R & 256 : 0), A = re, f) for (let e of f) vn(e);
		t.T !== null && (t.T.Ve = ne && !!(t.m & 1));
	}
	if (t.R & 64) {
		tn(t), dn(t);
		return;
	}
	let de = !!t.T?.U || te;
	if (!de) {
		let e = t.ue === y, i = e ? t.le : t.ue, a = S ?? Je, o = e && g && !r || !!t.T?.Te || !!(v && a) || !!h || !mr(t, i, ae);
		if (r && o && !(t.R & 262144 && !t.Ae && Object.is(t.ge, ae)) && e && (t.Ae = !t.T?.U, n || O.enqueue(r, t.W ?? (t.W = Ct.q.bind(null, t)), null)), !de) {
			if (o) (n ? !(a !== null && (le || Ln(re)?.R & 128)) : r && t.ue === y) ? t.le = ae : (t.ue = ae, v && (t.T.Te = v), n && (lt(t, a), t.m |= 4, je?.(t, !m && S))), t.o !== null && Nt(t);
			else if (t.he != se) for (let e = t.o; e !== null; e = e.t) Wt(e.u, T);
		}
		if (!o && !t.T?.U && (v && xn(t, v), b)) for (let e of b) e !== t && Sn(t, e);
		ee && !(t.m & 5) && Sn(t);
	}
	if (n && le && t.m & 1) {
		let e = S ?? Je;
		e && !e.P && (r && je?.(t) === 2 || lt(t, e));
	}
	t.T?.U || t.ue !== y || r && t.Ae || (n || r === 3 ? en(t) : ot(t)), (t.ue !== y || t.T !== null && (t.T.me !== null || t.T.Le !== null) || t.m & 5 && (!n || t.m & 1)) && (t.l |= 128, At(t)), ce && (Vt(t), D()), ie && vn(t);
}
function Mn(e) {
	if (!(e.R & 68)) {
		if (e.R & 1) for (let t = e.C; t; t = t.G) {
			let n = t.S;
			if (n.X && Mn(n), e.R & 2) break;
		}
		(e.R & 2 || e.T?.U && e.ie < E && !e.T?.Ee) && jn(e), e.R &= 376 | r | i | s | c | l | u;
	}
}
function Nn(e, t) {
	let n = t?.transparent ?? !1, r = typeof t == "object" && !!t && "loadingValue" in t, i = {
		id: de(t, n, A),
		l: (n ? 4 : 0) | !!t?.ownedWrite | (!A || t?.lazy ? 32 : 0) | (t?.sync ? 64 : 0) | (t?.ae ? 2 : 0) | (t?.xe ?? 0),
		ye: t?.equals ?? Kn,
		ke: null,
		A: A?.A ?? b,
		be: 0,
		X: e,
		le: r ? t.loadingValue : void 0,
		he: 0,
		ve: void 0,
		We: null,
		C: null,
		_: null,
		de: 0,
		o: null,
		Ze: null,
		_parent: A,
		Ge: null,
		Me: null,
		pe: null,
		R: t?.lazy ? 512 : 0,
		m: r ? 0 : 4,
		ie: E,
		ue: y,
		we: -1,
		Ie: r,
		T: null
	};
	return t?.unobserved && (j(i).Ye = t.unobserved), Wn(i, t), i;
}
function j(e) {
	return e.T ?? (e.T = {
		Ee: null,
		Se: null,
		U: void 0,
		fe: void 0,
		se: void 0,
		Ye: void 0,
		De: void 0,
		me: null,
		Le: null,
		Re: null,
		Ve: !1,
		je: y,
		Be: -1,
		ce: 0,
		Ue: !1,
		I: 0,
		Te: null
	});
}
function Pn(e, t) {
	e.R |= 128, (t.m & 4 || e.i !== 1) && Ye(C(t), !e.i && e.m & 4 || je?.(e));
}
function Fn(e, t) {
	let n = ze && e.l & 32768, r = Ce && qe !== null;
	if (!(n && Ue(e, t)) && !((!r || e.m & 4 && t.m & 1) && !n && (!(e.l & 1 << 23) || t.l & 1024))) {
		let i = C(t);
		if (r && qe.over && w(qe.over) === i && !n) return !1;
		if (!(!r && i === S && !n || In(e, i))) return kt(e, i), (r || n) && ke(e, t), !0;
	}
	return Pn(e, t), !1;
}
function In(e, t) {
	return (e.m & 4 || e.l & 1048576) && e.l & 256 && C(e) === t;
}
function Ln(e) {
	return e !== null && e.Qe ? e.Ke : e;
}
function Rn(e) {
	ne(e);
	let t = j(e);
	t.Le = e.ke, t.me = e.pe, e.ke = null, e.pe = null, e.be = 0;
}
function zn(e, t, n, r, i) {
	let a = i?.transparent ?? !1, o = {
		id: de(i, a, A),
		l: r << 23 | (a ? 4 : 0) | !!i?.ownedWrite | (i?.sync ? 64 : 0) | (i?.xe ?? 0),
		ye: !1,
		ke: null,
		A: A?.A ?? b,
		be: 0,
		X: e,
		le: void 0,
		he: 0,
		ve: void 0,
		We: null,
		C: null,
		_: null,
		de: 0,
		o: null,
		Ze: null,
		_parent: A,
		Ge: null,
		Me: null,
		pe: null,
		R: 512,
		m: 4,
		ie: E,
		ue: y,
		we: -1,
		Ie: !1,
		Ae: !1,
		ge: void 0,
		qe: t,
		Je: n,
		ze: void 0,
		i: r,
		T: null
	};
	return i?.unobserved && (j(o).Ye = i.unobserved), Wn(o, Un), o;
}
var Bn = null;
function Vn(e) {
	Bn = e;
}
function Hn(e) {
	return e.i ? Bn : null;
}
var Un = { lazy: !0 };
function Wn(e, t) {
	e.We = e;
	let n = A?.Qe ? A.Ke : A;
	A && se(A, e), n && (e.he = n.he + 1), We?.(e), !t?.lazy && jn(e, !0);
}
function Gn(e, t) {
	let n = {
		ye: t?.equals ?? Kn,
		l: +!!t?.ownedWrite | (t?.ae ? 2 : 0),
		le: e,
		o: null,
		Ze: null,
		ie: E,
		ue: y,
		we: -1,
		T: null
	};
	return t?.unobserved && (j(n).Ye = t.unobserved), n;
}
function Kn(e, t) {
	return e === t;
}
function qn(e, t, n, r, i) {
	return {
		ye: t,
		l: 1 | h,
		le: e,
		o: null,
		Ze: null,
		ie: E,
		ue: y,
		we: -1,
		T: null,
		O: n,
		Xe: r,
		acc: i,
		px: void 0,
		pxv: void 0
	};
}
var Jn = null;
function Yn(e, t) {
	let n = k;
	k = !1;
	try {
		return e();
	} finally {
		k = n;
	}
}
var Xn = 0;
function Zn(e, t) {
	if (e.R & 512) e.R &= -513, jn(e, !0);
	else if (e.R & 64 && e.l & 32) {
		let t = e._parent;
		if (t !== null) {
			if (t.R & 64) {
				e.l &= -33;
				return;
			}
			e.R & 32 || se(t, e);
		}
		jn(e, !0);
	}
}
function Qn(e, t) {
	return !t || e.ue === y || t.l & 16;
}
var $n = !1;
function er() {
	$n = !0;
}
function tr(e) {
	return O.Y || e.ue === y || e.l & 4194304 ? y : e.l & 256 ? e.T.Be === E ? e.T.je : y : e.le;
}
function nr(e) {
	let t = e.T;
	t.Be !== E && (t.je = e.ue, t.Be = E, $n = !0);
}
var rr = [];
function ir(e) {
	return e.R |= a, !0;
}
function ar() {
	if ($n = !1, rr.length !== 0) {
		for (let e of rr) e.l &= ~v;
		rr.length = 0;
	}
}
function or(e, t) {
	e.he >= T.Fe || e.R & 1 ? (qt(t), Kt(T), Mn(e)) : t.l & 65536 && Mn(e);
	let n = e.he;
	e._parent === t ? e.R |= f : n >= t.he && Xt(t, t.he = n + 1);
}
function sr() {
	return A.R & i;
}
function M(e) {
	let t = A;
	if (t?.Qe && (t = t.Ke), Jn !== null) return Jn(e, t);
	if (typeof e.X == "function" && Zn(e), !e.X && e.T?.De === void 0 && (!$n || e.ue === y) && !(e.l & 2048)) return t && (k && cn(e, t), e.l & 256 && !(t.l & 16) && Fn(t, e)) || !t || e.ue === y || t.l & 16 || e.ue === e.le && Object.is(e.ue, e.le) ? e.le : (ur(t), e.ue);
	let n = !1;
	if (t && (k && (cn(e, t), e.X && or(e, t)), e.l & 256 && !(e.l & 2048) && !(t.l & 16) && (e.m & 4 ? Pn(t, e) : n = Fn(t, e))), e.m & 1 && !n) {
		if (t) {
			if (!(t.l & 16) || e.m & 4) throw !k && e !== t && cn(e, t), e.T?.U;
		} else if (e.m & 4) throw e.T?.U;
	}
	if (e.X && e.m & 2) {
		if (k && e.ie < E && !(e.R & 32)) return jn(e), M(e);
		throw !n && e.l & 2097152 && lr(e, t), e.T?.U;
	}
	(n || !t) && cr(e);
	let r = lr(e, n ? null : t);
	return !t && typeof e.X == "function" && e.l & 32 && !(e.m & 1) && !e.o && (on.add(e), D()), r;
}
function cr(e) {
	if (e.T?.Te) throw e.T.Te;
}
function lr(t, n) {
	if (t.ue !== y && t.m & 4 && (!n || n.l & 16)) {
		if (Xn > 0) {
			let e = Ln(A);
			if (e && t.l & 256 && In(e, C(t))) return t.ue;
		}
		throw new e(null);
	}
	let r = n && $n ? tr(t) : y;
	if (r !== y) return ir(n), r;
	if (Qn(t, n)) return t.le;
	if (ur(n, t), t.l & 2097152) throw t.ue;
	return t.ue;
}
function ur(e, t) {
	t?.m & 4 || (e.R |= s);
}
function dr(e, t) {
	return S === null || In(e, S) || (t?.l & 2304) == 256 ? !1 : (kt(e, S), !0);
}
function fr(e) {
	O.Y || e.l & 4194304 || (e.l |= v, rr.push(e));
}
var pr = null;
function mr(t, n, r) {
	if (t.ye === Kn) return n === r;
	try {
		return t.ye && t.ye(n, r);
	} catch (n) {
		if (!(n instanceof e)) return On(t, 2, n), !0;
	}
}
function N(e, t) {
	pr !== null && pr(e);
	let n = e.ue === y ? e.le : e.ue;
	if (typeof t == "function" && (t = t(n)), e.l & 256 && Ze(C(e)), !(e.m & 4 || e.T?.Te || !mr(e, n, t))) return t;
	let r = e.ue !== y;
	return r ? e.l & 256 && !O.Y && nr(e) : At(e), e.ue = t, A !== null && fr(e), e.X !== void 0 && (e.ie = E), r && e.we === jt || (Nt(e), D()), t;
}
function hr(e, t) {
	let n = e.l & 256 && !(e.R & 1024) && C(e) !== S;
	if (n && typeof t == "function") {
		let n = t(e.le);
		t = () => n;
	}
	return e.m & 2 && (e.T.Te = e.T.U, On(e, 0)), t = N(e, t), e.l &= ~_, n ? (e.R = e.R & -2 | 2, Ut(e, T), D()) : e.ue !== y && (e.R |= r), t;
}
function gr(e, t) {
	let n = A, r = k;
	A = e, k = !1;
	try {
		return t();
	} finally {
		A = n, k = r;
	}
}
function _r(e, t = !0) {
	try {
		return e();
	} finally {}
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/identities.js
var vr = null;
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/core/effect.js
function yr(e, t, n, r) {
	let i = zn(e, t, n, r?.user ? 2 : 1, r);
	jn(i, !0), r?.defer ? Ft(i) : i.ue === y && (i.T?.Re?.P || i.i === 2 || r?.schedule ? O.enqueue(i.i, Sr.bind(null, i), i.T?.Re) : Sr(i, 0));
}
function br() {
	let e = this.m, t = this.T?.U;
	if (e & 2) {
		if (O.notify(this, 1, 0), this.i === 2) {
			this.m & 2 && Pt(this);
			return;
		}
		xr(this, n(t));
	} else this.i === 2 ? e & 1 && this.Ae && !t?.source?.T?.Ve && (j(this).fe = !(this.Ae = !1)) : this.i === 1 && O.notify(this, 3, e, t);
}
function xr(e, t, n) {
	if (!O.notify(e, 2, 2)) throw xt(t), t;
}
function Sr(e, r) {
	if (!e.Ae || e.R & 64 || r && Pe?.(e) || r && He?.(e)) return;
	if (e.m & 2 && e.i === 2) {
		let t = n(e.T?.U);
		e.ge = e.le, e.Ae = !1;
		try {
			e.Je ? e.Je(t, () => {
				let t = e.ze;
				e.ze = void 0, t?.();
			}) : console.error(t);
		} catch (t) {
			xr(e, t);
		}
		return;
	}
	let i = e.T?.U == null, a = e.ze;
	e.ze = void 0;
	try {
		a?.(), e.ze = e.qe(e.le, e.ge);
	} catch (n) {
		j(e).U = new t(e, n), e.m |= 2, xr(e, n);
	} finally {
		e.ge = e.le, e.Ae = !1, i && en(e);
	}
}
Ct.q = Sr;
function Cr(e, t) {
	let n = !1, r, i = () => {
		if (!a.Ae || a.R & 64 || Pe?.(a)) return;
		let e = jt;
		n = !1;
		try {
			a.Ae = !1, jn(a);
		} finally {}
		for (let t = a.C; t !== null; t = t.G) {
			let o = t.S;
			if (o.ue !== y && !(o.l & 2048) && (o.ue !== o.le || !Object.is(o.ue, o.le))) {
				if (o.l & 256) n || (n = !0, C(o).rn[1].push(r || (r = () => {
					n && (a.Ae = !0, i());
				})));
				else if (o.we <= e || o.X) {
					Vt(a), D();
					break;
				}
			}
		}
	}, a = Nn(() => {
		let t = a.ze;
		a.ze = void 0, t?.();
		let n = _r(e);
		a.ze = n;
	}, {
		...t,
		lazy: !0
	});
	a.ze = void 0, a.l = a.l & -33 | 16, a.Ae = !0, a.i = 3, a.Z = i, Vt(a), D();
}
Vn(br);
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/store/types.js
var wr = Symbol(0), Tr = Symbol(0), P = Symbol(0), Er = Symbol(0), Dr = Symbol(0), Or = /* @__PURE__ */ new WeakSet(), kr = !1;
function Ar(e) {
	return kr && Or.has(e);
}
function jr(e) {
	if (F(e)) {
		if (e[P] !== void 0) return;
		kr = !0, Or.add(e);
	}
}
function Mr(e) {
	if (Array.isArray(e)) for (let t = 0, n = e.length; t < n; t++) jr(e[t]);
	else for (let t in e) jr(e[t]);
}
var Nr = Object.prototype, Pr = /* @__PURE__ */ new WeakMap();
function F(e) {
	if (typeof e != "object" || !e || Object.isFrozen(e)) return !1;
	let t = Object.getPrototypeOf(e);
	if (t === Nr || t === null || Array.isArray(e)) return !0;
	let n = Pr.get(t);
	return n === void 0 && (n = Object.prototype.toString.call(e) === "[object Object]" && (typeof Node > "u" || !(e instanceof Node)), Pr.set(t, n)), n;
}
var I = !1;
function Fr(e) {
	I = e;
}
var Ir = null;
function Lr(e) {
	Ir = e;
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/signals.js
function Rr(e) {
	let t = M.bind(null, e);
	return t[ee] = e, t;
}
function zr(e, t) {
	if (typeof e == "function") {
		let n = Nn(e, t);
		return n.l &= -33, [Rr(n), hr.bind(null, n)];
	}
	let n = Gn(e, t);
	return vr !== null && vr(n), [Rr(n), N.bind(null, n)];
}
function Br(e, t) {
	return Rr(Nn(e, t));
}
function Vr(e, t, n) {
	yr(e, t.effect || t, t.error, {
		user: !0,
		...n
	});
}
function Hr(e, t, n) {
	yr(e, t, void 0, n);
}
function Ur(e) {
	let t = pe();
	t && !(t.l & 16) ? Cr(() => Yn(e), void 0) : O.enqueue(2, function t() {
		if (T.Et >= T.Fe) return O.enqueue(2, t);
		e();
	});
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/map.js
function Wr(e, t, n) {
	let r = typeof n?.keyed == "function" ? n.keyed : void 0, i = t.length > 1, a = t, o = {
		H: _e(),
		it: 0,
		st: e,
		ot: [],
		ft: a,
		ht: [],
		ln: [],
		Xe: r,
		ct: r || n?.keyed === !1 ? [] : void 0,
		lt: i && n?.keyed !== !1 ? [] : void 0,
		ut: n?.keyed === !1,
		L: n?.fallback
	}, s = Nn(Zr.bind(o), void 0);
	return s.l &= -33, Rr(s);
}
var Gr = { ownedWrite: !0 };
function Kr(e, t, n, r) {
	let i = e.ot, a = e.it - 1, o = [], s = [], c = [], l = 256, u = r, d = r;
	for (; u <= a && d <= n - 1;) {
		let e = i[u], r = t[d];
		if (e === r) {
			let e = u;
			do
				d++;
			while (++u <= a && d < n && i[u] === t[d]);
			c.push(e, d - u + e, u - e);
			continue;
		}
		let f = -1, p = Math.min(32 - o.length, a - u, l);
		for (let e = 1; e <= p; e++) if (i[u + e] === r) {
			f = e;
			break;
		}
		l -= f === -1 ? p : f;
		let m = -1;
		p = Math.min(32 - s.length, n - 1 - d, l);
		for (let n = 1; n <= p; n++) if (t[d + n] === e) {
			m = n;
			break;
		}
		if (l -= m === -1 ? p : m, f !== -1 && (m === -1 || f <= m)) for (; f-- > 0;) o.push(u++);
		else if (m !== -1) for (; m-- > 0;) s.push(d++);
		else {
			if (l <= 0 || o.length === 32 || s.length === 32) return !1;
			o.push(u++), s.push(d++);
		}
	}
	for (; u <= a; u++) {
		if (o.length === 32) return !1;
		o.push(u);
	}
	for (; d <= n - 1; d++) {
		if (s.length === 32) return !1;
		s.push(d);
	}
	return qr(e, t, n, r, o, s, c);
}
function qr(e, t, n, r, i, a, o) {
	let s = e.ot, c, l, u;
	if (a.length !== 0) for (u = Array(i.length), l = 0; l < a.length; l++) {
		let e = -1;
		for (c = 0; c < i.length; c++) if (!u[c] && s[i[c]] === t[a[l]]) {
			e = c;
			break;
		}
		if (e === -1) return !1;
		u[e] = !0, a[l] = a[l] << 6 | e;
	}
	for (c = 0; c < i.length; c++) {
		let e = s[i[c]];
		if (e === void 0) return !1;
		for (l = r - 1; (l = s.indexOf(e, l + 1)) !== -1;) if (!i.includes(l)) return !1;
	}
	let d = e.ht, f = e.ln, p = d.slice(0, n), m = f.slice(0, n);
	for (let e = 0; e < o.length; e += 3) {
		let t = o[e], n = o[e + 1];
		if (t !== n) for (let r = 0; r < o[e + 2]; r++) p[n + r] = d[t + r], m[n + r] = f[t + r];
	}
	for (l = 0; l < a.length; l++) {
		let e = a[l] >> 6, t = i[a[l] & 63];
		p[e] = d[t], m[e] = f[t];
	}
	for (e.ht = p, e.ln = m, e.it = n, e.ot = t, c = 0; c < i.length; c++) u !== void 0 && u[c] || f[i[c]].dispose();
	return !0;
}
function Jr(e, t, n, r, i, a, o, s, c) {
	let l = e.Xe, u = e.ot, d = e.ln, f = [], p = n;
	for (let m = n; m <= i; p++, m++) {
		let i = l ? l(t[m]) : t[m];
		for (; p <= r && (l ? l(u[p]) : u[p]) !== i;) f.push(d[p++]);
		if (p > r) return o.fill(void 0), null;
		a[m] = e.ht[p], o[m - n] = d[p], s && (s[m - n] = e.ct[p]), c && (c[m - n] = e.lt[p]);
	}
	for (; p <= r; p++) f.push(d[p]);
	return f;
}
function Yr(e, t, n, r, i, a, o, s, c) {
	let l = e.ln, u = e.ct, d = e.lt, f = e.it, p = n - f, m, h;
	if (p > 0) for (l.length = n, u && (u.length = n), d && (d.length = n), m = f - 1, h = n - 1; m > i; m--, h--) l[h] = l[m], u && (u[h] = u[m]), d && (d[h] = d[m]);
	else if (p < 0) {
		for (m = i + 1, h = a + 1; m < f; m++, h++) l[h] = l[m], u && (u[h] = u[m]), d && (d[h] = d[m]);
		l.length = n, u && (u.length = n), d && (d.length = n);
	}
	for (h = r; h <= a; h++) l[h] = o[h - r], u && Xr(u[h] = s[h - r], t[h]), d && N(d[h] = c[h - r], h);
	for (h = a + 1; h < n; h++) u && Xr(u[h], t[h]), d && p !== 0 && N(d[h], h);
}
var Xr = (e, t) => e.le === t && e.ue === y || N(e, t);
function Zr() {
	this.H.Ke = pe();
	let e = this.st() || [];
	e[wr], e = Ir?.(e[P]) ?? e;
	let t = e.length;
	return gr(this.H, Qr.bind(this, e, t)), this.ht;
}
function Qr(e, t) {
	let n = e.slice(0), r, i, a, o, s, c = this.ct ? this.ut ? () => (o[a] = Gn(n[i], Gr), this.ft(Rr(o[a]), i)) : () => (o[a] = Gn(n[i], Gr), s && (s[a] = Gn(i, Gr)), this.ft(Rr(o[a]), s ? Rr(s[a]) : void 0)) : this.lt ? () => {
		let e = n[i];
		return s[a] = Gn(i, Gr), this.ft(e, Rr(s[a]));
	} : () => {
		let e = n[i];
		return this.ft(e);
	};
	if (t === 0) this.it !== 0 && (this.H.dispose(!1), this.ln = [], this.ot = [], this.ht = [], this.it = 0, this.ct && (this.ct = []), this.lt && (this.lt = [])), this.L && !this.ht.length && (this.ln[0]?.dispose(), this.ht[0] = gr(this.ln[0] = _e(), this.L));
	else if (this.it === 0) {
		let e = Array(t), l = Array(t);
		o = this.ct && Array(t), s = this.lt && Array(t);
		try {
			for (i = 0; i < t; i++) a = i, e[i] = gr(l[i] = _e(), c);
		} catch (e) {
			for (r = 0; r <= i; r++) l[r]?.dispose();
			throw e;
		}
		this.ln[0] && this.ln[0].dispose(), this.ht = e, this.ln = l, o && (this.ct = o), s && (this.lt = s), this.ot = n, this.it = t;
	} else {
		let e, l, u, d, f, p, m, h, g;
		for (e = 0, l = Math.min(this.it, t); e < l && (this.ot[e] === n[e] || this.ct && $r(this.Xe, this.ot[e], n[e])); e++) this.ct && Xr(this.ct[e], n[e]);
		for (l = this.it - 1, u = t - 1; l >= e && u >= e && (this.ot[l] === n[u] || this.ct && $r(this.Xe, this.ot[l], n[u])); l--, u--);
		if (e === t && this.it === t) {
			this.ot = n;
			return;
		}
		if (t <= this.it && l - e > 64 && this.ct === void 0 && this.lt === void 0) {
			let r = e + (u - e >> 1), i = n[r], a = Math.min(l, r + 32), o = Math.max(e, r - 32);
			for (; o <= a && this.ot[o] !== i;) o++;
			if (o <= a && Kr(this, n, t, e)) return;
		}
		let _ = t - this.it, v = u - e + 1, y = Array(t), b = Array(v);
		o = this.ct ? Array(v) : void 0, s = this.lt ? Array(v) : void 0;
		let ee = _ < 0 ? Jr(this, n, e, l, u, y, b, o, s) : null;
		if (ee !== null) ee.length !== 0 && (h = ee);
		else {
			for (p = /* @__PURE__ */ new Map(), m = Array(v), i = u; i >= e; i--) d = n[i], f = this.Xe ? this.Xe(d) : d, r = p.get(f), m[i - e] = r === void 0 ? -1 : r, p.set(f, i);
			for (r = e; r <= l; r++) d = this.ot[r], f = this.Xe ? this.Xe(d) : d, i = p.get(f), i !== void 0 && i !== -1 ? (y[i] = this.ht[r], b[i - e] = this.ln[r], o && (o[i - e] = this.ct[r]), s && (s[i - e] = this.lt[r]), i = m[i - e], p.set(f, i)) : (h ?? (h = [])).push(this.ln[r]);
			try {
				for (i = e; i <= u; i++) b[i - e] === void 0 && ((g ?? (g = [])).push(b[i - e] = _e()), a = i - e, y[i] = gr(b[i - e], c));
			} catch (e) {
				if (g) for (r = 0; r < g.length; r++) g[r].dispose();
				throw e;
			}
		}
		for (r = 0; r < e; r++) y[r] = this.ht[r];
		for (i = u + 1; i < t; i++) y[i] = this.ht[i - _];
		if (Yr(this, n, t, e, l, u, b, o, s), this.ht = y, this.it = t, this.ot = n, h) for (r = 0; r < h.length; r++) h[r].dispose();
	}
}
function $r(e, t, n) {
	return !e || e(t) === e(n);
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/store/target.js
var L = Symbol(0), ei = /* @__PURE__ */ new WeakMap();
function ti(e, t) {
	(t.rr?.map ?? ei).set(e, t);
}
function ni(e) {
	return e[L] !== void 0;
}
function ri(e, t) {
	let n = e[L];
	return n !== void 0 && n.rr === t ? n : (t?.map ?? ei).get(e);
}
function ii(e) {
	let t = e;
	for (; t && !t.d;) t.d = !0, t = t.u;
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/store/hooks.js
var R = null, ai = null, oi = Symbol(0);
function si(e, t, n, r) {
	this.v = e, this.ch = e[P] !== void 0, this.pb = null, this.n = null, this.h = null, this.k = null, this.dk = null, this.u = t, this.pk = n, this.px = null, this.d = !1, this.a = !1, this.sc = 0, this.kc = 0, this.nc = 0, this.rr = r, this.o = r !== null && r.opt === !0, this.s = !1, this.ovl = !1, this.del = null, this.wk = null;
}
function ci(e, t, n, r = t?.rr ?? null) {
	let i = new si(e, t, n, r);
	return i.px = new Proxy(Array.isArray(e) ? [] : {}, i), ti(e, i), i;
}
function z(e, t = null, n = null, r = t?.rr ?? null) {
	if (kr && Ar(e)) return e;
	let i = ri(e, r);
	if (i !== void 0) return i.px;
	let a = e[P];
	return a?.px === e && (r === null || a.rr === r) ? e : ci(e, t, n, r).px;
}
function B(e) {
	if (typeof e != "object" || !e) return e;
	let t = e[P];
	return t !== void 0 && (t.px === e || ri(e, t.rr) === t) && t.v !== void 0 ? (t.ovl && Vi(t), t.pb ?? t.v) : e;
}
var li = function(e, t) {
	return Kn(e, t) || fi(this.O, e, t);
};
function ui(e, t) {
	return e === t || e !== e && t !== t;
}
var di = function(e, t) {
	return e === t;
};
function fi(e, t, n) {
	if (typeof t != "object" || !t || typeof n != "object" || !n) return !1;
	let r = ri(t, e.rr);
	return r !== void 0 && r === ri(n, e.rr);
}
var pi = /* @__PURE__ */ new Set();
function mi(e) {
	let t = e.O, n = e.Xe;
	if (n === wr) t.k === e && (t.k = null);
	else if (n === Tr) return;
	else n === oi ? t.dk === e && (t.dk = null) : t.n?.[n] === e ? (delete t.n[n], t.nc--) : t.h?.[n] === e && delete t.h[n];
	t.rr !== null && t.nc === 0 && t.k === null && t.dk === null && (t.h === null || Reflect.ownKeys(t.h).length === 0) && t.rr.live.delete(t);
}
function hi(e, t, n) {
	e.rr !== null && e.rr.live.add(e), ii(e), ai !== null && ai.ro(e, t, n);
}
var gi = (e) => e.ue !== y || e.l & 2048 || e.O.k?.l & 256;
Qt((e) => {
	gi(e) ? pi.add(e) : mi(e);
});
function _i(e, t, n, r) {
	if (t.ye && t.ye(t.le, n)) return;
	At(t), t.ue = n;
	let i = e.k;
	if (i !== null) {
		if (i.l & 256 && ka(e, r)) {
			let e = C(i);
			(!(i.l & 2048) || e.folded) && lt(t, w(e._parent ?? e));
		}
		i.l & 4194304 && fr(t);
	}
}
function vi(e, t, n = -1) {
	let r = e.n ?? (e.n = Object.create(null)), i = r[t];
	if (i === void 0) {
		let a = e.pb, o = i = qn(Ea(e)[t], li, e, t, n === -1 ? Ai(a ?? e.v, t) : n === 1);
		a !== null && !o.acc && _i(e, o, e.del?.has(t) ? void 0 : a[t], t), r[t] = i, e.nc++, hi(e, o, t);
	}
	return i;
}
function yi(e, t) {
	let n = e.h ?? (e.h = Object.create(null)), r = n[t];
	if (r === void 0) {
		let i = r = qn(t in Ea(e), Kn, e, t, !1), a = e.pb;
		a !== null && _i(e, i, t in a && !e.del?.has(t), t), n[t] = r, hi(e, i, t);
	}
	return r;
}
function bi(e) {
	let t = e.k;
	return t === null && (t = e.k = qn(e.v, di, e, wr, !1), hi(e, t, wr), e.pb !== null && !na && (t.le = ea(e), t.ue = e.pb, At(t))), t;
}
function xi(e, t) {
	if (e.k === null && qe === null && (A === null || O.Y) && !Si(e)) return;
	let n = bi(e);
	n.ue === y && At(n), n.ue = t, A !== null && fr(n), e.rr !== null && !H && Va(e, n);
}
function Si(e) {
	let t = e.rr?.node;
	return t != null && !H && !!(t.l & 256);
}
var Ci = (e) => {
	for (let t = 0; t < Ji.length; t++) {
		let n = Ji[t];
		n.k === null && n.pb !== null && lt(bi(n), e);
	}
	R?.park(e);
};
function wi(e, t) {
	(e.l & 10240) == 10240 ? N(e, t) : (e.l & 256 && Ze(C(e)), Nt(e), D());
}
var V = Object.prototype.hasOwnProperty, Ti = Object.getPrototypeOf, Ei = Object.setPrototypeOf, Di = Object.prototype.__lookupGetter__, Oi = Object.prototype.__lookupSetter__, ki = Object.prototype.propertyIsEnumerable;
function Ai(e, t) {
	return V.call(e, t) && (Di.call(e, t) !== void 0 || Oi.call(e, t) !== void 0);
}
function ji(e, t) {
	if (t.sc || Pi(t), t.sc === 2) {
		let n = { ...e };
		return n[L] = t, n;
	}
	let n;
	if (!t.a && t.kc <= e.length + 1 && Ti(e) === Array.prototype) n = e.slice();
	else {
		let r = Object.getOwnPropertyDescriptors(e);
		for (let n of Reflect.ownKeys(r)) {
			let i = r[n];
			n === "length" && Array.isArray(e) || (i.configurable = !0, !i.get && !i.set ? i.writable = !0 : t.a = !0);
		}
		n = Object.defineProperties(Array.isArray(e) ? Ei([], Ti(e)) : Object.create(Ti(e)), r);
	}
	return n[L] = t, n;
}
function Mi(e, t) {
	let n = Object.create(null);
	for (let t of Reflect.ownKeys(e)) n[t] = e[t];
	return Ei(n, Object.prototype), n[L] = t, n;
}
function Ni(e, t, n) {
	let r = Object.getOwnPropertyDescriptor(t, n);
	r.get || r.set || !r.enumerable || !r.writable || !r.configurable ? Object.defineProperty(e, n, r) : e[n] = r.value;
}
function Pi(e) {
	let t = e.v, n = Reflect.ownKeys(t), r = Ti(t) === Object.prototype;
	for (let i of n) {
		if (Ai(t, i)) {
			e.a = !0, r = !1;
			break;
		}
		r && !ki.call(t, i) && (r = !1);
	}
	return e.sc = r ? 2 : 1, e.kc = n.length, !e.a;
}
var Fi = 32, Ii = 1024, Li = 16, Ri = /* @__PURE__ */ new Set(), zi = (e) => {
	let t = Ti(e);
	return t === Object.prototype || t === Array.prototype || t === null;
};
function Bi(e, t) {
	if (e.kc > Ii) return !1;
	if (e.del?.size) return !0;
	let n = e.wk;
	if (n !== null && n !== Ri && n.u === void 0 && n.size <= Li) return !1;
	let r = e.v, i = 0;
	for (let e of Reflect.ownKeys(t)) if (!V.call(r, e) && ++i > Li) return !0;
	return !1;
}
function Vi(e) {
	let t = e.pb;
	if (!e.ovl) return t;
	let n = Ki(e, e.sc === 2 ? Mi(e.v, e) : ji(e.v, e), t);
	return e.pb = n, e.k?.ue === t && (e.k.ue = n), n;
}
function Hi(t) {
	let n = t.pb;
	if (R !== null && t.o && H && !Sa.has(t)) return t.pb = R.draft(t);
	if (n !== null && !ni(n)) {
		n = t.pb = ji(n, t);
		let e = t.k;
		e !== null && !(e.l & 256) && (e.ue = n);
	} else if (n === null) {
		let r = t.v;
		if (na || $i(t), !t.ch && !Array.isArray(r) && (t.sc === 0 ? Pi(t) : !t.a) && t.kc > Fi && ni(r)) n = t.pb = Object.create(r), t.ovl = !0;
		else try {
			n = t.pb = ji(r, t);
		} catch (t) {
			if (!(t instanceof e)) throw t;
			return {};
		}
		na || xi(t, n);
	}
	return n;
}
function Ui(e) {
	if (ni(e.v)) return;
	let t = e.v;
	if (e.v = ji(t, e), e.ch = !1, e.u) {
		Ui(e.u);
		let n = e.u.v, r = Wi(e, t);
		n[r] === t && (n[r] = e.v);
	}
}
function Wi(e, t) {
	let n = e.pk, r = e.u.v;
	if (r[n] === t || r[n] === e.v || !Array.isArray(r)) return n;
	let i = r.indexOf(t);
	return i === -1 ? n : (e.pk = i, i);
}
function Gi(e, t) {
	Ui(e), Ki(e, e.v, t);
}
function Ki(e, t, n) {
	for (let r of Reflect.ownKeys(n)) e.sc === 2 ? t[r] = n[r] : Ni(t, n, r);
	if (e.del !== null) {
		for (let n of e.del) delete t[n];
		e.kc -= e.del.size, e.del = null;
	}
	return e.ovl = !1, t;
}
function qi(e, t, n = !0) {
	na || $i(e);
	let r;
	e.pb === null ? r = e.v : (e.ovl && Vi(e), r = e.pb), na ? (e.pb = null, e.k !== null && (e.k.le = t)) : (e.pb = t, xi(e, t)), e.v = t, e.ch = t[P] !== void 0, e.ovl = !1, e.del = null, e.sc = 0, e.a = !1, e.wk = null, t[L]?.rr === e.rr ? t[L] = e : ti(t, e), R !== null && e.o && R.judge(e, t), n && r !== t && ya(e, r, t);
}
var Ji = [], Yi = [], Xi = [], Zi = [], Qi = null;
function $i(e) {
	e.pb === null && (D(), Qi !== null && Qi.set(e, Ji.length), Ji.push(e), Yi.push(e.v));
}
function ea(e) {
	if (Qi === null) {
		Qi = /* @__PURE__ */ new Map();
		for (let e = 0; e < Ji.length; e++) Qi.set(Ji[e], e);
	}
	let t = Qi.get(e);
	return t === void 0 ? e.v : Yi[t];
}
function ta() {
	if (Ji.length !== 0) {
		let e = Ji, t = Yi;
		Ji = Xi, Yi = Zi, Xi = e, Zi = t, Qi = null;
		for (let n = 0; n < e.length; n++) {
			let r = e[n];
			if (r.pb === null) continue;
			let i = r.k;
			i !== null && i.ue !== y ? (Ji.push(r), Yi.push(t[n])) : ia(r, t[n]);
		}
		e.length = 0, t.length = 0;
	}
	if (pi.size !== 0) for (let e of pi) e.o === null && !gi(e) && (pi.delete(e), mi(e));
}
Ct.k = (e) => !!((e.O?.rr)?.node?.m & 1), Le(Ci, () => {
	ta(), R?.sweep();
}), Ct.so = vi, Ct.fo = F;
var na = !1;
function ra(e) {
	let t = na;
	na = !0;
	try {
		e();
	} finally {
		na = t;
	}
}
function ia(e, t) {
	{
		let n = e.k, r = e.pb;
		if (r !== null) {
			if (r !== e.v) {
				if (e.ovl && (e.v !== t || !Bi(e, r) && n?.T?.De !== t)) Gi(e, r);
				else if (e.v !== t) {
					Ui(e);
					let n = e.v, i = e.wk;
					if (i !== null && i !== Ri) for (let e = i; e !== void 0; e = e.u) for (let t of e) V.call(r, t) ? Ni(n, r, t) : delete n[t];
					else {
						for (let e of Reflect.ownKeys(r)) e !== L && Ni(n, r, e);
						for (let e of Reflect.ownKeys(t)) e !== L && !V.call(r, e) && delete n[e];
					}
				} else e.v = e.ovl ? Vi(e) : r, e.ch = e.v[P] !== void 0;
			}
			e.pb = null, e.wk = null;
		}
		if (n !== null && (n.o === null ? e.k = null : n.le = e.v), e.v !== t && e.u) {
			let n = Wi(e, t);
			e.u.v[n] === t && (Ui(e.u), e.u.v[n] = e.v);
		}
	}
}
var aa = !1, H = !1;
function oa() {
	return H;
}
function sa(e, t, n) {
	if (e.rr === null || !H) return !1;
	if (t !== void 0) return (t.l & 262400) == 256 && C(t) !== S;
	let r = e.k;
	return r !== null && !!(r.l & 256) && C(r) !== S && ka(e, n);
}
function ca(e) {
	let t = e.pb;
	if (t === null) return;
	if (R !== null && e.o) {
		if (H) {
			e.pb = null, e.wk = null, e.pb = R.writes(e, t);
			return;
		}
		R.pair(e, t), R.judge(e, t);
	}
	let n = e.v, r = e.n, i = e.wk, a = i === Ri || e.a === !0 || !zi(e.ovl ? e.v : t) ? null : i;
	if (e.rr !== null && !aa && a !== null) {
		for (let t of a) if (sa(e, r?.[t], t)) {
			aa = !0;
			break;
		}
	}
	if (r !== null) {
		let i = a ?? Reflect.ownKeys(r);
		for (let a of i) {
			let i = r[a];
			if (i === void 0) continue;
			let o = !1;
			if (i.acc === !0 || (o = V.call(t, a)) && Di.call(t, a) !== void 0) {
				i.acc = Ai(t, a);
				let e = Object.getOwnPropertyDescriptor(n, a), r = Object.getOwnPropertyDescriptor(t, a);
				if (!r || r.get || r.set) {
					(e?.get !== r?.get || e?.set !== r?.set || e?.value !== r?.value) && N(i, () => ua);
					continue;
				}
				(e?.get || e?.set || !Kn(e?.value, r.value)) && N(i, () => r.value);
				continue;
			}
			let s = o || !(e.del?.has(a) || a === "__proto__") ? t[a] : void 0;
			R !== null && e.o && R.covers(e, a, !1) ? la(i, s) : (N(i, () => s), e.rr !== null && (H ? i.l |= g : (i.l &= ~g, Va(e, i))));
		}
	}
	let o = e.h;
	if (o !== null) {
		let n = a ?? Reflect.ownKeys(o);
		for (let r of n) {
			let n = o[r];
			if (n !== void 0) {
				if (R !== null && e.o && R.covers(e, r, !0)) {
					la(n, r in t && !e.del?.has(r));
					continue;
				}
				N(n, r in t && !e.del?.has(r)), e.rr !== null && !H && Va(e, n);
			}
		}
	}
	let s = e.k;
	if (s !== null && (s.o !== null || s.l & 2048)) {
		let r;
		if (e.ovl) {
			if (r = !!e.del?.size, !r) {
				for (let e of Reflect.ownKeys(t)) if (!V.call(n, e)) {
					r = !0;
					break;
				}
			}
		} else r = Array.isArray(t) && Array.isArray(n) ? fa(n, t) : pa(n, t);
		r && wi(s, t);
	}
}
function la(e, t) {
	e.le = t, e.ue !== y && (e.ue = t);
}
var ua = Symbol();
function da(e, t) {
	if (typeof e != "object" || !e || typeof t != "object" || !t) return !1;
	let n = ri(e, null);
	return n !== void 0 && n === ri(t, null);
}
function fa(e, t) {
	if (e.length !== t.length) return !0;
	for (let n = 0; n < t.length; n++) {
		let r = e[n], i = t[n];
		if (!Kn(r, i) && !da(r, i)) return !0;
	}
	return !1;
}
function pa(e, t) {
	let n = Reflect.ownKeys(t);
	if (Reflect.ownKeys(e).length - +ni(e) != n.length - +ni(t)) return !0;
	for (let t of n) if (t !== L && !(t in e)) return !0;
	return !1;
}
function ma(e, t) {
	let n = e.O;
	R !== null && n.o && R.covers(n, e.Xe, n.h?.[e.Xe] === e) ? la(e, typeof t == "function" ? t() : t) : (N(e, t), qe !== null && !H && e.O.rr !== null && Va(e.O, e));
}
function ha(e, t, n, r, i = !0) {
	if (e.acc === !0 || i && V.call(r, t) && Di.call(r, t) !== void 0) {
		e.acc = Ai(r, t);
		let i = Object.getOwnPropertyDescriptor(n, t), a = Object.getOwnPropertyDescriptor(r, t);
		if (!a || a.get || a.set) {
			(i?.get !== a?.get || i?.set !== a?.set || i?.value !== a?.value) && ma(e, () => ua);
			return;
		}
		let o = i?.value, s = a?.value;
		(i?.get || i?.set || !Kn(o, s) && !da(o, s)) && ma(e, typeof s == "function" ? () => s : s);
	} else {
		let i = n[t], a = r[t];
		(n[P] || !Kn(i, a) && !da(i, a)) && ma(e, typeof a == "function" ? () => a : a);
	}
}
function ga(e) {
	return e.acc === !0;
}
function _a(e, t, n, r, i, a) {
	e.acc === !0 ? ha(e, t, i, a, !1) : !Kn(n, r) && !da(n, r) && ma(e, typeof r == "function" ? () => r : r);
}
function va(e, t, n) {
	let r = e.h, i = t[P];
	if (r !== null) for (let e of Reflect.ownKeys(r)) (i || e in t != e in n) && ma(r[e], e in n);
	let a = e.k;
	a !== null && (a.o !== null || a.l & 2048) && (i || (Array.isArray(n) && Array.isArray(t) ? fa(t, n) : pa(t, n))) && wi(a, n);
}
function ya(e, t, n) {
	let r = e.n;
	if (r !== null) for (let e of Reflect.ownKeys(r)) ha(r[e], e, t, n);
	va(e, t, n);
}
var ba = 0, xa = null, Sa = /* @__PURE__ */ new Set();
function Ca(e) {
	if (e.rr !== null) return e.rr;
	let t = e;
	for (; t.u !== null;) t = t.u;
	return t;
}
function U(e) {
	return xa !== null && xa.has(Ca(e));
}
function wa(e, t, n) {
	return typeof n == "object" && n && n[P] !== void 0 ? Ta(e, z(n, e, t)) : n;
}
function Ta(e, t) {
	if (xa !== null && U(e)) {
		let e = t?.[P];
		e?.v !== void 0 && xa.add(Ca(e));
	}
	return t;
}
function Ea(e) {
	let t = e.k;
	return t === null ? e.pb === null ? e.v : ea(e) : t.ue === y ? e.v : t.le;
}
function Da() {
	let e = A;
	return e === null ? null : (e.Qe && (e = e.Ke ?? null), e === null || e.l & 16 ? null : e);
}
function Oa(e, t, n = !1) {
	if (R !== null && H && e.o && !Sa.has(e) && U(e)) {
		let t = Hi(e);
		return Sa.add(e), t;
	}
	let r = e.pb;
	if (r === null) return e.v;
	if (U(e) || I) {
		if (I && !H) {
			let n = t === void 0 ? void 0 : e.n?.[t];
			if (n !== void 0) (n.l & 2304) == 256 && Ye(C(n));
			else {
				let n = e.k;
				n !== null && (n.l & 2304) == 256 && (t === void 0 || ka(e, t)) && Ye(C(n));
			}
		}
		return r;
	}
	let i = e.k;
	if (t !== void 0) {
		let n = e.n?.[t];
		if (n?.l & 2048 && i?.T?.Re !== (n.T.Re || 0)) return Ea(e);
	}
	let a = i !== null && !!(i.l & 256);
	if (a && t !== void 0 && !ka(e, t, n)) return r;
	let o = Da();
	if (o === null) return x() !== null || Pa(e) ? r : Jn === null || !a && t !== void 0 && !Fa(e, t, n) ? a ? i.le : e.v : i === null ? Ea(e) : M(i);
	if (!a) {
		if (o.R & 16384 && !(o.l & 32784)) return r;
		if (t !== void 0 && !Fa(e, t, n)) return Ea(e);
		if (i === null) return o.l & 32768 && dr(o) ? Ea(e) : (ur(o), r);
	}
	return Yn(() => M(i));
}
function ka(e, t, n = !0) {
	return Ia(e, e.k.le, e.k.ue, t, n) && !Na(e, t);
}
var Aa = /* @__PURE__ */ new WeakMap();
function ja(e) {
	let t = Aa.get(e);
	return t === void 0 && Aa.set(e, t = new Set(Object.values(e))), t;
}
function Ma(e, t, n) {
	return typeof e == "object" && !!e && typeof t == "object" && !!t && (n === null || ui(n(e), n(t)));
}
function Na(e, t) {
	let n = e.k, r = n.le, i = r[t], a = n.ue[t], o = Array.isArray(r) ? e.rr?.key : null;
	if (e.s || o === void 0 || !Ma(i, a, o) || !F(i) || !F(a) || Array.isArray(i) !== Array.isArray(a) || ri(i, e.rr) !== void 0 || ri(a, e.rr) !== void 0 || ja(r).has(a) || ja(n.ue).has(i)) return !1;
	let s = z(i, e, t)[P];
	return s?.v === i && (qi(s, a, !1), lt(bi(s), C(n)), !0);
}
function Pa(e) {
	return e.rr !== null && A === null && !(e.k?.l & 256);
}
function Fa(e, t, n = !0) {
	return Ia(e, Ea(e), e.pb, t, n);
}
function Ia(e, t, n, r, i) {
	if (e.ch || n[P] !== void 0 || Ti(n) !== Ti(t) || !zi(t)) return !0;
	if (e.del?.has(r)) return r in t;
	let a = V.call(n, r) || e.ovl && V.call(e.v, r);
	if (a !== V.call(t, r)) return !0;
	if (!a) return !1;
	if ((i || e.a) && (Ai(t, r) || Ai(n, r) || ki.call(t, r) !== ki.call(n, r))) return !0;
	let o = n[r], s = t[r];
	return !Kn(s, o) && !fi(e, s, o);
}
function La(e, t, n) {
	let r;
	return e.ue !== y && !(e.l & 256) && n.rr !== null && (A === null || n.rr.node?.m & 4) ? (A !== null && k && cn(e, A), r = e.ue) : r = M(e), r === ua ? t : r;
}
function Ra(e, t, n, r, i, a = -1) {
	let o = e.ch && r === e.v, s = n;
	if (!U(e) && !I && (i === void 0 && x() !== null && (i = vi(e, t, a)), i !== void 0)) {
		let t = La(i, n, e);
		o ? i.le = n : s = t;
	}
	if (e.s) return wa(e, t, s);
	if (e.ch && !o && typeof s == "object" && s && s[P]?.px !== s && (s = Ha(e, t, s)), i !== void 0) {
		if (i.pxv === s && s !== void 0) return Ta(e, i.px);
		if (!F(s)) return s;
		let n = z(s, e, t);
		return i.px = n, i.pxv = s, Ta(e, n);
	}
	return F(s) ? Ta(e, z(s, e, t)) : s;
}
function za(e, t) {
	for (let n = t.o; n !== null; n = n.t) if (n.u === e) return !0;
	return !1;
}
function Ba(e) {
	let t = e.rr.node;
	if (!(t === null || I || U(e))) {
		if (t.m & 3 || t.l & 2097152) {
			if (Jn === null && t.m & 1 && R?.stands(e)) return;
			let n = A;
			if (n !== null && n.i === 1 && t.m & 1 && t.l & 256 && S !== C(t) && !za(n, t)) return;
			n?.C !== void 0 && t.l & 2097152 && cn(t, n), M(t);
		} else {
			let e = A;
			e?.Qe && (e = e.Ke), e && or(t, e), Yn(() => M(t));
		}
	}
}
function Va(e, t, n = qe) {
	let r = e.rr?.node;
	r != null && r.l & 256 && t.ue !== y && !(t.l & 2304) && (lt(t, C(r)), t.T.Ve = r.T.Ve);
}
function Ha(e, t, n) {
	let r = e.v[P];
	if (r.ch) {
		let e = Ha(r, t, n);
		return e === n ? n : z(e, r, t);
	}
	let i = ri(n, r.rr);
	return i === void 0 ? (r.v[t] === n || r.pb?.[t] === n) && F(n) ? z(n, r, t) : n : i.px;
}
function Ua(e) {
	if (!U(e) && !I && x() !== null) {
		let t = M(bi(e));
		if (R !== null && e.o) {
			let t = R.frame(e);
			if (t !== y) return t;
		}
		return t;
	}
	let t = Oa(e);
	return Wa(e) ? R.view(e, t) : t;
}
function Wa(e) {
	return R !== null && e.o && !U(e) && !I;
}
var Ga = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]);
function Ka(e, t) {
	let n = e.wk;
	Sa.has(e) || (Sa.add(e), n !== null && n !== Ri && (n = /* @__PURE__ */ new Set(), n.u = e.wk, e.wk = n)), n !== Ri && (e.wk ?? (e.wk = /* @__PURE__ */ new Set())).add(t);
}
si.prototype = {
	get(e, t, n) {
		let r = this;
		if (typeof t != "string") {
			if (t === P) return r;
			if (t === Er) return n;
			if (t === L || t === Dr) return;
			if (t === ee) return r.rr?.node ?? void 0;
			if (t === wr) {
				if (r.rr !== null && Ba(r), !U(r) && x() !== null) {
					M(bi(r));
					let e = Oa(r);
					e[P] !== void 0 && e[wr];
				}
				return;
			}
		}
		if (Jn !== null && ai !== null && x() === null && ai.io(r, t), r.rr !== null && Ba(r), R !== null && r.o && !I) {
			if (U(r)) R.drafted(r, t);
			else {
				let e = R.read(r, t);
				if (e !== y) return e;
			}
		}
		let i = r.n?.[t];
		if (xa === null && !I) {
			let e = i;
			if (e !== void 0 && e.acc !== !0 && !r.ch) {
				let n = La(e, void 0, r);
				if (typeof n != "object" || !n) return n;
				if (r.s) return wa(r, t, n);
				if (e.pxv === n) return e.px;
				if (F(n)) {
					let i = z(n, r, t);
					return e.px = i, e.pxv = n, i;
				}
				return n;
			}
		}
		let a = Oa(r, t);
		if (a === r.pb && r.del?.has(t)) {
			!U(r) && x() !== null && M(vi(r, t));
			return;
		}
		let o = -1;
		{
			let e;
			if (i === void 0 ? !U(r) && x() !== null ? (e = Ai(a, t), a === (r.pb ?? r.v) && (o = +!!e)) : e = !1 : e = i.acc === !0, e) {
				!U(r) && x() !== null && M(i ?? vi(r, t, o));
				let e = Reflect.get(a, t, n);
				return r.s ? wa(r, t, e) : F(e) ? Ta(r, z(e, r, t)) : e;
			}
		}
		let s = r.ovl && a === r.pb;
		if ((t === "constructor" ? I || U(r) : t === "__proto__" || t === "prototype") && !V.call(a, t) && !(s && V.call(r.v, t))) return;
		let c = a[t];
		if (c === void 0 && !V.call(a, t) && !(s && V.call(r.v, t))) {
			if (c = Reflect.get(a, t, n), typeof c == "function") return c;
			if (r.ch && a === r.v) return Ra(r, t, c, a, i, o);
			if (c === void 0 && !U(r)) {
				x() !== null && vi(r, t, o);
				let e = r.n?.[t];
				if (e) {
					let n = La(e, void 0, r);
					return r.s ? wa(r, t, n) : F(n) ? Ta(r, z(n, r, t)) : n;
				}
			}
			return r.s ? wa(r, t, c) : F(c) ? Ta(r, z(c, r, t)) : c;
		}
		return typeof c == "function" && !V.call(a, t) && !(s && V.call(r.v, t)) ? c : Ra(r, t, c, a, i, o);
	},
	has(e, t) {
		let n = this;
		if (t === P || t === Er || t === wr) return !0;
		if (t === L || t === Dr) return !1;
		if (Jn !== null && ai !== null && x() === null && ai.io(n, t), n.rr !== null && Ba(n), R !== null && n.o && !I && U(n) && R.drafted(n, t, !0), Wa(n)) {
			let e = R.has(n, t);
			if (e !== void 0) return e;
		}
		let r = Oa(n, t);
		if (!U(n) && !I && x() !== null) {
			let e = yi(n, t), i = M(e);
			if (!n.ch || r !== n.v) return !!i;
			let a = t in r;
			return e.le = a, a;
		}
		return t in r && !(r === n.pb && n.del?.has(t));
	},
	ownKeys() {
		let e = this;
		return Jn !== null && ai !== null && x() === null && ai.io(e, void 0), e.rr !== null && Ba(e), R !== null && e.o && !I && U(e) && R.drafted(e, void 0, !0), Xa(e, Ua(e));
	},
	getOwnPropertyDescriptor(e, t) {
		let n = this;
		if (t === L || t === Dr) return;
		let r = x();
		Jn !== null && ai !== null && r === null && ai.io(n, t), n.rr !== null && Ba(n);
		let i = r !== null && !U(n) && !I, a = i && qa(n, r);
		if (!a && Wa(n)) {
			let r = R.descriptor(n, t, Array.isArray(e));
			if (r !== void 0) return r === null ? void 0 : r;
		}
		let o;
		if (a) o = Ua(n);
		else if (i) {
			let e = M(yi(n, t));
			if (o = Oa(n, t, !0), !e && (!n.ch || !(t in o))) return;
		} else o = Oa(n, t, !0);
		let s;
		if (s ?? (s = Za(n, o, t)), s !== void 0) return t === "length" && Array.isArray(e) || (s.configurable = !0), s;
	},
	set(e, t, n) {
		let r = this, i = U(r);
		if (!i && !I || t === "__proto__") return !0;
		let a = r.s || r.rr && n?.[P]?.rr !== r.rr ? n : B(n), o = Hi(r);
		H && r.k?.l & 256 && pi.add(vi(r, t)), Array.isArray(o) ? (Ka(r, t), t === "length" ? r.wk = Ri : Ka(r, "length")) : (Ka(r, t), t in o || r.kc++);
		let s = Ga.has(t);
		return s || r.ovl && r.sc !== 2 && !V.call(o, t) ? Object.defineProperty(o, t, {
			value: a,
			writable: !0,
			enumerable: !0,
			configurable: !0
		}) : o[t] = a, r.del?.delete(t), s || (r.s && typeof a == "object" && a && jr(a), i || ca(r)), !0;
	},
	defineProperty(e, t, n) {
		let r = this, i = U(r);
		if (!i && !I || t === "__proto__") return !0;
		(n.get || n.set) && (r.a = !0), "value" in n && (n = {
			...n,
			value: B(n.value)
		});
		let a = Hi(r);
		return (r.a || !(n.enumerable && n.writable && n.configurable)) && (r.sc = 1), Ka(r, t), Object.defineProperty(a, t, n), r.del?.delete(t), i || ca(r), !0;
	},
	deleteProperty(e, t) {
		let n = this, r = U(n);
		if (!r && !I) return !0;
		let i = Hi(n);
		Ka(n, t);
		let a = n.ovl && V.call(n.v, t);
		return V.call(i, t) && (delete i[t], a || n.kc--), a && (n.del ?? (n.del = /* @__PURE__ */ new Set())).add(t), r || ca(n), !0;
	},
	getPrototypeOf() {
		return Ti(this.v);
	},
	preventExtensions: () => !1,
	setPrototypeOf: () => !1
};
function qa(e, t) {
	let n = e.k;
	if (n === null) return !1;
	let r = n.Ze;
	return r !== null && r.u === t && (!(t.R & 4) || r.Ne === t.de);
}
function Ja(e, t, n = !0) {
	pr !== null && pr(e);
	let r = e[P], i = xa;
	xa = /* @__PURE__ */ new Set(), xa.add(Ca(r));
	let a = H;
	H = n, ba === 0 && Sa.size && Sa.clear(), ba++;
	let o;
	try {
		o = t(e), R !== null && n && r.o && !I && o !== void 0 && o !== e && F(o) && (R.reconcile(e, B(o), r.rr?.key ?? null), o = void 0);
	} finally {
		if (ba--, xa = i, ba === 0 && Sa.size) {
			let e = [...Sa];
			Sa.clear();
			for (let t of e) ca(t);
			if (na) for (let t of e) t.pb !== null && ia(t, t.v);
		}
		H = a;
	}
	if (o !== void 0 && o !== e && F(o) && qi(r, B(o)), n && aa) {
		aa = !1;
		let e = r.rr.node;
		e.R & 2 || (e.R = e.R & -2 | 2, Ut(e, T), D());
	}
}
function Ya(e, t) {
	let n = t?.shallow === !0, r = z(e);
	return vr !== null && vr(r[P]), n && (r[P].s = !0, Mr(e)), [r, (e) => Ja(r, e)];
}
Lr((e) => {
	if (e?.s && !(e.ch || e.a || xa || I || e.rr?.opt)) return e.rr && Ba(e), Oa(e);
});
function Xa(e, t) {
	let n;
	if (e.ovl && t === e.pb) {
		n = Reflect.ownKeys(e.v);
		let r = e.del;
		r?.size && (n = n.filter((e) => !r.has(e)));
		for (let r of Reflect.ownKeys(t)) V.call(e.v, r) || n.push(r);
	} else n = Reflect.ownKeys(t);
	for (let e = n.length - 1; e >= 0 && typeof n[e] == "symbol"; e--) if (n[e] === L) {
		n.splice(e, 1);
		break;
	}
	return n;
}
function Za(e, t, n) {
	let r = Object.getOwnPropertyDescriptor(t, n);
	if (e.ovl && t === e.pb) {
		if (e.del?.has(n)) return;
		r === void 0 && (r = Object.getOwnPropertyDescriptor(e.v, n));
	}
	return r;
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/store/reconcile.js
function Qa(e, t, n, r = !1) {
	if (t == null) throw Error("");
	let i = t[P];
	if (i?.px !== t) throw Error("");
	let a = n === null ? null : typeof n == "string" ? (e) => e?.[n] : n;
	if (R !== null && i.o && oa()) {
		R.reconcile(t, B(e), a);
		return;
	}
	if (r && e !== t && e?.[P] !== void 0) {
		if ((i.pb ?? i.v) === e) return;
		qi(i, e);
		return;
	}
	let o = B(e);
	if (a) {
		let e = i.pb ?? i.v, t = a(e);
		if (t !== void 0 && !ui(a(o), t)) {
			if (!r) throw Error("");
			ni(e) ? delete e[L] : (i.rr?.map ?? ei).delete(e), qi(i, o);
			return;
		}
	}
	$a(i, o, a, r);
}
function $a(e, t, n, r = !1) {
	let i = e.ovl ? Vi(e) : e.pb ?? e.v;
	if (t === i && !ni(i)) return;
	let a = R !== null && e.o ? (R.pair(e, t, !0), R.view(e, i)) : i, o = Array.isArray(t), s = e.s === !0;
	if (qi(e, t, !1), s && Mr(t), e.dk, Array.isArray(a) !== o || i[P]) {
		ya(e, i, t);
		return;
	}
	if (o) {
		let o = e.n, c = 0;
		if (n && !s) {
			let s = a.length, l = t.length, u = 0;
			for (let d = Math.min(s, l); u < d; u++) {
				let s = t[u], l = a[u];
				if (l !== s && !Ma(l, s, n)) break;
				if (typeof s == "object" && s && (l !== s || ni(s)) && to(B(l), s, n, r, e, u), o !== null) {
					let e = o[u];
					e !== void 0 && (c++, _a(e, u, i[u], s, i, t));
				}
			}
			let d = u, f = null;
			for (; u < t.length; u++) {
				let s = t[u];
				if (typeof s == "object" && s) {
					let t = n(s), i;
					if (t !== void 0) {
						if (f === null) {
							f = /* @__PURE__ */ new Map();
							for (let e = d; e < a.length; e++) {
								let t = B(a[e]);
								if (typeof t == "object" && t) {
									let r = n(t);
									if (r === void 0) continue;
									let i = f.get(r);
									i === void 0 ? f.set(r, e) : Array.isArray(i) ? i.push(e) : f.set(r, [i, e]);
								}
							}
						}
						let e = f.get(t);
						e === void 0 ? i = void 0 : Array.isArray(e) ? (i = B(a[e.shift()]), e.length === 1 && f.set(t, e[0])) : (i = B(a[e]), f.delete(t));
					} else i = B(a[u]);
					to(i, s, n, r, e, u);
				}
				if (o !== null) {
					let e = o[u];
					e !== void 0 && (c++, ha(e, u, i, t, !1));
				}
			}
		} else {
			let l = Math.min(a.length, t.length), u = t.length;
			for (let d = 0; d < u; d++) {
				let u = t[d];
				if (!s && d < l && typeof u == "object" && u && to(B(a[d]), u, n, r, e, d), o !== null) {
					let e = o[d];
					e !== void 0 && (c++, ha(e, d, i, t, !1));
				}
			}
		}
		if (o !== null && c < e.nc) for (let e of Reflect.ownKeys(o)) {
			let n = typeof e == "string" ? +e : NaN;
			n >= 0 && n < t.length || ha(o[e], e, i, t, !1);
		}
		va(e, i, t);
		return;
	}
	let c = e.n, l = 0;
	for (let o in t) {
		let u = t[o], d = i[o], f = typeof u == "object" && !!u;
		if (d === u && (!f || !ni(u)) && (c === null || c[o] === void 0 || !ga(c[o]))) c?.[o] !== void 0 && l++;
		else if (f && !s && to(B(a[o]), u, n, r, e, o), c !== null) {
			let e = c[o];
			e !== void 0 && (l++, _a(e, o, d, u, i, t));
		}
	}
	let u = Object.getOwnPropertySymbols(t);
	for (let a = 0; a < u.length; a++) {
		let o = u[a];
		if (o === L) continue;
		let d = t[o];
		if (!s && typeof d == "object" && d && to(B(i[o]), d, n, r, e, o), c !== null) {
			let e = c[o];
			e !== void 0 && (l++, _a(e, o, i[o], d, i, t));
		}
	}
	if (c !== null && l < e.nc) for (let e of Reflect.ownKeys(c)) eo.call(t, e) || ha(c[e], e, i, e === "__proto__" ? Object.create(null) : t, !1);
	va(e, i, t);
}
var eo = Object.prototype.hasOwnProperty;
function to(e, t, n, r, i, a) {
	if (typeof e != "object" || !e) return;
	let o = i.rr;
	t = B(t);
	let s = ri(e, o), c = ri(t, o);
	if (s !== void 0 && s.pk !== a && (s.pk != a && i.v[s.pk] === s.v ? s = void 0 : s.u === i && (s.pk = a)), c !== void 0 && c !== s) {
		if (c.v === t) {
			c.u === i && (c.pk = a);
			return;
		}
		(o?.map ?? ei).delete(t);
	}
	if (s !== void 0 && F(t) && !(kr && Ar(t)) && Array.isArray(e) === Array.isArray(t)) {
		if (typeof a != "number" && n) {
			let r = n(e), i = n(t);
			if (r !== void 0 && i !== void 0 && !ui(r, i)) return;
		}
		(r || n === null || s.d) && $a(s, t, n, r);
	}
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/store/projection.js
function no(e, t, n, r, i, a) {
	let o = (e) => {
		if (!t()) return !0;
		Fr(!0);
		let r = _t;
		a !== void 0 && vt(a());
		try {
			n ? n(e) : e();
		} finally {
			Fr(!1), vt(r);
		}
		return i && i(), !0;
	}, s = (e) => {
		Fr(!0);
		try {
			return e();
		} finally {
			Fr(!1);
		}
	}, c = new Proxy(Array.isArray(e) ? [] : {}, {
		get(o, c) {
			let l = s(() => e[c]);
			return !r && typeof l == "object" && l && c !== P ? no(l, t, n, !1, i, a) : l;
		},
		has: (t, n) => s(() => n in e),
		set: (t, n, r) => o(() => {
			e[n] = r;
		}),
		deleteProperty: (t, n) => o(() => {
			delete e[n];
		}),
		ownKeys: () => s(() => Reflect.ownKeys(e)),
		getPrototypeOf: () => Ti(e),
		getOwnPropertyDescriptor(t, n) {
			let r = s(() => Reflect.getOwnPropertyDescriptor(e, n));
			return r && (r.configurable = !0), r;
		},
		defineProperty: (t, n, r) => o(() => {
			Reflect.defineProperty(e, n, r);
		})
	}), l = e[P];
	return l !== void 0 && ti(c, l), c;
}
function ro(e, t) {
	return t ? Array.isArray(e) ? e.slice() : { ...e } : JSON.parse(JSON.stringify(e));
}
function io(t) {
	let n = t.node, r = new e(n);
	t.Tt = !0;
	let i = R?.ask(t);
	co(t, (e) => {
		e.o === null || i?.(e) || (ln(e, n), kn(e, 1, r));
	});
}
function ao(e, t) {
	co(e, (e) => {
		e.o !== null && gn(e, (e) => {
			e.m & 2 && e.T.U === t || Vt(e);
		});
	}), D();
}
function oo(e) {
	if (!e.Tt) return;
	e.Tt = !1;
	let t = e.node;
	co(e, (e) => {
		e.o !== null && Sn(e, t);
	}), Nt(t);
}
function so(e, t) {
	e & 1 ? io(this) : e ? e & 2 && ao(this, t) : oo(this);
}
function co(e, t) {
	for (let n of e.live) {
		let e = n.n;
		if (e !== null) for (let n of Reflect.ownKeys(e)) t(e[n]);
		let r = n.h;
		if (r !== null) for (let e of Reflect.ownKeys(r)) t(r[e]);
		n.k !== null && t(n.k), n.dk !== null && t(n.dk);
	}
}
function lo(t, n, r, i, a) {
	let o = pe(), s = t[P], c = s.rr, l = c.run = (c.run || 0) + 1, u, d = o.Ie ? ro(s.v, s.s) : null, f = () => _t || (o.T !== null && o.T.Ee !== null ? o.T.ce : 0), p = no(t, () => c.run === l && !he(o), a, s.s, () => {
		!(o.m & 1) && !o.Ie && D();
	}, f), m = l === 1, h = () => Ja(p, (e) => {
		u = n(d ?? e);
		let a = (n, a = 1) => {
			if (d && (n === void 0 || n === d) && (n = ro(d, s.s)), n !== e && n !== void 0) {
				let e = () => {
					let e = _t;
					vt(f());
					try {
						Ja(t, (e) => Qa(n, e, r, !0), !1);
					} finally {
						vt(e);
					}
				};
				i ? i(e, n) : e();
			}
			m && o.m & 4 || oo(c), a && Nt(o);
		}, l = Tn(o, u, a, (e, t) => {
			m && o.m & 4 || (t ? io(c) : ao(c, e));
		});
		o.Ie || a(l, o.m & 3);
	}, !1);
	try {
		m ? ra(h) : h();
	} catch (t) {
		throw m || (t instanceof e ? io(c) : ao(c, t)), t;
	}
	return o.m & 1 && o.T.Ee !== null && !o.Ie && !m && io(c), o;
}
function uo(e, t, n, r) {
	t || (t = {});
	let i = n?.key === void 0 ? "id" : n.key, a = {
		map: /* @__PURE__ */ new WeakMap(),
		node: null,
		live: /* @__PURE__ */ new Set(),
		st: so,
		It: !!n?.shallow,
		opt: r,
		key: typeof i == "function" ? i : i === null ? null : (e) => F(e) ? e[i] : void 0
	}, o = z(t, null, null, a);
	a.It && (o[P].s = !0, Mr(t));
	let s;
	if (n?.seedLoadingValue && (s = { loadingValue: void 0 }), e) {
		let t = Nn(() => {
			a.node || (a.node = pe()), lo(o, e, i);
		}, s);
		t.l &= -33, a.node = t, t.rr = a;
	}
	return o;
}
function fo(e, t, n) {
	let r = uo(e, t, n);
	return [r, (e) => Ja(r, e)];
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/store/index.js
function po(e, t, n) {
	return typeof e == "function" ? fo(e, t, n) : Ya(e, t);
}
function mo(e, t = "id") {
	return (n) => Qa(e, n, t);
}
// node_modules/.pnpm/@solidjs+signals@2.0.0/node_modules/@solidjs/signals/dist/prod/flatten.js
function ho(e, t) {
	if (typeof e == "function" && !e.length) {
		if (t?.doNotUnwrap) return e;
		do
			e = e();
		while (typeof e == "function" && !e.length);
	}
	if (!t?.skipNonRendered || e != null && e !== !0 && e !== !1 && e !== "") {
		if (Array.isArray(e)) {
			let n = [];
			return go(e, n, t) ? () => {
				let e = [];
				return go(n, e, {
					...t,
					doNotUnwrap: !1
				}), e;
			} : n;
		}
		return e;
	}
}
function go(t, n = [], r) {
	let i = null, a = !1;
	for (let o = 0; o < t.length; o++) try {
		let e = t[o];
		if (typeof e == "function" && !e.length) {
			if (r?.doNotUnwrap) {
				n.push(e), a = !0;
				continue;
			}
			do
				e = e();
			while (typeof e == "function" && !e.length);
		}
		Array.isArray(e) ? a = go(e, n, r) || a : r?.skipNonRendered && (e == null || e === !0 || e === !1 || e === "") || n.push(e);
	} catch (t) {
		if (!(t instanceof e)) throw t;
		i = t;
	}
	if (i) throw i;
	return a;
}
// node_modules/.pnpm/solid-js@2.0.0/node_modules/solid-js/dist/solid.js
var _o = !1, vo = {
	hydrating: !1,
	registry: void 0,
	done: !1
}, yo, bo = (...e) => Br(...e), W = zr, xo = (...e) => typeof e[0] == "function" && vo.hydrating ? yo(po, e[0], e[1] ?? {}, e[2]) : po(...e), So = ve, Co = Hr, wo = (...e) => Vr(...e);
function G(e, t, n, r) {
	return Yn(() => e(t || {}));
}
var To = (e) => {
	throw `Stale read from <${e}>.`;
};
function K(e) {
	let t = "fallback" in e ? {
		keyed: e.keyed,
		fallback: () => e.fallback
	} : { keyed: e.keyed }, n = pe(), r, i = () => gr(n, () => Wr(() => e.each, e.children, t));
	return vo.hydrating && (r = i()), () => (r ?? (r = i()))();
}
function Eo(e) {
	let t = e.keyed, n = Br(() => e.when, void 0), r = t ? n : Br(n, {
		equals: (e, t) => !e == !t,
		sync: !0
	});
	return Br(() => {
		let i = r();
		if (i) {
			let a = e.children;
			return typeof a == "function" && a.length > 0 ? Yn(t ? () => a(i) : () => a(() => (r() || To("Show"), n())), _o) : a;
		}
		return e.fallback;
	}, { sync: !0 });
}
// node_modules/.pnpm/solid-js@2.0.0/node_modules/solid-js/dist/internal.js
var Do = sr, Oo = vo, ko = /*#__PURE__*/ Symbol("slot"), Ao = /*#__PURE__*/ Symbol("index"), jo = {
	transparent: !0,
	sync: !0
}, Mo = { sync: !0 };
function q(e, t, n) {
	Co(e, t, n ? {
		sync: !0,
		...n,
		transparent: !n.scope
	} : jo);
}
function J(e) {
	return bo(() => e(), Mo);
}
function No(e, t, n, r) {
	let i = n.length, a = t.length, o = i, s = 0, c = 0, l, u, d, f;
	for (; s < a && t[s] === n[c];) s++, c++;
	if (s === a && c === o) return;
	let p = e.moveBefore && e.isConnected, m = r || e, h = (t, n) => {
		p && t.isConnected ? e.moveBefore(t, n) : e.insertBefore(t, n), (r || t[ko]) && (t[ko] = m);
	};
	if (!a) {
		for (let e of n) h(e, r);
		return;
	}
	let g = (t) => t && t.parentNode === e && (!(t = t[ko]) || t === m), _ = (t) => {
		for (; t < i && !g(n[t]);) t++;
		return n[t] || (u && u.parentNode !== e ? r || null : u);
	};
	for (u = g(f = t[a - 1]) ? f.nextSibling : r || null; s < a || c < o;) if (t[s] === n[c]) s++, c++;
	else {
		for (; a > s && o > c && t[a - 1] === n[o - 1];) a--, o--;
		if (a === s) for (f = _(o); c < o;) h(n[c++], f);
		else if (!g(f = t[s])) s++;
		else if (n[c] === t[a - 1] && (f === n[o - 1] || !l && f === n[c + 1] && t[s + 1] === n[c + 2])) do
			h(t[--a], f), c++;
		while (s < a - 1 && c < o && f === n[o - 1] && n[c] === t[a - 1]);
		else if (c < o && f === n[o - 1] && t[s + 1] !== n[o - 2] && g(n[c]) && g(t[a - 1])) h(f, _(o)), s++, o--;
		else {
			if (!l) for (l = 1, d = c; d < o;) n[d][Ao] = d++;
			if ((d = f[Ao]) >= 0 && n[d] === f) {
				if (c < d && d < o) {
					let i = s, l = 1;
					for (; ++i < a && i < o && t[i] === n[d + l];) l++;
					if (l > d - c) for (; c < d;) h(n[c++], f);
					else {
						let t = n[c++];
						s++, p ? h(t, f) : e.replaceChild(t, f), (r || t[ko]) && (t[ko] = m);
					}
				} else s++;
			} else f.remove(), s++;
		}
	}
}
var Po = "_$$", Fo = "_$SOLID_EVENT_OWNER", Io = {}, Lo = /* @__PURE__ */ new Set(), Ro = /* @__PURE__ */ new Map();
function zo(e, t, n, r = {}) {
	let i;
	Ho(t);
	try {
		So((a) => {
			i = a, r.onError && (pe()[yt] = r.onError);
			let o = e();
			t === document ? q(() => ho(o), () => {}) : Z(t, () => o, t.firstChild ? null : void 0, n, {
				...r.insertOptions,
				schedule: !0
			});
		}, { id: r.renderId }), zt();
	} catch (e) {
		throw i && i(), Uo(t), e;
	}
	return () => {
		i(), Uo(t), t.textContent = "";
	};
}
function Bo(e, t, n) {
	let r = document.createElement("template");
	r.innerHTML = e;
	let i = r.content.firstChild;
	return n === 2 ? i.firstChild : i;
}
function Y(e, t) {
	let n;
	return (r) => (n || (n = Bo(e, r, t)), t === 1 ? document.importNode(n, !0) : n.cloneNode(!0));
}
function Vo(e) {
	for (let t of e) Lo.has(t) || (Lo.add(t), Ro.forEach((e, n) => Ko(t, n, e)));
}
function Ho(e) {
	let t = Wo(e, e);
	t && (t.roots = (t.roots || 0) + 1);
}
function Uo(e) {
	let t = Ro.get(e);
	t && (t.roots > 1 ? t.roots-- : delete t.roots), Go(e, e);
}
function Wo(e, t = e) {
	if (!e || !t) return;
	let n = Ro.get(e);
	return n || Ro.set(e, n = {
		owners: /* @__PURE__ */ new Map(),
		handlers: /* @__PURE__ */ new Map()
	}), n.owners.set(t, (n.owners.get(t) || 0) + 1), Lo.forEach((t) => Ko(t, e, n)), n;
}
function Go(e, t = e) {
	let n = Ro.get(e);
	if (!n) return;
	let r = n.owners.get(t);
	r > 1 ? n.owners.set(t, r - 1) : n.owners.delete(t), n.owners.size || (n.handlers.forEach((t, n) => e.removeEventListener(n, t)), Ro.delete(e));
}
function Ko(e, t, n) {
	if (n.handlers.has(e)) return;
	let r = (e) => ss(e, t, n);
	n.handlers.set(e, r), t.addEventListener(e, r);
}
var qo = (e) => e._$host || e.parentNode || e.host;
function Jo(e, t) {
	let n = 0;
	for (; e;) {
		if (t.owners.has(e)) return {
			owner: e,
			distance: n
		};
		n++, e = qo(e);
	}
}
function Yo(e, t, n) {
	if (as(e)) return;
	let r = e.nodeName;
	t === "value" && r === "SELECT" ? us(e, n) : (t === "value" || t === "defaultValue") && (r === "INPUT" || r === "TEXTAREA") ? n == null && /^(checkbox|radio)$/.test(e.type) ? e.removeAttribute("value") : e[t] = n ?? "" : e[t] = n, $o(e, t);
}
var Xo = null, Zo = [];
function Qo(e, t) {
	for (let n = 0; n < e.length; n++) e[n](t);
}
function $o(e, t) {
	Xo !== null && e._$claimed && Zo.some((e) => e.includes(t.slice(t.indexOf(":") + 1))) && Qo(Xo, e);
}
function es(e, t) {
	return Xo !== null && !e._$claimed && (e._$claimed = !0, t === void 0 ? Qo(Xo, e) : gr(t, () => Qo(Xo, e))), e;
}
function X(e, t, n) {
	if (as(e)) return;
	let r = t === "multiple" && e.localName === "select";
	if (n == null || n === !1) e.removeAttribute(t);
	else if (e.setAttribute(t, n === !0 ? "" : n), r && !e._$multiple) {
		let t = e.options;
		for (let e = 0; e < t.length; e++) t[e].defaultSelected && (t[e].selected = !0);
	}
	r && (e._$multiple = !0), $o(e, t);
}
var ts = { scope: !0 }, ns = null, rs = null, is = null;
function Z(e, t, n, r, i) {
	let a = n !== void 0;
	if (a && !r && (r = []), ns !== null && (r = ns.claimInitial(e, a, r)), typeof t != "function" && (t = fs(t, r, a, !0), typeof t != "function")) {
		cs(e, t, r, n), is !== null && i && i.host && is(t, i.host);
		return;
	}
	if (a && r.length === 0) {
		let t = document.createTextNode("");
		e.insertBefore(t, n), r = [t];
	}
	let o = !1;
	q(() => {
		ns !== null && (r = ns.reclaimRegion(r, e, n));
		let s = fs(t(), r, a, !0), c = o;
		return o = !0, typeof s == "function" ? (q(() => (ns !== null && (r = ns.reclaimRegion(r, e, n)), fs(s, r, a)), (t) => {
			r = cs(e, t, r, n), is !== null && i && i.host && is(r, i.host);
		}, c && !(i && i.schedule) ? {
			...i,
			schedule: !0
		} : i), Io) : s;
	}, (t) => {
		t !== Io && (r = cs(e, t, r, n), is !== null && i && i.host && is(r, i.host));
	}, t.$s ? i ? {
		...i,
		scope: !0
	} : ts : i);
}
function as(e) {
	return !Oo.hydrating || Oo.isClaiming && !Oo.isClaiming() ? !1 : !e || e.isConnected ? !0 : os !== null && os.claimed(e);
}
var os = null;
function ss(e, t, n) {
	if (ns !== null && ns.dedupEvent(e)) return;
	let r = e[Fo], i;
	if (r) {
		if (r === !0 || r === t || !t.contains(r)) return;
		i = r;
	}
	let a = n.owners.size === 1 && n.owners.has(t) ? t : Jo(e.target, n)?.owner;
	if (!a || a === i) return;
	e[Fo] = a;
	let o = i || e.target, s = Po + e.type, c = (t, n) => Object.defineProperty(e, t, {
		configurable: !0,
		value: n
	}), l = () => {
		let t = o[s];
		if (t && !o.disabled) {
			c("currentTarget", o);
			let n = o[`${s}Data`];
			if (n === void 0 ? typeof t == "function" ? t.call(o, e) : t.handleEvent(e) : t.call(o, n, e), e.cancelBubble) return;
		}
		return o.host && typeof o.host != "string" && !o.host._$host && o.contains(e.target) && c("target", o.host), !0;
	}, u = () => o === a || o.parentNode === a, d = () => {
		for (; o && l() && !u();) o = qo(o);
	};
	if (i) i === e.target && (o = qo(i)), o && o !== a && d();
	else if (e.composedPath) {
		let t = e.composedPath();
		if (t.length) {
			c("target", t[0]);
			for (let e = 0; e < t.length && (o = t[e], l()); e++) {
				if (o._$host) {
					o = o._$host, d();
					break;
				}
				if (u()) break;
			}
		} else d();
	} else d();
	delete e.target, delete e.currentTarget;
}
function cs(e, t, n, r) {
	if (ns !== null && as(e)) {
		if (t && t !== n) {
			let e = Array.isArray(t);
			for (let r of e ? t : [t]) if (r && r.nodeType) {
				if (!as(r)) return n;
			} else if (e && (typeof r == "string" || typeof r == "number")) return n;
		}
		return t;
	}
	if (t === n) return t;
	if (ns !== null && Oo.hydrating && t && t.length !== 0) {
		let r = [].concat(n ?? []);
		if ([].concat(t).every((t) => (t === r[0] && r.shift(), t?.parentNode === e)) && !r.length) return t;
	}
	let i = typeof t;
	if (i === "string" || i === "number") {
		let r = typeof n;
		r === "string" || r === "number" ? e.firstChild.data = t : ps(e, n) ? e.textContent = t : (ms(e, n), e.insertBefore(document.createTextNode(t), e.firstChild));
	} else if (t === void 0) hs(e, n, r);
	else if (t.nodeType) Array.isArray(n) ? hs(e, n, r ?? null, t) : n != null && n.nodeType ? n.parentNode === e ? e.replaceChild(t, n) : e.appendChild(t) : n != null && e.firstChild ? e.replaceChild(t, e.firstChild) : e.appendChild(t), (r || t[ko]) && (t[ko] = r || e);
	else if (Array.isArray(t)) {
		let i = Array.isArray(n);
		for (let e = 0, r = t.length; e < r; e++) {
			let r = t[e], a = typeof r;
			if (a === "string" || a === "number") {
				let a = i ? n[e] : void 0;
				if (a && a.nodeType === 3) {
					let n = a._$d;
					n !== r && (n !== void 0 || a.data !== "" + r) && (a.data = a._$d = r), t[e] = a;
				} else t[e] = document.createTextNode(r);
			}
		}
		t.length === 0 ? hs(e, n, r) : i ? No(e, n, t, r) : (n != null && hs(e, n), No(e, [], t));
	}
	return rs && rs(e), t;
}
function ls(e) {
	(e = e.currentTarget || e)._$v = null, e.removeEventListener("change", ls, !0);
}
function us(e, t) {
	let n = e._$v && e._$v.map;
	if (t != null && t.map ? n || e.addEventListener("change", ls, !0) : n && e.removeEventListener("change", ls, !0), t == null) return e._$v = null, queueMicrotask(() => e.value = t) || (e.value = t);
	e._$v = t, (rs || (rs = ds))(e), queueMicrotask(() => rs(e));
}
function ds(e) {
	e && e._$v == null && (e = e.parentNode);
	let t = e && e._$v;
	if (t != null) {
		if (t.map) {
			let n = [...e.options];
			for (let e = 0; e < n.length; e++) n[e].selected = t.some((t) => t == n[e].value);
			t.every((e) => n.some((t) => t.value == e)) && ls(e);
		} else e.value = t, e.selectedIndex > -1 && e.value == t && (e._$v = null);
	}
}
function fs(e, t, n, r) {
	if (e = ho(e, {
		skipNonRendered: !0,
		doNotUnwrap: r
	}), r && typeof e == "function") return e;
	if (n && !Array.isArray(e) && (e = [e ?? ""]), ns !== null && Oo.hydrating && Array.isArray(e)) for (let n = 0, r = e.length; n < r; n++) {
		let r = e[n], i = t && t[n], a = typeof r;
		(a === "string" || a === "number") && i && i.nodeType === 3 && as(i) && (e[n] = i);
	}
	return e;
}
function ps(e, t) {
	if (t == null) return !0;
	if (Array.isArray(t)) return t.length ? e.firstChild === t[0] && e.lastChild === t[t.length - 1] : e.firstChild === null;
	if (t === "") return e.firstChild === null;
	if (t.nodeType) return e.firstChild === t && e.lastChild === t;
	let n = e.firstChild;
	return n !== null && n.nodeType === 3 && e.lastChild === n;
}
function ms(e, t) {
	if (Array.isArray(t)) for (let n = 0; n < t.length; n++) {
		let r = t[n];
		r.parentNode === e && r.remove();
	}
	else if (t.nodeType) t.parentNode === e && t.remove();
	else {
		let t = e.firstChild;
		t && t.nodeType === 3 && t.remove();
	}
}
function hs(e, t, n, r) {
	if (n === void 0) return ps(e, t) ? e.textContent = "" : ms(e, t);
	if (t.length) {
		let i = !1;
		for (let a = t.length - 1; a >= 0; a--) {
			let o = t[a];
			if (r !== o) {
				let t = o[ko], s = o.parentNode === e && (!t || t === (n || e));
				r && !i && !a ? s ? e.replaceChild(r, o) : e.insertBefore(r, n) : s && o.remove();
			} else i = !0;
		}
	} else r && e.insertBefore(r, n);
	r && (n || r[ko]) && (r[ko] = n || e);
}
// mcp.js
var gs = "2026-07-28";
function _s(e, t = {}, n, r) {
	let i = {
		Authorization: `Bearer ${r}`,
		Accept: "application/json, text/event-stream",
		"Content-Type": "application/json",
		"MCP-Protocol-Version": gs,
		"Mcp-Method": e
	};
	e === "tools/call" && (i["Mcp-Name"] = t.name), e === "resources/read" && (i["Mcp-Name"] = t.uri);
	let a = {
		jsonrpc: "2.0",
		id: n,
		method: e,
		params: {
			...t,
			_meta: {
				"io.modelcontextprotocol/protocolVersion": gs,
				"io.modelcontextprotocol/clientInfo": {
					name: "local-fabric",
					version: "1"
				},
				"io.modelcontextprotocol/clientCapabilities": {}
			}
		}
	};
	return {
		method: "POST",
		headers: i,
		body: JSON.stringify(a)
	};
}
function vs(e, t = "") {
	let n = 0;
	async function r(n, r, i, a) {
		let o = await fetch(t + "/mcp", {
			..._s(n, r, i, e),
			cache: "no-store",
			signal: a
		});
		if (!o.ok) throw Error(o.status + " " + await o.text());
		return o;
	}
	async function i(e, t) {
		let i = ++n, a = await (await r(e, t, i)).json();
		if (a.id !== i) throw Error("MCP response ID mismatch");
		if (a.error) throw Error(a.error.message);
		if (a.result?.resultType !== "complete") throw Error("Expected complete result");
		return a.result;
	}
	async function a(e) {
		let t = await i("resources/read", { uri: e });
		return JSON.parse(t.contents[0].text);
	}
	async function o(e, t) {
		let n = await i("tools/call", {
			name: e,
			arguments: t
		});
		if (n.isError) throw Error(n.content[0].text);
		return n.content[0].text;
	}
	async function* s(e, t) {
		let i = ++n, a = (await r("subscriptions/listen", { notifications: { resourceSubscriptions: e } }, i, t)).body.pipeThrough(new TextDecoderStream()).getReader(), o = "", s = !1;
		try {
			for (;;) {
				let { value: e, done: t } = await a.read();
				if (t) return;
				o += e;
				let n;
				for (; (n = o.indexOf("\n\n")) !== -1;) {
					let e = o.slice(0, n);
					o = o.slice(n + 2);
					let t = e.split("\n").find((e) => e.startsWith("data: "));
					if (!t) continue;
					let r = JSON.parse(t.slice(6));
					if (r.id === i && r.result?.resultType === "complete") return;
					if (r.params?._meta?.["io.modelcontextprotocol/subscriptionId"] !== i) throw Error("Subscription ID mismatch");
					if (s) r.method === "notifications/resources/updated" && (yield {
						initial: !1,
						uris: [r.params.uri]
					});
					else {
						if (r.method !== "notifications/subscriptions/acknowledged") throw Error("Expected subscription acknowledgment");
						s = !0, yield {
							initial: !0,
							uris: r.params.notifications.resourceSubscriptions ?? []
						};
					}
				}
			}
		} finally {
			await a.cancel().catch(() => {}), a.releaseLock();
		}
	}
	return {
		read: a,
		call: o,
		rpc: i,
		watch: s
	};
}
// connection.js
var ys, [bs, xs] = W(""), [Ss, Cs] = W("Disconnected"), [ws, Ts] = W(""), [Es, Ds] = xo([]), [Os, ks] = xo({}), [As, js] = W(null), [Ms, Ns] = W(null), [Ps, Fs] = W([]);
async function Is(e) {
	try {
		await e();
	} catch (e) {
		Ts(e.message);
	}
}
var Ls = (e) => new Promise((t) => setTimeout(t, e));
async function Rs(e, t, n) {
	await ys.call(e, t), Ts("Accepted; waiting for " + n);
	for (let e = 0; e < 120; e++) {
		await Ls(500);
		let e = await ys.read("fabric://status");
		if (e[n] !== "pending") {
			Ts(n + ": " + e[n]);
			return;
		}
	}
	Ts("Still pending. Check status before retrying.");
}
function zs() {
	wo(bs, (e) => {
		if (!e) {
			Ds(mo([])), ks(mo({})), Ns(null), js(null), Fs([]);
			return;
		}
		let t = new AbortController(), n = vs(e);
		ys = n;
		let r = t.signal;
		return (async () => {
			for (; !r.aborted;) {
				try {
					Cs("Connecting");
					for await (let { initial: e, uris: t } of n.watch([
						"fabric://devices/metadata",
						"fabric://devices/state",
						"fabric://activity",
						"fabric://automation/actions",
						"fabric://automation/rules"
					], r)) {
						e && Cs("Live");
						for (let e of t) {
							let t = await n.read(e);
							if (r.aborted) return;
							e === "fabric://devices/metadata" && Ds(mo(Object.entries(t.devices).map(([e, t]) => ({
								...t,
								device_id: Number(e)
							})), "device_id")), e === "fabric://devices/state" && ks(mo(t.devices)), e === "fabric://activity" && js(t), e === "fabric://automation/actions" && Fs(t), e === "fabric://automation/rules" && Ns(t);
						}
					}
				} catch (e) {
					if (r.aborted) return;
					if (e.message.startsWith("401 ")) {
						xs(""), Ts("Token rejected. Use the current serial token.");
						return;
					}
					Ts(e.message);
				}
				Cs("Reconnecting"), await Ls(1e3);
			}
		})(), () => t.abort();
	});
}
// fields.jsx
var Bs = /* @__PURE__ */ Y("<label><!><!>"), Vs = /* @__PURE__ */ Y("<select>"), Hs = /* @__PURE__ */ Y("<input required>"), Us = /* @__PURE__ */ Y("<option>"), Ws = (e) => Object.entries(e || {});
function Gs(e, t) {
	let n = {};
	for (let [r, i] of Ws(t)) {
		let t = e.elements.namedItem(r).value;
		n[r] = i.type === "boolean" ? t === "true" : ["integer", "number"].includes(i.type) ? Number(t) : t;
	}
	return n;
}
function Ks(e) {
	return G(K, {
		get each() {
			return Object.keys(e.schema || {});
		},
		children: (t) => {
			let n = () => e.schema[t];
			var r = Bs(), i = r.firstChild, a = i.nextSibling;
			return Z(r, t, i), Z(r, (() => {
				var r = J(() => !!(n().enum || n().type === "boolean"));
				return () => r() ? (() => {
					var r = Vs();
					return X(r, "name", t), Z(r, G(K, {
						get each() {
							return n().enum || [!0, !1];
						},
						children: (e) => (() => {
							var t = Us();
							return Z(t, () => String(e?.label ?? e)), q(() => String(e?.value ?? e), (e) => {
								t.value = e;
							}), t;
						})()
					})), q(() => String(e.defaults?.[t] ?? n().enum?.[0]?.value ?? n().enum?.[0] ?? !0), (e) => {
						Yo(r, "value", e);
					}), r;
				})() : (() => {
					var r = Hs();
					return X(r, "name", t), q(() => ({
						e: ["integer", "number"].includes(n().type) ? "number" : "text",
						t: n().step ?? (n().type === "integer" ? 1 : "any"),
						a: n().min,
						o: n().max,
						i: e.defaults?.[t] ?? n().min ?? "",
						n: Do()
					}), ({ e, t, a: n, o: i, i: a, n: o }, s) => {
						e !== s?.e && X(r, "type", e), t !== s?.t && X(r, "step", t), n !== s?.a && X(r, "min", n), i !== s?.o && X(r, "max", i), a === s?.i && o || Yo(r, "value", a);
					}), r;
				})();
			})(), a), r;
		}
	});
}
// rules/PropertyFields.jsx
var qs = /* @__PURE__ */ Y("<label><select><option value>Choose…</option><!><!>"), Js = /* @__PURE__ */ Y("<option> (unavailable)"), Ys = /* @__PURE__ */ Y("<option>"), Xs = /* @__PURE__ */ Y("<label>Operator<select>"), Zs = /* @__PURE__ */ Y("<label>Value <!><!>"), Qs = /* @__PURE__ */ Y("<select required>"), $s = /* @__PURE__ */ Y("<input required>"), Q = (e) => e?.clock ? "clock:" + e.clock : e?.delay_s === void 0 ? e?.native ? "local:" + e.native : e?.device ? [
	e.device,
	e.endpoint,
	e.cluster,
	e.property ?? e.name
].join("/") : "" : "delay";
function ec(e) {
	return Es.flatMap((t) => Object.entries(Os[t.device_id]?.endpoints ?? {}).flatMap(([n, r]) => Object.entries(r.clusters ?? {}).flatMap(([r, i]) => Object.entries(i[e] ?? {}).map(([i, a]) => ({
		device: t.device_id,
		endpoint: +n,
		cluster: r,
		[e === "properties" ? "property" : "name"]: i,
		meta: a,
		label: t.name + " · " + n + " · " + r + " / " + i
	})))));
}
function tc(e) {
	var t = qs(), n = t.firstChild, r = n.firstChild.nextSibling, i = r.nextSibling;
	return Z(t, () => e.label, n), n.addEventListener("change", (t) => e.change(t.currentTarget.value)), Z(n, (() => {
		var t = J(() => !(!e.value || e.options.some((t) => Q(t) === e.value)));
		return () => t() ? (() => {
			var t = Js(), n = t.firstChild;
			return Z(t, () => e.value, n), q(() => e.value, (e) => {
				t.value = e;
			}), t;
		})() : void 0;
	})(), r), Z(n, G(K, {
		get each() {
			return e.options;
		},
		children: (t) => (() => {
			var n = Ys();
			return Z(n, () => t.label), q(() => ({
				e: Q(t),
				t: e.value === Q(t),
				a: Do()
			}), ({ e, t, a: r }, i) => {
				e === i?.e && r || (n.value = e), t === i?.t && r || (n.selected = t);
			}), n;
		})()
	}), i), q(() => ({
		e: e.required,
		t: e.value,
		a: Do()
	}), ({ e, t, a: r }, i) => {
		e !== i?.e && X(n, "required", e), t === i?.t && r || Yo(n, "value", t);
	}), t;
}
var nc = {
	boolean: ["true", "false"],
	enum: ["==", "!="],
	string: ["==", "!="],
	number: [
		">",
		"<",
		">=",
		"<=",
		"==",
		"!="
	]
};
function rc(e) {
	let t = [...e.enum ?? []];
	return e.value != null && !t.some((t) => (t?.value ?? t) === e.value) && t.push({
		value: e.value,
		label: e.label ?? e.value
	}), t;
}
function ic(e, t) {
	if (!e) return;
	let { label: n, meta: r, ...i } = e, a = {
		...i,
		type: r.type,
		op: t ?? nc[r.type][0]
	};
	if (a.op !== "changes" && a.type !== "boolean") {
		let e = rc(r)[0];
		a.value = a.type === "enum" ? e?.value ?? e : a.type === "number" ? r.value ?? 0 : "";
	}
	return a;
}
function ac(e) {
	let t = () => e.options.find((t) => Q(t) === Q(e.test)), n = () => t()?.meta, r = () => e.trigger ? {
		true: "becomes true",
		false: "becomes false",
		"==": "becomes equal to",
		"!=": "becomes different from",
		">": "crosses above",
		"<": "crosses below",
		">=": "reaches or exceeds",
		"<=": "reaches or falls below",
		changes: "changes"
	} : {
		true: "is true",
		false: "is false",
		"==": "is equal to",
		"!=": "is not equal to"
	};
	return J(() => J(() => !!n())() ? [(() => {
		var i = Xs(), a = i.firstChild.nextSibling;
		return a.addEventListener("change", (n) => e.change(ic(t(), n.currentTarget.value))), Z(a, G(K, {
			get each() {
				return [...nc[n().type], ...e.trigger ? ["changes"] : []];
			},
			children: (t) => (() => {
				var n = Ys();
				return n.value = t, Z(n, () => r()[t] ?? t), q(() => e.test.op === t, (e) => {
					n.selected = e;
				}), n;
			})()
		})), q(() => e.test.op, (e) => {
			Yo(a, "value", e);
		}), i;
	})(), G(Eo, {
		get when() {
			return J(() => e.test.op !== "changes")() && n().type !== "boolean";
		},
		get children() {
			var t = Zs(), r = t.firstChild.nextSibling, i = r.nextSibling;
			return Z(t, () => n().unit, r), Z(t, (() => {
				var t = J(() => n().type === "enum");
				return () => t() ? (() => {
					var t = Qs();
					return t.addEventListener("change", (t) => e.change({
						...e.test,
						value: JSON.parse(t.currentTarget.value)
					})), Z(t, G(K, {
						get each() {
							return rc(n());
						},
						children: (t) => (() => {
							var n = Ys();
							return Z(n, () => t?.label ?? String(t)), q(() => ({
								e: (t?.value ?? t) === e.test.value,
								t: JSON.stringify(t?.value ?? t),
								a: Do()
							}), ({ e, t, a: r }, i) => {
								e === i?.e && r || (n.selected = e), t === i?.t && r || (n.value = t);
							}), n;
						})()
					})), t;
				})() : (() => {
					var t = $s();
					return t._$$input = (t) => e.change({
						...e.test,
						value: n().type === "number" ? t.currentTarget.value === "" ? null : t.currentTarget.valueAsNumber : t.currentTarget.value
					}), q(() => ({
						e: n().type === "number" ? "number" : "text",
						t: n().step,
						a: n().min,
						o: n().max,
						i: e.test.value ?? "",
						n: Do()
					}), ({ e, t: n, a: r, o: i, i: a, n: o }, s) => {
						e !== s?.e && X(t, "type", e), n !== s?.t && X(t, "step", n), r !== s?.a && X(t, "min", r), i !== s?.o && X(t, "max", i), a === s?.i && o || Yo(t, "value", a);
					}), t;
				})();
			})(), i), t;
		}
	})] : void 0);
}
Vo(["input"]);
// rules/ClockFields.jsx
var oc = /* @__PURE__ */ Y("<div role=group aria-label=\"Days of week\"class=days><span>Days"), sc = /* @__PURE__ */ Y("<label>Schedule<select><option value=at>At</option><option value=during>During"), cc = /* @__PURE__ */ Y("<label><input type=time required>"), lc = /* @__PURE__ */ Y("<button type=button>"), uc = (e) => {
	let [t, n] = e.split(":").map(Number);
	return t * 60 + n;
}, dc = (e) => [Math.floor(e / 60), e % 60].map((e) => String(e).padStart(2, "0")).join(":"), fc = [
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat",
	"Sun"
], pc = {
	clock: "minute",
	label: "Local clock · every minute"
};
function mc(e) {
	let t = () => e.input.weekdays ?? (e.input.weekday ? [e.input.weekday] : [
		1,
		2,
		3,
		4,
		5,
		6,
		7
	]);
	function n(n) {
		let r = t().includes(n) ? t().filter((e) => e !== n) : [...t(), n].sort((e, t) => e - t);
		if (!r.length) return;
		let { weekday: i, ...a } = e.input;
		e.change({
			...a,
			weekdays: r
		});
	}
	function r(t) {
		let { start: n, end: r, at: i, ...a } = e.input;
		e.change(t ? {
			...a,
			at: n ?? 1080
		} : {
			...a,
			start: i ?? 1080,
			end: Math.min(1440, (i ?? 1080) + 60)
		});
	}
	return [
		J(() => J(() => !e.condition)() ? (() => {
			var t = sc(), n = t.firstChild.nextSibling, i = n.firstChild, a = i.nextSibling;
			return n.addEventListener("change", (e) => r(e.currentTarget.value === "at")), q(() => ({
				e: e.input.at === void 0 ? "during" : "at",
				t: e.input.at !== void 0,
				a: e.input.at === void 0,
				o: Do()
			}), ({ e, t, a: r, o }, s) => {
				e === s?.e && o || Yo(n, "value", e), t === s?.t && o || (i.selected = t), r === s?.a && o || (a.selected = r);
			}), t;
		})() : void 0),
		G(K, {
			get each() {
				return e.input.at === void 0 ? ["start", "end"] : ["at"];
			},
			children: (t) => (() => {
				var n = cc(), r = n.firstChild;
				return Z(n, t === "at" ? "Time" : t === "start" ? "From" : "Until", r), r._$$input = (n) => {
					let r = n.currentTarget.value;
					r && e.change({
						..."at" in e.input ? {} : {
							start: 0,
							end: 1440
						},
						...e.input,
						[t]: t === "end" && r === "00:00" ? 1440 : uc(r)
					});
				}, q(() => dc((e.input[t] ?? (t === "end" ? 1440 : 0)) % 1440), (e) => {
					r.value = e ?? "";
				}), n;
			})()
		}),
		(() => {
			var e = oc();
			return Z(e, () => fc.map((e, r) => (() => {
				var i = lc();
				return i._$$click = () => n(r + 1), Z(i, e), q(() => ({
					e: t().includes(r + 1) ? "true" : "false",
					t: t().length === 1 && t()[0] === r + 1
				}), ({ e, t }, n) => {
					e !== n?.e && X(i, "aria-pressed", e), t !== n?.t && X(i, "disabled", t);
				}), i;
			})()), null), e;
		})()
	];
}
Vo(["input", "click"]);
// rules/WhenFields.jsx
var hc = /* @__PURE__ */ Y("<fieldset class=when><legend>When</legend><button type=button>Add input</button><!><!><!>"), gc = /* @__PURE__ */ Y("<fieldset><!><!><!><!><!>"), _c = /* @__PURE__ */ Y("<label>Lua input name<input required pattern=[A-Za-z_][A-Za-z0-9_]* maxLength=23>"), vc = /* @__PURE__ */ Y("<button type=button>Remove input"), yc = /* @__PURE__ */ Y("<small>Choose a property test instead of “changes” to combine inputs."), bc = /* @__PURE__ */ Y("<small> If conditions are checked only then."), xc = /* @__PURE__ */ Y("<small>Lua runs when any watched value changes. Read values by name, e.g. event.current.<!>.");
function Sc(e) {
	let t = () => Array.isArray(e.when) ? e.when : [e.when ?? {}], n = () => Array.isArray(e.when);
	function r(t) {
		if (!t.length) {
			e.change(void 0);
			return;
		}
		if (t.length === 1 && !t[0].clock && (e.visual || !n())) {
			let { name: n, ...r } = t[0];
			e.change(r.device ? r : void 0);
			return;
		}
		let r = new Set(t.map((e) => e.name)), i = 1;
		e.change(t.map((e) => {
			if (e.name !== void 0 || !Q(e)) return e;
			let t;
			if (e.clock && !r.has("clock")) t = "clock";
			else {
				for (; r.has("input" + i);) i++;
				t = "input" + i++;
			}
			return r.add(t), {
				...e,
				name: t
			};
		}));
	}
	let i = (e, n) => r(t().map((t, r) => r === e ? n : t)), a = () => t().some((e) => e.op === "changes");
	var o = hc(), s = o.firstChild.nextSibling, c = s.nextSibling, l = c.nextSibling, u = l.nextSibling;
	return Z(o, G(K, {
		keyed: !1,
		get each() {
			return t();
		},
		children: (a, o) => {
			let s = (e) => i(o, {
				...e,
				...a().name === void 0 ? {} : { name: a().name }
			}), c = () => [...t().some((e, t) => t !== o && e.clock) ? [] : [pc], ...e.options.filter((e) => !t().some((t, n) => n !== o && Q(t) === Q(e)))];
			var l = gc(), u = l.firstChild, d = u.nextSibling, f = d.nextSibling, p = f.nextSibling, m = p.nextSibling;
			return Z(l, G(tc, {
				required: !0,
				get label() {
					return o === 0 ? "When input" : e.visual ? "And input" : "Watched input";
				},
				get value() {
					return Q(a());
				},
				get options() {
					return c();
				},
				change: (t) => {
					if (t === "clock:minute") {
						s({
							clock: "minute",
							...e.visual ? { at: 1080 } : {}
						});
						return;
					}
					let n = e.options.find((e) => Q(e) === t);
					s(e.visual ? ic(n) : e.select(t));
				}
			}), u), Z(l, (() => {
				var t = J(() => !!(e.visual && a().clock));
				return () => t() ? G(mc, {
					get input() {
						return a();
					},
					change: s
				}) : void 0;
			})(), d), Z(l, (() => {
				var n = J(() => !!(e.visual && a().device));
				return () => n() ? G(ac, {
					get options() {
						return e.options;
					},
					get test() {
						return a();
					},
					get trigger() {
						return t().length === 1;
					},
					change: s
				}) : void 0;
			})(), f), Z(l, (() => {
				var t = J(() => !!(!e.visual && n() && Q(a())));
				return () => t() ? (() => {
					var e = _c(), t = e.firstChild.nextSibling;
					return t._$$input = (e) => i(o, {
						...a(),
						name: e.currentTarget.value
					}), q(() => a().name, (e) => {
						t.value = e ?? "";
					}), e;
				})() : void 0;
			})(), p), Z(l, (() => {
				var e = J(() => !!(t().length > 1 || Q(a())));
				return () => e() ? (() => {
					var e = vc();
					return e._$$click = () => r(t().filter((e, t) => t !== o)), e;
				})() : void 0;
			})(), m), l;
		}
	}), s), s._$$click = () => r([...t(), {}]), Z(o, (() => {
		var e = J(() => !!a());
		return () => e() ? yc() : void 0;
	})(), c), Z(o, (() => {
		var n = J(() => !!(e.visual && t().length > 1));
		return () => n() ? (() => {
			var e = bc(), n = e.firstChild;
			return Z(e, () => t().some((e) => e.at !== void 0) ? "Run at the selected minute if the other When tests are already true." : "Run when all When tests become true together.", n), e;
		})() : void 0;
	})(), l), Z(o, (() => {
		var r = J(() => !(e.visual || !n()));
		return () => r() ? (() => {
			var e = xc(), n = e.firstChild.nextSibling;
			return Z(e, () => t().find((e) => e.name)?.name, n), e;
		})() : void 0;
	})(), u), q(() => t().length >= 4 || a() || t().some((e) => !Q(e)), (e) => {
		X(s, "disabled", e);
	}), o;
}
Vo(["click", "input"]);
// rules/compile.js
var Cc = (e) => Array.isArray(e) ? e : [e], wc = (e) => "\"" + e.replace(/[\x00-\x1f"\\]/g, (e) => "\\" + String(e.charCodeAt(0)).padStart(3, "0")) + "\"", Tc = (e) => typeof e == "string" ? wc(e) : String(e), $ = (e) => {
	throw Error(e);
};
function Ec(e) {
	return {
		device: e.device,
		endpoint: e.endpoint,
		cluster: e.cluster,
		property: e.property
	};
}
function Dc(e) {
	let t = ["v"];
	e.weekdays && (Array.isArray(e.weekdays) && e.weekdays.length && !e.weekdays.some((e) => !Number.isInteger(e) || e < 1 || e > 7) && new Set(e.weekdays).size === e.weekdays.length || $("Invalid weekdays"), t.push("(" + e.weekdays.map((e) => "v.weekday == " + e).join(" or ") + ")"));
	let n = "v.hour*60+v.minute";
	return e.at === void 0 ? (e.start !== void 0 || e.end !== void 0) && ((!Number.isInteger(e.start) || !Number.isInteger(e.end) || e.start < 0 || e.start >= e.end || e.end > 1440) && $("Invalid clock window"), t.push(n + " >= " + e.start, n + " < " + e.end)) : ((!Number.isInteger(e.at) || e.at < 0 || e.at >= 1440 || e.start !== void 0 || e.end !== void 0) && $("Invalid clock time"), t.push(n + " == " + e.at)), t.join(" and ");
}
var Oc = (e, t) => !t?.length || t.some((t) => (t?.value ?? t) === e);
function kc(e, t) {
	if (t.type !== "enum" && !Oc(e, t.enum)) return !1;
	switch (t.type) {
		case "boolean": return typeof e == "boolean";
		case "string": return typeof e == "string";
		case "enum": return (typeof e == "string" || Number.isInteger(e)) && (e === t.value || t.enum?.some((t) => (t?.value ?? t) === e));
		case "integer":
		case "number": return Number.isFinite(e) && (t.type !== "integer" || Number.isInteger(e)) && !(e < t.min || e > t.max) && (!t.step || Math.abs(e / t.step - Math.round(e / t.step)) < 1e-7);
		default: return !1;
	}
}
function Ac(e, t, n) {
	if (e.clock === "minute") return Dc(e);
	let r = t.find((t) => t.device === e.device && t.endpoint === e.endpoint && t.cluster === e.cluster && t.property === e.property)?.meta;
	return r && e.type === r.type || $("Unknown or changed property: " + e.property), n && e.op === "changes" ? "true" : e.type === "boolean" && ["true", "false"].includes(e.op) ? "v == " + e.op : (e.type !== "boolean" && [
		"==",
		"!=",
		...e.type === "number" ? [
			"<",
			"<=",
			">",
			">="
		] : []
	].includes(e.op) && kc(e.value, r) || $("Invalid comparison for " + e.property), "v ~= nil and v " + (e.op === "!=" ? "~=" : e.op) + " " + Tc(e.value));
}
function jc(e, t) {
	if (e.delay_s !== void 0) return (!Number.isInteger(e.delay_s) || e.delay_s < 1 || e.delay_s > 86400) && $("Delay must be 1–86400 seconds"), "automation.delay(" + e.delay_s + ")";
	let n = typeof e.native == "string", r = t.find((t) => n ? t.native === e.native : !t.native && t.device === e.device && t.endpoint === e.endpoint && t.cluster === e.cluster && t.name === e.name);
	r || $("Unknown action: " + (e.native ?? e.name));
	let i = Object.entries(r.meta.arguments ?? {}), a = e.arguments ?? {};
	(i.length !== Object.keys(a).length || i.some(([e, t]) => !Object.hasOwn(a, e) || !kc(a[e], t) || n && t.type === "string" && new TextEncoder().encode(a[e]).length > 512)) && $("Invalid arguments for " + (e.native ?? e.name));
	let o = "{" + i.map(([e]) => "[" + wc(e) + "]=" + Tc(a[e])).join(",") + "}";
	return n ? "automation.invoke_local(" + wc(e.native) + "," + o + ")" : "matter.invoke_action(" + [
		e.device,
		e.endpoint,
		wc(e.cluster),
		wc(e.name),
		o
	].join(",") + ")";
}
function Mc(e, t, n) {
	let r = Cc(e.when), i = Array.isArray(e.when), a = [];
	(r.length < 1 || r.length > 4) && $("Select 1–4 inputs");
	let o = r.map((e) => Ac(e, t, !i)), s = r.map((e) => e.clock ? {
		name: e.name,
		clock: "minute"
	} : i ? {
		name: e.name,
		...Ec(e)
	} : Ec(e));
	if (i) {
		(r.some((e) => typeof e.name != "string" || !/^[A-Za-z_][A-Za-z0-9_]{0,22}$/.test(e.name)) || new Set(r.map((e) => e.name)).size !== r.length) && $("Use unique Lua input names"), new Set(s.map(({ name: e, ...t }) => JSON.stringify(t))).size !== r.length && $("Duplicate input"), a.push("local function ready(s)"), r.forEach((e, t) => a.push(" local v=s[" + wc(e.name) + "]", " if not (" + o[t] + ") then return false end")), a.push(" return true", "end");
		for (let e of r) e.at !== void 0 && a.push("local p=event.previous[" + wc(e.name) + "]", "if p.hour*60+p.minute == " + e.at + " then return end");
		a.push("if ready(event.previous) or not ready(event.current) then return end");
	} else e.when.op !== "changes" && a.push("local function ready(v) return " + o[0] + " end", "if ready(event.previous) or not ready(event.current) then return end");
	(e.conditions?.length ?? 0) > 4 && $("At most four conditions");
	for (let n of e.conditions ?? []) {
		let e = n.clock ? "automation.local_time()" : "matter.get_property(" + [
			n.device,
			n.endpoint,
			wc(n.cluster),
			wc(n.property)
		].join(",") + ")", r = n.clock ? "Outside selected local schedule" : "#" + n.device + "/" + n.endpoint + " " + n.cluster + "." + n.property + " " + n.op + (n.value === void 0 ? "" : " " + n.value);
		a.push("local v=" + e, "if not (" + Ac(n, t, !1) + ") then return automation.skip(" + wc(r) + (n.clock ? "" : ", v") + ") end");
	}
	let c = Cc(e.action);
	return (!c.length || c.length > 8) && $("Select 1–8 actions"), a.push(...c.map((e) => jc(e, n))), {
		when: i ? s : s[0],
		source: a.join("\n"),
		editor: e
	};
}
function Nc(e, t, n) {
	let r = {
		enabled: e.enabled,
		title: e.title
	};
	if (e.mode === "raw") Object.assign(r, {
		when: e.when,
		source: e.source
	});
	else {
		let i = {
			when: e.when,
			action: e.action
		};
		e.conditions?.length && (i.conditions = e.conditions), Object.assign(r, Mc(i, t, n));
	}
	return new TextEncoder().encode(JSON.stringify(r)).length > 3072 && $("Rule exceeds 3072 bytes"), r;
}
// rules/Traces.jsx
var Pc = /* @__PURE__ */ Y("<div class=\"flex items-end gap-3\"><label>Show runs<select><option value=all>All rules</option><option value=rule>Selected rule</option></select></label><small>Up to <!> finished runs · RAM only, since restart"), Fc = /* @__PURE__ */ Y("<ul class=\"max-h-64 overflow-auto\">"), Ic = /* @__PURE__ */ Y("<p role=status>"), Lc = /* @__PURE__ */ Y("<li>"), Rc = /* @__PURE__ */ Y("<li class=\"border-b border-divider py-1\"><strong>Run #<!> · <!> · <!></strong> · <!> ms · <div></div><!>"), zc = /* @__PURE__ */ Y("<div>"), Bc = /* @__PURE__ */ Y("<details><summary>Automation traces"), Vc = "fabric://automation/runs", Hc = (e) => e.time ? (/* @__PURE__ */ new Date(e.time * 1e3)).toLocaleString() : `boot +${Math.floor(e.uptime_ms / 1e3)}s`;
function Uc(e) {
	let [t, n] = W(null), [r, i] = W(!1), [a, o] = W("");
	wo(() => ys, (e) => {
		let t = new AbortController();
		return (async () => {
			for (; !t.signal.aborted;) {
				try {
					for await (let r of e.watch([Vc], t.signal)) {
						let r = await e.read(Vc);
						if (t.signal.aborted) return;
						n(r), o("");
					}
				} catch (e) {
					if (t.signal.aborted) return;
					o(e.message);
				}
				t.signal.aborted || await new Promise((e) => setTimeout(e, 1e3));
			}
		})(), () => t.abort();
	});
	let s = () => (t()?.finished ?? []).filter((t) => !r() || t.rule_id === e.ruleId);
	return [
		(() => {
			var e = Pc(), n = e.firstChild, a = n.firstChild.nextSibling, o = n.nextSibling, s = o.firstChild.nextSibling;
			return a.addEventListener("change", (e) => {
				i(e.currentTarget.value === "rule");
			}), Z(o, () => t()?.capacity ?? "…", s), q(() => r() ? "rule" : "all", (e) => {
				Yo(a, "value", e);
			}), e;
		})(),
		J(() => J(() => !!a())() ? (() => {
			var e = Ic();
			return Z(e, a), e;
		})() : void 0),
		(() => {
			var e = Fc();
			return Z(e, G(K, {
				get each() {
					return s();
				},
				get fallback() {
					var e = Lc();
					return Z(e, () => t() ? "No runs in this view." : "Loading traces…"), e;
				},
				children: (e) => (() => {
					var t = Rc(), n = t.firstChild, r = n.firstChild.nextSibling, i = r.nextSibling.nextSibling, a = i.nextSibling.nextSibling, o = n.nextSibling.nextSibling, s = o.nextSibling.nextSibling, c = s.nextSibling;
					return Z(n, () => e.id, r), Z(n, () => e.title || `Slot ${e.slot}`, i), Z(n, () => e.outcome, a), Z(t, () => e.elapsed_ms, o), Z(t, () => Hc(e), s), Z(s, () => e.trigger), Z(t, (() => {
						var t = J(() => !!e.reason);
						return () => t() ? (() => {
							var t = zc();
							return Z(t, () => e.reason), t;
						})() : void 0;
					})(), c), t;
				})()
			})), e;
		})()
	];
}
function Wc(e) {
	let [t, n] = W(!1);
	var r = Bc();
	return r.addEventListener("toggle", (e) => n(e.currentTarget.open)), Z(r, (() => {
		var n = J(() => !!t());
		return () => n() ? G(Uc, { get ruleId() {
			return e.ruleId;
		} }) : void 0;
	})(), null), r;
}
// rules/ActionSteps.jsx
var Gc = /* @__PURE__ */ Y("<fieldset><legend>Then, in order</legend><button type=button>Add step"), Kc = /* @__PURE__ */ Y("<fieldset data-then-step><legend>Step </legend><!><!><button type=button>Remove step"), qc = /* @__PURE__ */ Y("<label>Delay (seconds)<input required type=number min=1 max=86400 step=1>"), Jc = /* @__PURE__ */ Y("<div><!><!>"), Yc = /* @__PURE__ */ Y("<p>");
function Xc(e) {
	let t = (t, n) => e.change(e.steps.map((e, r) => r === t ? n : e));
	var n = Gc(), r = n.firstChild.nextSibling;
	return Z(n, G(K, {
		keyed: !1,
		get each() {
			return e.steps;
		},
		children: (n, r) => (() => {
			var i = Kc(), a = i.firstChild, o = a.nextSibling, s = o.nextSibling, c = s.nextSibling;
			return Z(a, r + 1, null), Z(i, G(tc, {
				label: "Action",
				required: !0,
				get options() {
					return e.options;
				},
				get value() {
					return Q(n());
				},
				change: (n) => t(r, n === "delay" ? { delay_s: 1 } : e.select(n) ?? {})
			}), o), Z(i, (() => {
				var e = J(() => n().delay_s !== void 0);
				return () => e() ? [" ", (() => {
					var e = qc(), i = e.firstChild.nextSibling;
					return i._$$input = (e) => t(r, { delay_s: e.currentTarget.valueAsNumber }), q(() => n().delay_s, (e) => {
						i.value = e ?? "";
					}), e;
				})()] : void 0;
			})(), s), Z(i, G(Eo, {
				get when() {
					return e.descriptor(n());
				},
				children: (e) => (() => {
					var i = Jc(), a = i.firstChild, o = a.nextSibling;
					return i._$$input = (i) => t(r, {
						...n(),
						arguments: Gs(i.currentTarget.closest("fieldset"), e().meta.arguments)
					}), Z(i, (() => {
						var t = J(() => !!n().native);
						return () => t() ? (() => {
							var t = Yc();
							return Z(t, () => e().meta.description), t;
						})() : void 0;
					})(), a), Z(i, G(Ks, {
						get schema() {
							return e().meta.arguments;
						},
						get defaults() {
							return n().arguments;
						}
					}), o), i;
				})()
			}), c), c._$$click = () => e.change(e.steps.filter((e, t) => t !== r)), i;
		})()
	}), r), r._$$click = () => e.change([...e.steps, {}]), q(() => e.steps.length >= 8, (e) => {
		X(r, "disabled", e);
	}), n;
}
Vo(["click", "input"]);
// rules/RuleEditor.jsx
var Zc = /* @__PURE__ */ Y("<section id=rules class=rules><h2>Automation rules</h2><label>Rule slot<select></select></label><form><label>Title<input maxLength=64></label><label>Enabled<input type=checkbox></label><fieldset class=definition><legend>Rule definition</legend><label>Mode<select><option value=visual>Visual</option><option value=raw>Raw Lua</option></select></label><!><!></fieldset><!><button class=primary>Save rule</button><button type=button>Delete rule</button><small>"), Qc = /* @__PURE__ */ Y("<option>: <!>"), $c = /* @__PURE__ */ Y("<label>Lua body<textarea required>"), el = /* @__PURE__ */ Y("<fieldset class=conditions><button type=button>Add condition"), tl = /* @__PURE__ */ Y("<legend>If all conditions hold"), nl = /* @__PURE__ */ Y("<fieldset><!><button type=button>Remove condition"), rl = /* @__PURE__ */ Y("<details><summary>View saved rule as Lua</summary><pre>"), il = () => ({
	mode: "visual",
	enabled: !0,
	conditions: [],
	title: ""
});
function al() {
	let [e, t] = W(1), [n, r] = W(il()), i = bo(() => ec("properties")), a = bo(() => [...ec("actions"), ...Ps().map((e) => ({
		native: e.name,
		label: e.name,
		meta: e
	}))]);
	function o(e, n = Ms()) {
		t(e);
		let i = n?.[e - 1];
		r(i ? {
			enabled: i.enabled,
			title: i.title,
			...i.editor ? {
				...i.editor,
				mode: "visual"
			} : {
				mode: "raw",
				when: i.when,
				source: i.source
			}
		} : il());
	}
	Ur(() => {
		o(1);
	});
	async function s(e) {
		let t = await ys.read("fabric://automation/rules");
		Ns(t), o(e, t);
	}
	let c = (e, t) => r({
		...n(),
		[e]: t
	}), l = (e, t) => {
		let n = e.find((e) => Q(e) === t);
		if (!n) return;
		let { label: r, meta: i, ...a } = n;
		return a;
	}, u = () => Array.isArray(n().action) ? n().action : [n().action ?? {}], d = bo(() => [{
		delay_s: 1,
		label: "Delay"
	}, ...a()]), f = (e) => a().find((t) => Q(t) === Q(e));
	async function p(t) {
		let r = { ...n() };
		if (!r.when || Array.isArray(r.when) && !r.when.length || r.mode === "visual" && !r.action) throw Error("Select a trigger and action");
		if (r.mode === "visual") {
			let e = u().map((e, n) => {
				if (e.delay_s !== void 0) return e;
				let r = f(e);
				if (!r) throw Error("Select an available action for each step");
				return {
					...e,
					arguments: Gs(t.querySelectorAll("[data-then-step]")[n], r.meta.arguments)
				};
			});
			if (!e.length) throw Error("Add an action or delay");
			r.action = e.length === 1 ? e[0] : e, delete r.source;
		}
		await ys.call("rule.save", {
			slot: e(),
			definition: Nc(r, i(), a())
		}), await s(e()), Ts("Rule saved on board");
	}
	var m = Zc(), h = m.firstChild.nextSibling, g = h.firstChild.nextSibling, _ = h.nextSibling, v = _.firstChild, y = v.firstChild.nextSibling, b = v.nextSibling, ee = b.firstChild.nextSibling, te = b.nextSibling, ne = te.firstChild.nextSibling, re = ne.firstChild.nextSibling, ie = ne.nextSibling, ae = ie.nextSibling, oe = te.nextSibling, se = oe.nextSibling, ce = se.nextSibling, le = ce.nextSibling;
	return g.addEventListener("change", (e) => o(+e.currentTarget.value)), Z(g, G(K, {
		get each() {
			return (Ms() ?? []).map((e, t) => t + 1);
		},
		children: (e) => (() => {
			var t = Qc(), n = t.firstChild, r = n.nextSibling;
			return t.value = e, Z(t, e, n), Z(t, () => Ms()?.[e - 1]?.title || "Untitled / empty", r), t;
		})()
	})), _.addEventListener("submit", (e) => {
		e.preventDefault(), Is(() => p(e.currentTarget));
	}), y._$$input = (e) => c("title", e.currentTarget.value), ee.addEventListener("change", (e) => c("enabled", e.currentTarget.checked)), re.addEventListener("change", (e) => {
		let t = e.currentTarget.value, i = n();
		(i.when || i.action || i.conditions?.length || i.source) && !confirm("Clear this draft and switch mode? The saved rule keeps running until you save a replacement.") ? e.currentTarget.value = i.mode : r({
			mode: t,
			title: i.title ?? "",
			enabled: i.enabled,
			...t === "visual" ? { conditions: [] } : { source: "" }
		});
	}), Z(te, G(Sc, {
		get visual() {
			return n().mode === "visual";
		},
		get when() {
			return n().when;
		},
		get options() {
			return i();
		},
		select: (e) => l(i(), e),
		change: (e) => c("when", e)
	}), ie), Z(te, (() => {
		var e = J(() => n().mode === "raw");
		return () => e() ? (() => {
			var e = $c(), t = e.firstChild.nextSibling;
			return t._$$input = (e) => c("source", e.currentTarget.value), q(() => ({
				e: Array.isArray(n().when) ? "-- event.current.<input name>, event.previous.<input name>" : "if not event.current then return end",
				t: n().source ?? "",
				a: Do()
			}), ({ e, t: n, a: r }, i) => {
				e !== i?.e && X(t, "placeholder", e), n === i?.t && r || (t.value = n ?? "");
			}), e;
		})() : void 0;
	})(), ae), Z(_, (() => {
		var e = J(() => n().mode === "visual");
		return () => e() ? (() => {
			var e = el(), t = e.firstChild;
			return Z(e, (() => {
				var e = J(() => !!n().conditions?.length);
				return () => e() ? [tl(), G(K, {
					keyed: !1,
					get each() {
						return n().conditions;
					},
					children: (e, t) => {
						let r = (e) => c("conditions", n().conditions.map((n, r) => r === t ? e : n));
						var a = nl(), o = a.firstChild, s = o.nextSibling;
						return Z(a, G(tc, {
							required: !0,
							label: t === 0 ? "If input" : "And condition",
							get options() {
								return [pc, ...i()];
							},
							get value() {
								return Q(e());
							},
							change: (e) => r(e === "clock:minute" ? {
								clock: "minute",
								start: 1080,
								end: 1320
							} : ic(i().find((t) => Q(t) === e)) ?? {})
						}), o), Z(a, (() => {
							var t = J(() => !!e().clock);
							return () => t() ? G(mc, {
								condition: !0,
								get input() {
									return e();
								},
								change: r
							}) : G(ac, {
								get options() {
									return i();
								},
								get test() {
									return e();
								},
								change: r
							});
						})(), s), s._$$click = () => c("conditions", n().conditions.filter((e, n) => n !== t)), a;
					}
				})] : void 0;
			})(), t), t._$$click = () => c("conditions", [...n().conditions ?? [], {}]), q(() => (n().conditions?.length ?? 0) >= 4, (e) => {
				X(t, "disabled", e);
			}), e;
		})() : void 0;
	})(), oe), Z(_, (() => {
		var e = J(() => n().mode === "visual");
		return () => e() ? G(Xc, {
			get steps() {
				return u();
			},
			get options() {
				return d();
			},
			descriptor: f,
			select: (e) => l(a(), e),
			change: (e) => c("action", e)
		}) : void 0;
	})(), se), ce._$$click = () => Is(async () => {
		confirm("Delete this rule?") && (await ys.call("rule.remove", { slot: e() }), await s(e()));
	}), Z(_, (() => {
		var t = J(() => !!Ms()?.[e() - 1]?.editor);
		return () => t() ? (() => {
			var t = rl(), n = t.firstChild.nextSibling;
			return Z(n, () => Ms()[e() - 1].source), t;
		})() : void 0;
	})(), le), Z(le, () => Ms()?.[e() - 1]?.diagnostic), Z(m, G(Wc, { get ruleId() {
		return Ms()?.[e() - 1]?.rule_id;
	} }), null), q(() => ({
		e: e(),
		t: n().title || "",
		a: n().enabled,
		o: n().mode,
		i: Do()
	}), ({ e, t, a: n, o: r, i }, a) => {
		e === a?.e && i || Yo(g, "value", e), t === a?.t && i || (y.value = t ?? ""), n === a?.a && i || (ee.checked = n), r === a?.o && i || Yo(re, "value", r);
	}), m;
}
Vo(["input", "click"]);
// DeviceActivity.jsx
var ol = /* @__PURE__ */ Y("<section id=activity><h2>Device activity</h2><p>Recent reported property changes · since restart</p><ol class=\"max-h-56 overflow-auto\">"), sl = /* @__PURE__ */ Y("<li>"), cl = /* @__PURE__ */ Y("<li>#<!>/<!> <!>.<!>: <!> · <!>");
function ll(e) {
	return e.current == null ? "unknown" : e.cluster === "on_off" ? e.current ? "on" : "off" : e.cluster === "occupancy_sensing" ? e.current ? "occupied" : "unoccupied" : String(e.current) + (e.truncated ? "…" : "") + (e.unit ? " " + e.unit : "");
}
function ul() {
	var e = ol(), t = e.firstChild.nextSibling.nextSibling;
	return Z(t, G(K, {
		get each() {
			return As() ?? [];
		},
		get fallback() {
			var e = sl();
			return Z(e, () => As() ? "No device transitions yet." : "Loading…"), e;
		},
		children: (e) => (() => {
			var t = cl(), n = t.firstChild.nextSibling, r = n.nextSibling.nextSibling, i = r.nextSibling.nextSibling, a = i.nextSibling.nextSibling, o = a.nextSibling.nextSibling, s = o.nextSibling.nextSibling;
			return Z(t, () => e.device, n), Z(t, () => e.endpoint, r), Z(t, () => e.cluster, i), Z(t, () => e.property, a), Z(t, () => ll(e), o), Z(t, (() => {
				var t = J(() => !!e.time);
				return () => t() ? (/* @__PURE__ */ new Date(e.time * 1e3)).toLocaleString() : `boot +${Math.floor(e.uptime_ms / 1e3)}s`;
			})(), s), t;
		})()
	})), e;
}
// DevicePanel.jsx
var dl = /* @__PURE__ */ Y("<article><h3> <small>#<!> · <!><!></small></h3><!><button>Remove node"), fl = /* @__PURE__ */ Y("<button type=button>Edit name &amp; room"), pl = /* @__PURE__ */ Y("<form><label>Name<input name=name required maxlength=63></label><label>Room<input name=room maxlength=63></label><button>Save identity</button><button type=button>Cancel"), ml = /* @__PURE__ */ Y("<fieldset><legend> · endpoint <!></legend><div class=values>"), hl = /* @__PURE__ */ Y("<span class=value>: <strong></strong> <!>"), gl = /* @__PURE__ */ Y("<form><button>"), _l = /* @__PURE__ */ Y("<section id=devices><h2>Devices <small></small></h2><form><label>Onboarding code<input name=code required></label><button>Commission</button><button type=button>Cancel</button></form><div class=\"mt-3 grid items-start gap-3 grid-cols-[repeat(auto-fit,minmax(min(100%,22rem),1fr))]\">"), vl = /* @__PURE__ */ Y("<label class=\"mt-2 max-w-60\">Filter by room<select><option value>All rooms"), yl = /* @__PURE__ */ Y("<option>"), bl = /* @__PURE__ */ Y("<p>No devices reported yet.");
function xl(e) {
	let t = e.device, n = () => Os[t.device_id], [r, i] = W(null);
	var a = dl(), o = a.firstChild, s = o.firstChild, c = s.nextSibling, l = c.firstChild.nextSibling, u = l.nextSibling.nextSibling, d = u.nextSibling, f = o.nextSibling, p = f.nextSibling;
	return Z(o, () => t.name, s), Z(c, () => t.device_id, l), Z(c, (() => {
		var e = J(() => !n());
		return () => e() ? "loading" : n().online ? "online" : "offline";
	})(), u), Z(c, (() => {
		var e = J(() => !!t.room);
		return () => e() ? " · " + t.room : "";
	})(), d), Z(a, G(Eo, {
		get when() {
			return r();
		},
		get fallback() {
			var e = fl();
			return e._$$click = () => i({
				name: t.name,
				room: t.room
			}), e;
		},
		children: (e) => {
			var n = pl(), r = n.firstChild, a = r.firstChild.nextSibling, o = r.nextSibling, s = o.firstChild.nextSibling, c = o.nextSibling.nextSibling;
			return n.addEventListener("submit", (e) => {
				e.preventDefault();
				let { name: n, room: r } = e.currentTarget.elements, a = {
					device_id: t.device_id,
					name: n.value.trim(),
					room: r.value.trim()
				};
				Is(async () => {
					await ys.call("device.set_identity", a), i(null);
				});
			}), c._$$click = () => i(null), q(() => ({
				e: e().name,
				t: e().room,
				a: Do()
			}), ({ e, t, a: n }, r) => {
				e === r?.e && n || (a.value = e ?? ""), t === r?.t && n || (s.value = t ?? "");
			}), n;
		}
	}), f), Z(a, G(K, {
		get each() {
			return Object.keys(n()?.endpoints ?? {});
		},
		children: (e) => G(K, {
			get each() {
				return Object.keys(n()?.endpoints?.[e]?.clusters || {});
			},
			children: (r) => {
				let i = () => n()?.endpoints?.[e]?.clusters?.[r];
				var a = ml(), o = a.firstChild, s = o.firstChild, c = s.nextSibling, l = o.nextSibling;
				return Z(o, r, s), Z(o, e, c), Z(l, G(K, {
					get each() {
						return Object.entries(i()?.properties ?? {});
					},
					children: ([e, t]) => (() => {
						var n = hl(), r = n.firstChild, i = r.nextSibling, a = i.nextSibling.nextSibling;
						return Z(n, e, r), Z(i, () => String(t.label ?? t.value ?? "unknown")), Z(n, () => t.unit, a), n;
					})()
				})), Z(a, G(K, {
					get each() {
						return Object.keys(i()?.actions || {});
					},
					children: (a) => (() => {
						var o = gl(), s = o.firstChild;
						return o.addEventListener("submit", (n) => {
							n.preventDefault();
							let o = Gs(n.currentTarget, i().actions[a].arguments);
							Is(() => Rs("device.action", {
								device_id: t.device_id,
								endpoint_id: +e,
								cluster: r,
								action: a,
								arguments: o
							}, "control"));
						}), Z(o, G(Ks, { get schema() {
							return i().actions[a].arguments;
						} }), s), Z(s, a), q(() => !n()?.online, (e) => {
							X(s, "disabled", e);
						}), o;
					})()
				}), null), a;
			}
		})
	}), p), p._$$click = () => {
		confirm("Remove the underlying Matter node and all sibling devices?") && Is(() => Rs("device.remove", { device_id: t.device_id }, "membership"));
	}, a;
}
function Sl() {
	let [e, t] = W(""), n = () => [...new Set(Es.map((e) => e.room).filter(Boolean))].sort(), r = () => n().includes(e()) ? e() : "";
	var i = _l(), a = i.firstChild, o = a.firstChild.nextSibling, s = a.nextSibling, c = s.firstChild.nextSibling.nextSibling, l = s.nextSibling;
	return Z(o, () => Es.length), s.addEventListener("submit", (e) => {
		e.preventDefault();
		let t = e.currentTarget.code.value;
		Is(() => Rs("commission.start", { code: t }, "membership"));
	}), c._$$click = () => Is(() => ys.call("commission.cancel", {})), Z(i, (() => {
		var e = J(() => !!n().length);
		return () => e() ? (() => {
			var e = vl(), i = e.firstChild.nextSibling;
			return i.addEventListener("change", (e) => t(e.currentTarget.value)), Z(i, G(K, {
				get each() {
					return n();
				},
				children: (e) => (() => {
					var t = yl();
					return t.value = e, Z(t, e), q(() => e === r(), (e) => {
						t.selected = e;
					}), t;
				})()
			}), null), q(() => r(), (e) => {
				Yo(i, "value", e);
			}), e;
		})() : void 0;
	})(), l), Z(l, G(K, {
		get each() {
			return Es.filter((e) => !r() || e.room === r());
		},
		get fallback() {
			return bl();
		},
		children: (e) => G(xl, { device: e })
	})), i;
}
Vo(["click"]);
// app.jsx
var Cl = /* @__PURE__ */ Y("<header class=\"sticky top-0 z-10 flex min-h-13 items-center gap-2 sm:gap-3\"><h1>Local Fabric</h1><span class=board>ESP32-S31</span><span class=connection>"), wl = /* @__PURE__ */ Y("<output aria-live=polite>"), Tl = /* @__PURE__ */ Y("<nav class=\"ml-auto flex gap-3\"aria-label=\"Control panels\"><a href=#devices>Devices</a><a href=#activity>Activity"), El = /* @__PURE__ */ Y("<a href=#rules>Rules"), Dl = /* @__PURE__ */ Y("<section><h2>New access token</h2><p>Copy this before dismissing. If you lose it, run <code>fabric token</code> on the board’s UART.</p><input aria-label=\"New access token\"readonly><button>Dismiss"), Ol = /* @__PURE__ */ Y("<details><summary>Settings</summary><p>Rotate the shared access token for this board. You will need to update every client.</p><button type=button>Rotate access token"), kl = /* @__PURE__ */ Y("<section><form><label>Board access token (UART: fabric token)<input type=password name=secret required autocomplete=off></label><button>Connect");
function Al() {
	let [e, t] = W(""), [n, r] = W(!1);
	async function i() {
		if (!n() && confirm("Replace this board’s access token? Every client will be disconnected.")) {
			r(!0);
			try {
				let e = await fetch("/settings/token/rotate", {
					method: "POST",
					cache: "no-store",
					headers: { Authorization: "Bearer " + bs() }
				});
				if (!e.ok) throw Error(e.status + " " + await e.text());
				t(await e.text()), xs(""), Ts("Token replaced. Copy the new token, then reconnect.");
			} finally {
				r(!1);
			}
		}
	}
	return zs(), [
		(() => {
			var e = Cl(), t = e.firstChild.nextSibling.nextSibling;
			return Z(t, (() => {
				var e = J(() => !!bs());
				return () => e() ? Ss() : "Locked";
			})()), Z(e, (() => {
				var e = J(() => !!bs());
				return () => e() ? (() => {
					var e = Tl(), t = e.firstChild, n = t.nextSibling;
					return es(t), es(n), Z(e, (() => {
						var e = J(() => !!Ms());
						return () => e() ? (() => {
							var e = El();
							return es(e), e;
						})() : void 0;
					})(), null), e;
				})() : void 0;
			})(), null), e;
		})(),
		(() => {
			var e = wl();
			return Z(e, ws), e;
		})(),
		J(() => J(() => !!e())() ? (() => {
			var n = Dl(), r = n.firstChild.nextSibling.nextSibling, i = r.nextSibling;
			return r.addEventListener("focus", (e) => e.currentTarget.select()), i._$$click = () => t(""), q(() => e(), (e) => {
				r.value = e ?? "";
			}), n;
		})() : void 0),
		J(() => J(() => !!bs())() ? [
			G(Eo, {
				get when() {
					return Ss() === "Live";
				},
				get children() {
					var e = Ol(), t = e.firstChild.nextSibling.nextSibling;
					return t._$$click = () => Is(i), q(() => n(), (e) => {
						X(t, "disabled", e);
					}), e;
				}
			}),
			G(Sl, {}),
			G(ul, {}),
			G(Eo, {
				get when() {
					return Ms();
				},
				get children() {
					return G(al, {});
				}
			})
		] : (() => {
			var e = kl();
			return e.firstChild.addEventListener("submit", (e) => {
				e.preventDefault(), Ts(""), t(""), xs(e.currentTarget.secret.value.trim().replace(/^Bearer /, ""));
			}), e;
		})())
	];
}
zo(Al, document.getElementById("app")), Vo(["click"]);
